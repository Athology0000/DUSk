package org.cobalt.internal.ui.panel.panels

import org.cobalt.api.ui.theme.ThemeManager
import org.cobalt.api.util.ui.NVGRenderer
import org.cobalt.internal.mining.CommissionMacroModule
import org.cobalt.internal.mining.CommissionMacroModule.CommissionRouteZone
import org.cobalt.internal.mining.RoutesModule
import org.cobalt.internal.ui.components.settings.UICheckboxSetting
import org.cobalt.internal.ui.panel.UIPanel
import org.cobalt.internal.ui.util.ScrollHandler
import org.cobalt.internal.ui.util.isHoveringOver

internal class UICommissionRoutesPanel : UIPanel(
  x = 0f,
  y = 0f,
  width = 320f,
  height = 600f,
) {

  private val scroll = ScrollHandler()
  private val zones = CommissionMacroModule.getRouteZones()
  private var routes = emptyList<RoutesModule.SavedRouteInfo>()
  private var activeZone = zones.firstOrNull() ?: CommissionRouteZone.ROYAL

  init {
    refreshRoutes()
  }

  override fun render() {
    val theme = ThemeManager.currentTheme
    NVGRenderer.rect(x, y, width, height, theme.background, 10f)

    NVGRenderer.text("Commission Routes", x + PAD, y + 24f, 13f, theme.text)
    NVGRenderer.text(
      "Assign one saved route per zone. Titanium uses the same zone route.",
      x + PAD,
      y + 43f,
      9f,
      theme.textSecondary
    )

    renderTopButtons()
    renderZoneRows()

    val assignedCount = zones.count { zone -> CommissionMacroModule.getAssignedRouteName(zone) != null }
    NVGRenderer.text("Assigned $assignedCount / ${zones.size}", x + PAD, routeHeaderY() - 18f, 9f, theme.textSecondary)
    NVGRenderer.text(
      "Saved Routes (${activeZone.label})",
      x + PAD,
      routeHeaderY() - 2f,
      11f,
      theme.text
    )

    val contentY = routeListTop()
    val visibleHeight = height - (contentY - y) - PAD
    val totalHeight = if (routes.isEmpty()) EMPTY_STATE_H else routes.size * (ROW_H + ROW_GAP)
    scroll.setMaxScroll(totalHeight, visibleHeight)

    NVGRenderer.pushScissor(x + PAD, contentY, width - PAD * 2f, visibleHeight)
    if (routes.isEmpty()) {
      renderEmptyState(contentY)
    } else {
      val offset = scroll.getOffset()
      routes.forEachIndexed { index, route ->
        renderRouteRow(route, contentY + index * (ROW_H + ROW_GAP) - offset)
      }
    }
    NVGRenderer.popScissor()
  }

  override fun mouseClicked(button: Int): Boolean {
    if (button != 0) return false

    val refreshBounds = refreshButtonBounds()
    if (isHoveringOver(refreshBounds[0], refreshBounds[1], refreshBounds[2], refreshBounds[3])) {
      refreshRoutes()
      return true
    }

    val clearZoneBounds = clearZoneButtonBounds()
    if (isHoveringOver(clearZoneBounds[0], clearZoneBounds[1], clearZoneBounds[2], clearZoneBounds[3])) {
      CommissionMacroModule.assignRoute(activeZone, null)
      return true
    }

    val clearAllBounds = clearAllButtonBounds()
    if (isHoveringOver(clearAllBounds[0], clearAllBounds[1], clearAllBounds[2], clearAllBounds[3])) {
      CommissionMacroModule.clearRouteAssignments()
      CommissionMacroModule.clearRouteSelections()
      return true
    }

    zones.forEachIndexed { index, zone ->
      val rowY = zoneRowsTop() + index * (ZONE_ROW_H + ZONE_ROW_GAP)
      if (isHoveringOver(x + PAD, rowY, width - PAD * 2f, ZONE_ROW_H)) {
        activeZone = zone
        return true
      }
    }

    if (routes.isEmpty()) {
      return false
    }

    val contentY = routeListTop()
    val offset = scroll.getOffset()
    routes.forEachIndexed { index, route ->
      val rowY = contentY + index * (ROW_H + ROW_GAP) - offset
      if (isHoveringOver(x + PAD, rowY, width - PAD * 2f, ROW_H)) {
        val nextRoute = if (CommissionMacroModule.isRouteAssigned(activeZone, route.name)) null else route.name
        CommissionMacroModule.assignRoute(activeZone, nextRoute)
        return true
      }
    }

    return false
  }

  override fun mouseScrolled(horizontalAmount: Double, verticalAmount: Double): Boolean {
    if (!isHoveringOver(x, y, width, height)) {
      return false
    }
    scroll.handleScroll(verticalAmount)
    return true
  }

  private fun refreshRoutes() {
    routes = CommissionMacroModule.getAvailableRouteInfos()
  }

  private fun renderTopButtons() {
    renderButton("Refresh", refreshButtonBounds())
    renderButton("Clear Zone", clearZoneButtonBounds())
    renderButton("Clear All", clearAllButtonBounds())
  }

  private fun renderButton(label: String, bounds: FloatArray) {
    val theme = ThemeManager.currentTheme
    val bx = bounds[0]
    val by = bounds[1]
    val bw = bounds[2]
    val bh = bounds[3]
    val hovering = isHoveringOver(bx, by, bw, bh)
    NVGRenderer.rect(bx, by, bw, bh, if (hovering) theme.selectedOverlay else theme.controlBg, 6f)
    NVGRenderer.hollowRect(bx, by, bw, bh, 1f, theme.controlBorder, 6f)
    val textWidth = NVGRenderer.textWidth(label, 10f)
    NVGRenderer.text(label, bx + (bw - textWidth) / 2f, by + 6f, 10f, theme.text)
  }

  private fun renderZoneRows() {
    zones.forEachIndexed { index, zone ->
      renderZoneRow(zone, zoneRowsTop() + index * (ZONE_ROW_H + ZONE_ROW_GAP))
    }
  }

  private fun renderZoneRow(zone: CommissionRouteZone, rowY: Float) {
    val theme = ThemeManager.currentTheme
    val rowX = x + PAD
    val rowW = width - PAD * 2f
    val hovering = isHoveringOver(rowX, rowY, rowW, ZONE_ROW_H)
    val active = zone == activeZone
    val assigned = CommissionMacroModule.getAssignedRouteName(zone)
    val bgColor = when {
      active -> theme.selectedOverlay
      hovering -> theme.overlay
      else -> theme.controlBg
    }
    val borderColor = if (active) theme.accent else theme.controlBorder

    NVGRenderer.rect(rowX, rowY, rowW, ZONE_ROW_H, bgColor, 8f)
    NVGRenderer.hollowRect(rowX, rowY, rowW, ZONE_ROW_H, 1f, borderColor, 8f)
    NVGRenderer.text(zone.label, rowX + 10f, rowY + 9f, 11f, if (active) theme.accent else theme.text)
    NVGRenderer.text(
      ellipsize(assigned ?: "Unassigned", rowW - 20f, 9f),
      rowX + 10f,
      rowY + 24f,
      9f,
      theme.textSecondary
    )
  }

  private fun renderEmptyState(contentY: Float) {
    val theme = ThemeManager.currentTheme
    val boxX = x + PAD
    val boxY = contentY + 4f
    val boxW = width - PAD * 2f
    NVGRenderer.rect(boxX, boxY, boxW, EMPTY_STATE_H - 8f, theme.controlBg, 8f)
    NVGRenderer.hollowRect(boxX, boxY, boxW, EMPTY_STATE_H - 8f, 1f, theme.controlBorder, 8f)
    NVGRenderer.text("No saved routes found.", boxX + 12f, boxY + 16f, 11f, theme.text)
    NVGRenderer.text(
      "Save routes in the Routes module, then press Refresh.",
      boxX + 12f,
      boxY + 34f,
      9f,
      theme.textSecondary
    )
  }

  private fun renderRouteRow(route: RoutesModule.SavedRouteInfo, rowY: Float) {
    if (rowY + ROW_H < routeListTop() - 4f || rowY > y + height) {
      return
    }

    val theme = ThemeManager.currentTheme
    val rowX = x + PAD
    val rowW = width - PAD * 2f
    val selected = CommissionMacroModule.isRouteAssigned(activeZone, route.name)
    val hovering = isHoveringOver(rowX, rowY, rowW, ROW_H)
    val bgColor = when {
      selected -> theme.selectedOverlay
      hovering -> theme.overlay
      else -> theme.controlBg
    }
    val borderColor = if (selected) theme.accent else theme.controlBorder
    val nameColor = if (selected) theme.accent else theme.text

    NVGRenderer.rect(rowX, rowY, rowW, ROW_H, bgColor, 8f)
    NVGRenderer.hollowRect(rowX, rowY, rowW, ROW_H, 1f, borderColor, 8f)

    val cbX = rowX + 10f
    val cbY = rowY + 10f
    if (selected) {
      NVGRenderer.rect(cbX, cbY, CHECKBOX, CHECKBOX, theme.accent, 4f)
      NVGRenderer.image(
        UICheckboxSetting.checkmarkIcon,
        cbX + 1f,
        cbY + 1f,
        CHECKBOX - 2f,
        CHECKBOX - 2f,
        colorMask = theme.textOnAccent
      )
    } else {
      NVGRenderer.rect(cbX, cbY, CHECKBOX, CHECKBOX, theme.controlBg, 4f)
      NVGRenderer.hollowRect(cbX, cbY, CHECKBOX, CHECKBOX, 1f, theme.controlBorder, 4f)
    }

    val textX = cbX + CHECKBOX + 10f
    val routeName = ellipsize(route.name, rowW - (textX - rowX) - 10f, 11f)
    NVGRenderer.text(routeName, textX, rowY + 9f, 11f, nameColor)

    val details = ellipsize(buildRouteDetails(route), rowW - (textX - rowX) - 10f, 9f)
    NVGRenderer.text(details, textX, rowY + 26f, 9f, theme.textSecondary)
  }

  private fun buildRouteDetails(route: RoutesModule.SavedRouteInfo): String {
    val parts = mutableListOf<String>()
    if (route.mineTypes.isNotEmpty()) {
      parts += route.mineTypes.joinToString(", ")
    } else if (route.hasMinePoints) {
      parts += "Mine anchors (unknown block ids)"
    } else {
      parts += "Travel only"
    }
    if (route.hasWarpPoints) {
      parts += "warp points"
    }
    parts += "${route.pointCount} pts"
    return parts.joinToString(" | ")
  }

  private fun ellipsize(text: String, maxWidth: Float, size: Float): String {
    if (NVGRenderer.textWidth(text, size) <= maxWidth) {
      return text
    }
    var end = text.length
    while (end > 1) {
      val candidate = text.substring(0, end).trimEnd() + "..."
      if (NVGRenderer.textWidth(candidate, size) <= maxWidth) {
        return candidate
      }
      end--
    }
    return "..."
  }

  private fun refreshButtonBounds(): FloatArray {
    val bw = 76f
    val bh = 24f
    return floatArrayOf(x + width - PAD - bw * 3f - 16f, y + 16f, bw, bh)
  }

  private fun clearZoneButtonBounds(): FloatArray {
    val bw = 76f
    val bh = 24f
    return floatArrayOf(x + width - PAD - bw * 2f - 8f, y + 16f, bw, bh)
  }

  private fun clearAllButtonBounds(): FloatArray {
    val bw = 76f
    val bh = 24f
    return floatArrayOf(x + width - PAD - bw, y + 16f, bw, bh)
  }

  private fun zoneRowsTop(): Float = y + 78f

  private fun routeHeaderY(): Float = zoneRowsTop() + zones.size * (ZONE_ROW_H + ZONE_ROW_GAP) + 10f

  private fun routeListTop(): Float = routeHeaderY() + 16f

  companion object {
    private const val PAD = 16f
    private const val ROW_H = 52f
    private const val ROW_GAP = 8f
    private const val ZONE_ROW_H = 38f
    private const val ZONE_ROW_GAP = 6f
    private const val CHECKBOX = 16f
    private const val EMPTY_STATE_H = 76f
  }
}

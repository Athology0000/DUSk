package org.cobalt.internal.ui.panel.panels

import org.cobalt.api.ui.theme.ThemeManager
import org.cobalt.api.util.ui.NVGRenderer
import org.cobalt.internal.combat.CombatMacroModule
import org.cobalt.internal.mining.RoutesModule
import org.cobalt.internal.ui.panel.UIPanel
import org.cobalt.internal.ui.util.ScrollHandler
import org.cobalt.internal.ui.util.isHoveringOver

internal class UICombatWalkbackRoutesPanel : UIPanel(
  x = 0f,
  y = 0f,
  width = 340f,
  height = 600f,
) {

  private var pickerType: Int? = null
  private var routes = emptyList<RoutesModule.SavedRouteInfo>()
  private val scroll = ScrollHandler()

  init {
    activePanel = this
    refreshRoutes()
  }

  override fun render() {
    val theme = ThemeManager.currentTheme
    NVGRenderer.rect(x, y, width, height, theme.background, 10f)

    val activePicker = pickerType
    if (activePicker == null) {
      renderOverview()
    } else {
      renderPicker(activePicker)
    }
  }

  override fun mouseClicked(button: Int): Boolean {
    if (button != 0) return false

    val activePicker = pickerType
    if (activePicker == null) {
      ROUTE_TYPES.forEachIndexed { index, type ->
        val rowY = rowsTop() + index * (ROW_H + ROW_GAP)
        if (isHoveringOver(x + PAD, rowY, width - PAD * 2f, ROW_H)) {
          pickerType = type
          refreshRoutes()
          scroll.reset()
          return true
        }
      }
      return false
    }

    val backBounds = backButtonBounds()
    if (isHoveringOver(backBounds[0], backBounds[1], backBounds[2], backBounds[3])) {
      pickerType = null
      return true
    }

    val refreshBounds = refreshButtonBounds()
    if (isHoveringOver(refreshBounds[0], refreshBounds[1], refreshBounds[2], refreshBounds[3])) {
      refreshRoutes()
      return true
    }

    val clearBounds = clearButtonBounds()
    if (isHoveringOver(clearBounds[0], clearBounds[1], clearBounds[2], clearBounds[3])) {
      CombatMacroModule.setWalkbackRouteNameForType(activePicker, "")
      pickerType = null
      return true
    }

    if (routes.isNotEmpty()) {
      val contentY = routeListTop()
      val offset = scroll.getOffset()
      routes.forEachIndexed { index, route ->
        val rowY = contentY + index * (PICKER_ROW_H + PICKER_ROW_GAP) - offset
        if (isHoveringOver(x + PAD, rowY, width - PAD * 2f, PICKER_ROW_H)) {
          CombatMacroModule.setWalkbackRouteNameForType(activePicker, route.name)
          pickerType = null
          return true
        }
      }
    }

    return false
  }

  override fun mouseScrolled(horizontalAmount: Double, verticalAmount: Double): Boolean {
    if (pickerType == null) return false
    val listTop = routeListTop()
    val listHeight = height - (listTop - y) - PAD
    if (!isHoveringOver(x + PAD, listTop, width - PAD * 2f, listHeight)) {
      return false
    }
    scroll.handleScroll(verticalAmount)
    return true
  }

  private fun renderOverview() {
    val theme = ThemeManager.currentTheme
    NVGRenderer.text("Walkback Routes", x + PAD, y + 24f, 13f, theme.text)
    NVGRenderer.text(
      "Combat Macro route choosers stay visible here.",
      x + PAD,
      y + 43f,
      9f,
      theme.textSecondary,
    )
    NVGRenderer.text(
      "Click any row to assign or change the route.",
      x + PAD,
      y + 57f,
      9f,
      theme.textSecondary,
    )

    ROUTE_TYPES.forEachIndexed { index, type ->
      renderOverviewRow(type, rowsTop() + index * (ROW_H + ROW_GAP))
    }
  }

  private fun renderOverviewRow(type: Int, rowY: Float) {
    val theme = ThemeManager.currentTheme
    val rowX = x + PAD
    val rowW = width - PAD * 2f
    val selected = CombatMacroModule.getSelectedSlayerType() == type
    val hovering = isHoveringOver(rowX, rowY, rowW, ROW_H)
    val bgColor = when {
      selected -> theme.selectedOverlay
      hovering -> theme.overlay
      else -> theme.controlBg
    }
    val borderColor = if (selected) theme.accent else theme.controlBorder

    NVGRenderer.rect(rowX, rowY, rowW, ROW_H, bgColor, 8f)
    NVGRenderer.hollowRect(rowX, rowY, rowW, ROW_H, 1f, borderColor, 8f)

    val label = ellipsize(CombatMacroModule.getWalkbackRouteLabelForType(type), rowW - 96f, 11f)
    val route = ellipsize(CombatMacroModule.getWalkbackRouteNameForType(type), rowW - 24f, 10f)
    val labelColor = if (selected) theme.accent else theme.text

    NVGRenderer.text(label, rowX + 12f, rowY + 11f, 11f, labelColor)
    NVGRenderer.text(route, rowX + 12f, rowY + 31f, 10f, theme.textSecondary)

    val editLabel = "Edit"
    val editWidth = NVGRenderer.textWidth(editLabel, 10f) + 18f
    val editX = rowX + rowW - editWidth - 12f
    val editY = rowY + 12f
    NVGRenderer.rect(editX, editY, editWidth, 22f, theme.accent, 5f)
    NVGRenderer.text(
      editLabel,
      editX + (editWidth - NVGRenderer.textWidth(editLabel, 10f)) / 2f,
      editY + 6f,
      10f,
      theme.textOnAccent,
    )
  }

  private fun renderPicker(type: Int) {
    val theme = ThemeManager.currentTheme
    NVGRenderer.text("Walkback Routes", x + PAD, y + 24f, 13f, theme.text)
    NVGRenderer.text(
      CombatMacroModule.getWalkbackRouteLabelForType(type),
      x + PAD,
      y + 43f,
      10f,
      theme.accent,
    )
    NVGRenderer.text(
      "Choose a saved route for this slayer zone.",
      x + PAD,
      y + 57f,
      9f,
      theme.textSecondary,
    )

    renderButton("Back", backButtonBounds())
    renderButton("Refresh", refreshButtonBounds())
    renderButton("Clear", clearButtonBounds())

    NVGRenderer.text(
      "Saved Routes",
      x + PAD,
      routeHeaderY() - 2f,
      11f,
      theme.text,
    )

    val contentY = routeListTop()
    val visibleHeight = height - (contentY - y) - PAD
    val totalHeight = if (routes.isEmpty()) EMPTY_STATE_H else routes.size * (PICKER_ROW_H + PICKER_ROW_GAP)
    scroll.setMaxScroll(totalHeight, visibleHeight)

    NVGRenderer.pushScissor(x + PAD, contentY, width - PAD * 2f, visibleHeight)
    if (routes.isEmpty()) {
      renderEmptyState(contentY)
    } else {
      val offset = scroll.getOffset()
      routes.forEachIndexed { index, route ->
        renderPickerRow(type, route, contentY + index * (PICKER_ROW_H + PICKER_ROW_GAP) - offset)
      }
    }
    NVGRenderer.popScissor()
  }

  private fun renderPickerRow(type: Int, route: RoutesModule.SavedRouteInfo, rowY: Float) {
    if (rowY + PICKER_ROW_H < routeListTop() - 4f || rowY > y + height) {
      return
    }

    val theme = ThemeManager.currentTheme
    val rowX = x + PAD
    val rowW = width - PAD * 2f
    val selected = CombatMacroModule.getWalkbackRouteNameForType(type) == route.name
    val hovering = isHoveringOver(rowX, rowY, rowW, PICKER_ROW_H)

    val bgColor = when {
      selected -> theme.selectedOverlay
      hovering -> theme.overlay
      else -> theme.controlBg
    }
    val borderColor = if (selected) theme.accent else theme.controlBorder
    val nameColor = if (selected) theme.accent else theme.text

    NVGRenderer.rect(rowX, rowY, rowW, PICKER_ROW_H, bgColor, 8f)
    NVGRenderer.hollowRect(rowX, rowY, rowW, PICKER_ROW_H, 1f, borderColor, 8f)
    NVGRenderer.text(ellipsize(route.name, rowW - 24f, 11f), rowX + 12f, rowY + 10f, 11f, nameColor)
    NVGRenderer.text(
      ellipsize(buildRouteDetails(route), rowW - 24f, 9f),
      rowX + 12f,
      rowY + 28f,
      9f,
      theme.textSecondary,
    )
  }

  private fun renderEmptyState(contentY: Float) {
    val theme = ThemeManager.currentTheme
    val boxX = x + PAD
    val boxW = width - PAD * 2f
    NVGRenderer.rect(boxX, contentY + 4f, boxW, EMPTY_STATE_H - 8f, theme.controlBg, 8f)
    NVGRenderer.hollowRect(boxX, contentY + 4f, boxW, EMPTY_STATE_H - 8f, 1f, theme.controlBorder, 8f)
    NVGRenderer.text("No saved routes found.", boxX + 12f, contentY + 20f, 11f, theme.text)
    NVGRenderer.text(
      "Save routes in the Routes module, then press Refresh.",
      boxX + 12f,
      contentY + 38f,
      9f,
      theme.textSecondary,
    )
  }

  private fun renderButton(label: String, bounds: FloatArray) {
    val theme = ThemeManager.currentTheme
    val bx = bounds[0]
    val by = bounds[1]
    val bw = bounds[2]
    val bh = bounds[3]
    val hovering = isHoveringOver(bx, by, bw, bh)
    NVGRenderer.rect(bx, by, bw, bh, if (hovering) theme.selectedOverlay else theme.controlBg, 6f)
    NVGRenderer.hollowRect(bx, by, bw, bh, 1f, theme.controlBorder, 6f)
    val textWidth = NVGRenderer.textWidth(label, 10f)
    NVGRenderer.text(label, bx + (bw - textWidth) / 2f, by + 6f, 10f, theme.text)
  }

  private fun rowsTop(): Float = y + 86f

  private fun refreshRoutes() {
    routes = RoutesModule.getSavedRouteInfos()
  }

  private fun openPicker(type: Int) {
    pickerType = type
    refreshRoutes()
    scroll.reset()
  }

  private fun buildRouteDetails(route: RoutesModule.SavedRouteInfo): String {
    val parts = mutableListOf<String>()
    if (route.mineTypes.isNotEmpty()) {
      parts += route.mineTypes.joinToString(", ")
    } else if (route.hasMinePoints) {
      parts += "Mine anchors"
    } else {
      parts += "Travel only"
    }
    if (route.hasWarpPoints) {
      parts += "warp points"
    }
    parts += "${route.pointCount} pts"
    return parts.joinToString(" | ")
  }

  private fun backButtonBounds(): FloatArray {
    val buttonWidth = 58f
    val buttonHeight = 24f
    return floatArrayOf(x + width - PAD - buttonWidth * 3f - 16f, y + 14f, buttonWidth, buttonHeight)
  }

  private fun refreshButtonBounds(): FloatArray {
    val buttonWidth = 58f
    val buttonHeight = 24f
    return floatArrayOf(x + width - PAD - buttonWidth * 2f - 8f, y + 14f, buttonWidth, buttonHeight)
  }

  private fun clearButtonBounds(): FloatArray {
    val buttonWidth = 58f
    val buttonHeight = 24f
    return floatArrayOf(x + width - PAD - buttonWidth, y + 14f, buttonWidth, buttonHeight)
  }

  private fun routeHeaderY(): Float = y + 82f

  private fun routeListTop(): Float = routeHeaderY() + 16f

  private fun ellipsize(text: String, maxWidth: Float, size: Float): String {
    if (NVGRenderer.textWidth(text, size) <= maxWidth) {
      return text
    }
    var end = text.length
    while (end > 1) {
      val candidate = text.substring(0, end).trimEnd() + "..."
      if (NVGRenderer.textWidth(candidate, size) <= maxWidth) {
        return candidate
      }
      end--
    }
    return "..."
  }

  companion object {
    private var activePanel: UICombatWalkbackRoutesPanel? = null
    private val ROUTE_TYPES = listOf(0, 1, 2, 3, 4, 5)
    private const val PAD = 16f
    private const val ROW_H = 54f
    private const val ROW_GAP = 8f
    private const val PICKER_ROW_H = 50f
    private const val PICKER_ROW_GAP = 8f
    private const val EMPTY_STATE_H = 76f

    fun showPicker(type: Int): Boolean {
      val panel = activePanel ?: return false
      panel.openPicker(type)
      return true
    }
  }
}

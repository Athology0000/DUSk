package org.cobalt.internal.ui

import net.minecraft.client.input.CharacterEvent
import net.minecraft.client.input.KeyEvent

internal abstract class UIComponent(
  var x: Float,
  var y: Float,
  var width: Float,
  var height: Float,
) {

  abstract fun render()

  open fun mouseClicked(button: Int): Boolean = false
  open fun mouseReleased(button: Int): Boolean = false
  open fun mouseDragged(button: Int, offsetX: Double, offsetY: Double): Boolean = false
  open fun mouseScrolled(horizontalAmount: Double, verticalAmount: Double): Boolean = false

  open fun charTyped(input: CharacterEvent): Boolean = false
  open fun keyPressed(input: KeyEvent): Boolean = false

  fun updateBounds(x: Float, y: Float): UIComponent {
    this.x = x
    this.y = y
    return this
  }

}

package org.cobalt.internal.routes

import java.awt.Color
import net.minecraft.client.Minecraft
import net.minecraft.world.phys.AABB
import net.minecraft.world.phys.BlockHitResult
import net.minecraft.world.phys.HitResult
import net.minecraft.world.phys.Vec3
import org.cobalt.api.event.EventBus
import org.cobalt.api.event.annotation.SubscribeEvent
import org.cobalt.api.event.impl.client.MouseEvent
import org.cobalt.api.event.impl.render.NvgEvent
import org.cobalt.api.event.impl.render.WorldRenderEvent
import org.cobalt.api.ui.theme.ThemeManager
import org.cobalt.api.util.render.Render3D
import org.cobalt.api.util.ui.NVGRenderer
import org.cobalt.internal.ui.util.isHoveringOver

/** Manages the in-world route edit mode. Closed screen, sticky HUD, right-click recording. */
internal object RouteEditMode {

    private val mc = Minecraft.getInstance()

    var isActive = false
        private set

    private var activeRoute: SavedRoute? = null
    private var activeSub: SubRouteKey = SubRouteKey.POINTS
    private var currentMode: RoutePointType = RoutePointType.WALK
    private var validModes: List<RoutePointType> = emptyList()
    private val points = mutableListOf<RoutePoint>()

    /** If non-null, the next recorded point is inserted after this index (0-based). */
    private var insertAfterIndex: Int? = null
    private var onDoneCallback: (() -> Unit)? = null

    /** Colors for each point type (fill + stroke). */
    private val typeColor: Map<RoutePointType, Color> = mapOf(
        RoutePointType.WALK to Color(0x4D, 0xE2, 0xC5),  // teal
        RoutePointType.WARP to Color(0xFF, 0xE0, 0x4F),  // yellow
        RoutePointType.MINE to Color(0xFF, 0x8C, 0x00),  // orange
        RoutePointType.KILL to Color(0xFF, 0x6B, 0x8A),  // pink/red
    )

    // ── HUD geometry ─────────────────────────────────────────────────────────

    private const val HUD_W = 500f
    private const val HUD_H = 66f
    private const val HUD_PAD_BOTTOM = 28f
    private const val BTN_H = 24f
    private const val BTN_PAD_H = 10f  // horizontal padding inside button
    private const val BTN_GAP = 6f

    // Cached hit-test rects: [x, y, w, h] per button index in renderOrder
    private var modeButtonRects = emptyList<FloatArray>()
    private var undoBtnRect = floatArrayOf(0f, 0f, 0f, 0f)
    private var doneBtnRect  = floatArrayOf(0f, 0f, 0f, 0f)
    private var hudX = 0f
    private var hudY = 0f

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Enter edit mode for [sub] of [route].
     * Closes the Cobalt UI, activates in-world recording.
     * [onDone] is called (on the render thread) when the user clicks Done.
     */
    fun enterEdit(route: SavedRoute, sub: SubRouteKey, onDone: () -> Unit = {}) {
        activeRoute = route
        activeSub = sub
        validModes = allowedPointTypes(route.type, sub)
        currentMode = validModes.firstOrNull() ?: RoutePointType.WALK
        points.clear()
        points.addAll(route.getSubRoute(sub))
        insertAfterIndex = null
        onDoneCallback = onDone
        isActive = true
        mc.setScreen(null)
    }

    /**
     * Enter insert mode: next recorded point is inserted after [afterIndex].
     * The caller should close the Cobalt UI beforehand.
     */
    fun enterInsertMode(route: SavedRoute, sub: SubRouteKey, afterIndex: Int, onDone: () -> Unit = {}) {
        enterEdit(route, sub, onDone)
        insertAfterIndex = afterIndex
    }

    /** Returns the current point list (live copy, not the route itself). */
    fun getPoints(): List<RoutePoint> = points.toList()

    // ── Event handlers ────────────────────────────────────────────────────────

    @SubscribeEvent
    fun onNvg(@Suppress("UNUSED_PARAMETER") event: NvgEvent) {
        if (!isActive) return
        val route = activeRoute ?: return

        val window = mc.window
        val sw = window.screenWidth.toFloat()
        val sh = window.screenHeight.toFloat()

        hudX = sw / 2f - HUD_W / 2f
        hudY = sh - HUD_H - HUD_PAD_BOTTOM

        NVGRenderer.beginFrame(sw, sh)
        renderHud(route)
        NVGRenderer.endFrame()
    }

    @SubscribeEvent
    fun onWorldRender(event: WorldRenderEvent.Last) {
        if (!isActive || points.isEmpty()) return

        for (i in 0 until points.size - 1) {
            val a = points[i]
            val b = points[i + 1]
            val start = Vec3(a.x + 0.5, a.y + 0.5, a.z + 0.5)
            val end   = Vec3(b.x + 0.5, b.y + 0.5, b.z + 0.5)
            val color = typeColor[a.type] ?: Color.WHITE
            Render3D.drawLine(event.context, start, end, color, esp = true, thickness = 1.5f)
        }

        points.forEachIndexed { i, pt ->
            val color = typeColor[pt.type] ?: Color.WHITE
            val box = AABB(
                pt.x.toDouble(), pt.y.toDouble(), pt.z.toDouble(),
                pt.x + 1.0, pt.y + 1.0, pt.z + 1.0,
            )
            Render3D.drawBox(event.context, box, color, esp = true)
            val labelPos = Vec3(pt.x + 0.5, pt.y + 1.3, pt.z + 0.5)
            Render3D.drawWorldLabel(event.context, labelPos, "#${i + 1} ${pt.type.label}", color)
        }
    }

    @SubscribeEvent
    fun onRightClick(event: MouseEvent.RightClick) {
        if (!isActive) return
        val hit = mc.hitResult
        if (hit !is BlockHitResult || hit.type != HitResult.Type.BLOCK) return

        event.setCancelled(true)

        val pos = hit.blockPos
        val shiftHeld = mc.options.keyShift.isDown

        val type = if (shiftHeld) {
            // Cycle through valid modes on shift+click instead of a popup
            val idx = validModes.indexOf(currentMode)
            validModes[(idx + 1) % validModes.size]
        } else {
            currentMode
        }

        val newPoint = RoutePoint(type = type, x = pos.x, y = pos.y, z = pos.z)
        val insertIdx = insertAfterIndex
        if (insertIdx != null) {
            val clampedIdx = (insertIdx + 1).coerceIn(0, points.size)
            points.add(clampedIdx, newPoint)
            // After one insert, clear the insertAfterIndex so subsequent clicks append
            insertAfterIndex = null
        } else {
            points.add(newPoint)
        }

        saveCurrentPoints()
    }

    // ── NVG rendering ─────────────────────────────────────────────────────────

    private fun renderHud(route: SavedRoute) {
        val theme = ThemeManager.currentTheme
        val hx = hudX
        val hy = hudY

        // Background
        NVGRenderer.rect(hx, hy, HUD_W, HUD_H, theme.background, 10f)
        NVGRenderer.hollowRect(hx, hy, HUD_W, HUD_H, 1f, theme.controlBorder, 10f)

        // Row 1: route name + sub-route label   |   point count
        val titleText  = "${route.name}  ›  ${activeSub.icon} ${activeSub.label}"
        val ptCountTxt = "${points.size} pts"
        NVGRenderer.text(titleText, hx + 14f, hy + 14f, 11f, theme.text)
        val ptCountW = NVGRenderer.textWidth(ptCountTxt, 10f)
        NVGRenderer.text(ptCountTxt, hx + HUD_W - ptCountW - 14f, hy + 14f, 10f, theme.textSecondary)

        // Insert indicator
        val insertIdx = insertAfterIndex
        if (insertIdx != null) {
            val hint = "Inserting after #${insertIdx + 1}"
            NVGRenderer.text(hint, hx + 14f, hy + 29f, 9f, theme.accent)
        }

        // Row 2: mode buttons + Undo + Done
        val btnY = hy + HUD_H - BTN_H - 10f
        var curX = hx + 14f

        val newModeRects = mutableListOf<FloatArray>()
        for (mode in validModes) {
            val label = "${mode.icon} ${mode.label}"
            val bw = NVGRenderer.textWidth(label, 10f) + BTN_PAD_H * 2f
            val isSelected = mode == currentMode
            val isHover    = isHoveringOver(curX, btnY, bw, BTN_H)
            val bg = when {
                isSelected -> theme.accent
                isHover    -> theme.selectedOverlay
                else       -> theme.controlBg
            }
            val textColor = if (isSelected) theme.textOnAccent else theme.text
            NVGRenderer.rect(curX, btnY, bw, BTN_H, bg, 6f)
            NVGRenderer.hollowRect(curX, btnY, bw, BTN_H, 1f, theme.controlBorder, 6f)
            NVGRenderer.text(label, curX + BTN_PAD_H, btnY + 5f, 10f, textColor)
            newModeRects.add(floatArrayOf(curX, btnY, bw, BTN_H))
            curX += bw + BTN_GAP
        }
        modeButtonRects = newModeRects

        // Spacer gap before Undo/Done
        val rightEdge = hx + HUD_W - 14f

        val doneLabel  = "Done"
        val undoLabel  = "Undo"
        val doneBw  = NVGRenderer.textWidth(doneLabel, 10f) + BTN_PAD_H * 2f
        val undoBw  = NVGRenderer.textWidth(undoLabel, 10f) + BTN_PAD_H * 2f

        val doneBx = rightEdge - doneBw
        val undoBx = doneBx - undoBw - BTN_GAP

        val doneHover = isHoveringOver(doneBx, btnY, doneBw, BTN_H)
        val undoHover = isHoveringOver(undoBx, btnY, undoBw, BTN_H)

        // Done
        NVGRenderer.rect(doneBx, btnY, doneBw, BTN_H, if (doneHover) theme.accent else theme.controlBg, 6f)
        NVGRenderer.hollowRect(doneBx, btnY, doneBw, BTN_H, 1f, theme.controlBorder, 6f)
        NVGRenderer.text(doneLabel, doneBx + BTN_PAD_H, btnY + 5f, 10f, if (doneHover) theme.textOnAccent else theme.text)
        doneBtnRect = floatArrayOf(doneBx, btnY, doneBw, BTN_H)

        // Undo
        NVGRenderer.rect(undoBx, btnY, undoBw, BTN_H, if (undoHover) theme.selectedOverlay else theme.controlBg, 6f)
        NVGRenderer.hollowRect(undoBx, btnY, undoBw, BTN_H, 1f, theme.controlBorder, 6f)
        NVGRenderer.text(undoLabel, undoBx + BTN_PAD_H, btnY + 5f, 10f, theme.text)
        undoBtnRect = floatArrayOf(undoBx, btnY, undoBw, BTN_H)
    }

    @SubscribeEvent
    fun onLeftClick(event: MouseEvent.LeftClick) {
        if (!isActive) return

        // Mode buttons
        modeButtonRects.forEachIndexed { i, rect ->
            if (isHoveringOver(rect[0], rect[1], rect[2], rect[3])) {
                currentMode = validModes[i]
                event.setCancelled(true)
                return
            }
        }

        // Undo
        if (isHoveringOver(undoBtnRect[0], undoBtnRect[1], undoBtnRect[2], undoBtnRect[3])) {
            if (points.isNotEmpty()) {
                points.removeAt(points.lastIndex)
                saveCurrentPoints()
            }
            event.setCancelled(true)
            return
        }

        // Done
        if (isHoveringOver(doneBtnRect[0], doneBtnRect[1], doneBtnRect[2], doneBtnRect[3])) {
            finishEdit()
            event.setCancelled(true)
            return
        }
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private fun saveCurrentPoints() {
        val route = activeRoute ?: return
        val updated = route.withSubRoute(activeSub, points.toList())
        activeRoute = updated
        RouteStore.save(updated)
    }

    private fun finishEdit() {
        isActive = false
        val cb = onDoneCallback
        activeRoute = null
        onDoneCallback = null
        cb?.invoke()
    }

}

package org.cobalt.internal.combat

import java.util.UUID
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import java.awt.Color
import net.minecraft.ChatFormatting
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
import net.minecraft.client.multiplayer.ClientLevel
import net.minecraft.world.scores.DisplaySlot
import net.minecraft.core.BlockPos
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.decoration.ArmorStand
import net.minecraft.world.entity.player.Player
import net.minecraft.client.player.LocalPlayer
import org.cobalt.api.event.EventBus
import org.cobalt.api.event.annotation.SubscribeEvent
import org.cobalt.api.event.impl.client.ChatEvent
import org.cobalt.api.event.impl.client.TickEvent
import org.cobalt.api.event.impl.render.WorldRenderEvent
import org.cobalt.api.module.Module
import org.cobalt.api.module.setting.inGroup
import org.cobalt.api.module.setting.impl.ActionSetting
import org.cobalt.api.module.setting.impl.CheckboxSetting
import org.cobalt.api.module.setting.impl.ColorSetting
import org.cobalt.api.module.setting.impl.InfoSetting
import org.cobalt.api.module.setting.impl.InfoType
import org.cobalt.api.module.setting.impl.ModeSetting
import org.cobalt.api.module.setting.impl.KeyBindSetting
import org.cobalt.api.module.setting.impl.SliderSetting
import org.cobalt.api.module.setting.impl.TextSetting
import org.cobalt.api.util.helper.KeyBind
import org.cobalt.api.notification.NotificationManager
import org.cobalt.api.rotation.IRotationStrategy
import org.cobalt.api.rotation.EasingType
import org.cobalt.api.rotation.RotationExecutor
import org.cobalt.api.rotation.strategy.TimedEaseStrategy
import org.cobalt.api.util.AngleUtils
import org.cobalt.api.util.ChatUtils
import org.cobalt.api.util.InventoryUtils
import org.cobalt.api.util.MouseUtils
import org.cobalt.api.util.getLoreLines
import org.cobalt.api.util.helper.Rotation
import org.cobalt.api.util.render.Render3D
import org.cobalt.api.pathfinder.minecraft.MinecraftPathingRules
import org.cobalt.internal.helper.Config
import org.cobalt.api.pathfinder.jni.MovementProfile
import org.cobalt.api.pathfinder.jni.NativePathfinder
import org.cobalt.api.pathfinder.jni.PathStatus
import org.cobalt.api.util.player.MovementManager
import org.cobalt.internal.pathfinding.PathfindingModule
import org.cobalt.internal.helper.WalkbackBridge
import org.cobalt.internal.rotation.RotationsModule
import org.cobalt.internal.ui.hud.WalkbackRoutePickerPopup
import org.cobalt.internal.ui.panel.panels.UICombatWalkbackRoutesPanel
import org.cobalt.internal.ui.panel.panels.UIModuleList

object CombatMacroModule : Module("Combat Macro") {

  private val mc: Minecraft = Minecraft.getInstance()
  private val rotationStrategy = object : IRotationStrategy {
    private var sampledYawStep = 0f
    private var sampledPitchStep = 0f
    private var lastSampleNs = 0L
    private var lastRotateNs = 0L
    private var lastTargetYaw = Float.NaN
    private var lastTargetPitch = Float.NaN

    // Slow-varying aim drift — replaces the removed per-tick Math.random() jitter in
    // AngleUtils.getRotation(Entity). A human's hand naturally drifts a small amount
    // around the aim point in a correlated (smooth) way, not as white noise every tick.
    private var driftYaw = 0f
    private var driftPitch = 0f
    private var driftYawTarget = 0f
    private var driftPitchTarget = 0f
    private var lastDriftNs = 0L

    override fun onStart() {
      sampledYawStep = 0f
      sampledPitchStep = 0f
      lastSampleNs = 0L
      lastRotateNs = 0L
      lastTargetYaw = Float.NaN
      lastTargetPitch = Float.NaN
      driftYaw = 0f
      driftPitch = 0f
      driftYawTarget = 0f
      driftPitchTarget = 0f
      lastDriftNs = 0L
      refreshSamples(0f, 0f, force = true)
    }

    override fun onStop() {
      lastRotateNs = 0L
      lastTargetYaw = Float.NaN
      lastTargetPitch = Float.NaN
    }

    private fun updateDrift(nowNs: Long) {
      if (lastDriftNs == 0L || nowNs - lastDriftNs > 550_000_000L) {
        driftYawTarget = (Math.random().toFloat() - 0.5f) * 0.30f   // ±0.15°
        driftPitchTarget = (Math.random().toFloat() - 0.5f) * 0.40f // ±0.20°
        lastDriftNs = nowNs
      }
      // Smooth approach: reaches target in ~15 ticks, giving correlated drift
      driftYaw += (driftYawTarget - driftYaw) * 0.06f
      driftPitch += (driftPitchTarget - driftPitch) * 0.06f
    }

    override fun onRotate(player: LocalPlayer, targetYaw: Float, targetPitch: Float): Rotation {
      refreshSamples(targetYaw, targetPitch)

      val frameScale = currentFrameScale()
      val effectiveCurveIn = RotationsModule.bezierCurveIn.value.toFloat()
      val effectiveCurveOut = RotationsModule.bezierCurveOut.value.toFloat()
      val effectiveMinScale = RotationsModule.bezierMinScale.value.toFloat()
      val effectiveSnap = RotationsModule.bezierSnapThreshold.value.toFloat().coerceAtMost(COMBAT_MAX_SNAP_THRESHOLD)

      val yawDelta = AngleUtils.getRotationDelta(player.yRot, targetYaw)
      val pitchDelta = targetPitch - player.xRot
      val angularScale = stepScaleForDelta(abs(yawDelta), abs(pitchDelta))
      val nextYaw =
        player.yRot + smoothStep(
          yawDelta,
          sampledYawStep * frameScale * angularScale,
          effectiveCurveIn,
          effectiveCurveOut,
          effectiveMinScale,
          effectiveSnap,
        )
      val nextPitch =
        (
          player.xRot + smoothStep(
            pitchDelta,
            sampledPitchStep * frameScale * angularScale,
            effectiveCurveIn,
            effectiveCurveOut,
            effectiveMinScale,
            effectiveSnap,
          )
          ).coerceIn(-90f, 90f)

      updateDrift(System.nanoTime())
      return Rotation(nextYaw + driftYaw, (nextPitch + driftPitch).coerceIn(-90f, 90f))
    }

    private fun refreshSamples(targetYaw: Float, targetPitch: Float, force: Boolean = false) {
      val now = System.nanoTime()
      val targetShifted =
        lastTargetYaw.isNaN() ||
          abs(AngleUtils.getRotationDelta(lastTargetYaw, targetYaw)) >= COMBAT_ROTATION_RESEED_YAW ||
          abs(targetPitch - lastTargetPitch) >= COMBAT_ROTATION_RESEED_PITCH
      if (force || lastSampleNs == 0L || now - lastSampleNs >= COMBAT_ROTATION_SAMPLE_NS || targetShifted) {
        sampledYawStep = (RotationsModule.sample(RotationsModule.combatYawStep.value) * COMBAT_ROTATION_STEP_SCALE).toFloat()
        sampledPitchStep = (RotationsModule.sample(RotationsModule.combatPitchStep.value) * COMBAT_ROTATION_STEP_SCALE).toFloat()
        lastSampleNs = now
      }
      lastTargetYaw = targetYaw
      lastTargetPitch = targetPitch
    }

    private fun currentFrameScale(): Float {
      val now = System.nanoTime()
      val dt =
        if (lastRotateNs == 0L) {
          1f / COMBAT_ROTATION_BASE_HZ
        } else {
          ((now - lastRotateNs) / 1_000_000_000.0f).coerceIn(1f / 240f, 0.1f)
        }
      lastRotateNs = now
      return (dt * COMBAT_ROTATION_BASE_HZ).coerceIn(COMBAT_ROTATION_MIN_FRAME_SCALE, COMBAT_ROTATION_MAX_FRAME_SCALE)
    }

    private fun stepScaleForDelta(yawDelta: Float, pitchDelta: Float): Float {
      val maxDelta = max(yawDelta, pitchDelta)
      return (0.42f + (maxDelta / 65f).coerceIn(0f, 1f) * 0.58f)
    }

    private fun smoothStep(
      delta: Float,
      maxStep: Float,
      curveIn: Float,
      curveOut: Float,
      minScale: Float,
      snapThreshold: Float,
    ): Float {
      val absDelta = abs(delta)
      if (absDelta < snapThreshold) {
        return delta
      }
      val safeMaxStep = maxStep.coerceAtLeast(0.01f)
      val stepLimit = min(absDelta, safeMaxStep)
      val t = (absDelta / safeMaxStep).coerceIn(0f, 1f)
      val eased = cubicBezier(t, curveIn, curveOut)
      val scale = minScale + (1f - minScale) * eased
      val step = stepLimit * scale
      return if (delta < 0f) -step else step
    }

    private fun cubicBezier(t: Float, p1: Float, p2: Float): Float {
      val inv = 1f - t
      return (3f * inv * inv * t * p1) + (3f * inv * t * t * p2) + (t * t * t)
    }
  }
  private val builtInBlacklistedNames = setOf(
    "blacksmith",
    "click",
    "knifethrower",
    "toolsmith",
    "gimley",
    "hornum",
    "brynmor",
    "forge foreman",
    "fred",
    "sargwyn",
    "tarwen",
    "pdp2ut6lwf",
    "95j67t0hlr",
    "u07nk5sfh6",
    "12r7qltkkd",
    "lumina",
    "armor stand",
    "gjthi54bdc",
    "fragilis",
    "m68691nsos",
    "gemstone grinder",
    "geo",
    "4ud6865lsx",
    "crystal hollows",
    "gwendolyn",
    "emissary braum",
    "8s3f5ek78w",
    "lqf888h37w",
    "thormyr",
    "emmor",
    "08481rzc37",
    "5h260k1i05",
    "grandan",
    "5m965eru09",
    "emkam",
    "queen mismyla",
    "75576yv62m",
    "v4v8vjd7g8",
    "erren",
    "redros",
    "v7245ab06o",
    "zto57x66p5",
    "tornora",
    "leg1xn0us7",
    "castle guard",
    "i2ztjr35j6",
    "j4bjv2gi6i",
    "465awyh20w",
    "42toq9l273",
    "ticket master",
    "witches stew",
    "alcina",
    "witch",
    "6en215sve0",
    "bylma",
    "4yd3iv3sk7",
    "marigold",
    "gold essence shop",
    "l15l66bsyx",
    "emissary wilson",
    "3nba7e0ea6",
    "rat"
  )

  private val enabled = CheckboxSetting(
    "Enabled",
    "Pathfind to a target and attack until stopped.",
    false
  )

  private val toggleKeybind = KeyBindSetting(
    "Toggle Keybind",
    "Key to start/stop the combat macro.",
    KeyBind(-1)
  )

  private val slayerToggleKeybind = KeyBindSetting(
    "Slayer Toggle Keybind",
    "Key to start/stop the slayer macro.",
    KeyBind(-1)
  )

  private val info = InfoSetting(
    "Target",
    "Set a target name (partial match). Leave blank to target nearest mob.",
    InfoType.INFO
  )

  private val targetName = TextSetting(
    "Target Name",
    "Entity name to target (partial match).",
    ""
  )

  private val cryptZombieSlayer = CheckboxSetting(
    "Crypt Zombie Slayer",
    "Crypt Slayer flow: farm zombies/ghouls until Slayer boss is detected in tab, then focus boss.",
    false
  )

  private val slayerStatus = TextSetting(
    "Slayer Status",
    "Current Crypt Slayer state.",
    "Off"
  )

  private val slayerType = ModeSetting(
    "Slayer Type",
    "Which slayer quest type to run.",
    0,
    arrayOf("Zombie", "Wolf", "Spider", "Enderman", "Vampire", "Blaze")
  )

  private val slayerTier = SliderSetting(
    "Slayer Tier",
    "Quest tier to buy (1 = cheapest, 5 = hardest).",
    1.0,
    1.0,
    5.0,
    step = 1.0
  )

  private val slayerAutoWarp = CheckboxSetting(
    "Auto Warp",
    "Warp to the farming area after buying a new quest.",
    true
  )

  private val slayerLocation = ModeSetting(
    "Zombie Location",
    "Farming location for Zombie Slayer.",
    0,
    arrayOf("Zombie Graveyard", "Zombie Crypt")
  )

  private val wolfLocation = ModeSetting(
    "Wolf Location",
    "Farming location for Wolf Slayer.",
    0,
    arrayOf("Park", "Caves", "Castle")
  )

  private val spiderLocation = ModeSetting(
    "Spider Location",
    "Farming location for Spider Slayer.",
    0,
    arrayOf("Spider's Den", "Crimson Isle")
  )

  private val endermanLocation = ModeSetting(
    "Enderman Location",
    "Farming location for Enderman Slayer.",
    0,
    arrayOf("The End", "Hideout", "Void Sepulchre")
  )

  private val endermanVoidWarp = CheckboxSetting(
    "Warp To Void",
    "Run /warp void when starting Enderman Slayer at Void Sepulchre.",
    true
  )

  private val vampireLocation = ModeSetting(
    "Vampire Location",
    "Farming location for Vampire Slayer.",
    0,
    arrayOf("Wyld Woods")
  )

  private val blazeLocation = ModeSetting(
    "Blaze Location",
    "Farming location for Blaze Slayer.",
    0,
    arrayOf("Blazing Fortress")
  )

  private val slayerBossNotification = CheckboxSetting(
    "Boss Spawn Notification",
    "Show a HUD warning when the slayer boss spawns.",
    true
  )

  private val slayerBossEsp = CheckboxSetting(
    "Boss / MiniBoss ESP",
    "Highlight slayer bosses and minibosses while the slayer macro is active.",
    true
  )

  private val slayerEspTargets = ModeSetting(
    "ESP Targets",
    "Choose whether the slayer ESP highlights bosses, minibosses, or both.",
    2,
    arrayOf("Boss", "MiniBoss", "Both")
  )

  // Per-type walkback route backing settings (persisted; not rendered directly — shown via action buttons below)
  private val slayerEspStyle = ModeSetting(
    "ESP Style",
    "Glow uses the vanilla-style mob outline. Box keeps the older layered box ESP.",
    0,
    arrayOf("Glow", "Box")
  )

  private val slayerOwnBossOnly = CheckboxSetting(
    "Own Boss Only",
    "Only highlight your own slayer boss when ownership text is available.",
    true
  )

  private val slayerHighlightMiniBosses = CheckboxSetting(
    "Highlight MiniBosses",
    "Highlight slayer minibosses in addition to the main boss.",
    true
  )

  private val slayerBossEspColor = ColorSetting(
    "Boss Color",
    "Outline color used for the slayer boss.",
    0xFFFFFFFF.toInt()
  )

  private val slayerMiniBossEspColor = ColorSetting(
    "MiniBoss Color",
    "Outline color used for standard slayer minibosses.",
    0xFFFFFFFF.toInt()
  )

  private val slayerHighTierMiniEspColor = ColorSetting(
    "High Tier Mini Color",
    "Outline color used for higher-tier slayer minibosses.",
    0xFFFFD966.toInt()
  )

  private val slayerBlazeAttunementColors = CheckboxSetting(
    "Blaze Attunement Color",
    "Color Blaze Slayer outlines by attunement instead of the generic ESP colors.",
    true
  )

  private val zombieWalkbackRoute   = TextSetting("Zombie Walkback Route",   "", "")
  private val wolfWalkbackRoute     = TextSetting("Wolf Walkback Route",     "", "")
  private val spiderWalkbackRoute   = TextSetting("Spider Walkback Route",   "", "")
  private val endermanWalkbackRoute = TextSetting("Enderman Walkback Route", "", "")
  private val vampireWalkbackRoute  = TextSetting("Vampire Walkback Route",  "", "")
  private val blazeWalkbackRoute    = TextSetting("Blaze Walkback Route",    "", "")

  private fun walkbackRouteForType(type: Int): TextSetting = when (type) {
    0 -> zombieWalkbackRoute
    1 -> wolfWalkbackRoute
    2 -> spiderWalkbackRoute
    3 -> endermanWalkbackRoute
    4 -> vampireWalkbackRoute
    5 -> blazeWalkbackRoute
    else -> zombieWalkbackRoute
  }

  private fun walkbackRouteTypeName(type: Int): String = when (type) {
    0 -> "Zombie"
    1 -> "Wolf"
    2 -> "Spider"
    3 -> "Enderman"
    4 -> "Vampire"
    5 -> "Blaze"
    else -> "Zombie"
  }

  /** Returns the backing TextSetting for the currently selected slayer type. */
  private fun walkbackRouteForCurrentType(): TextSetting = walkbackRouteForType(slayerType.value)

  fun getSelectedSlayerType(): Int = slayerType.value

  fun getWalkbackRouteLabelForType(type: Int): String = "${walkbackRouteTypeName(type)} Walkback Route"

  fun getWalkbackRouteNameForType(type: Int): String = walkbackRouteForType(type).value.ifBlank { "None" }

  fun setWalkbackRouteNameForType(type: Int, routeName: String) {
    walkbackRouteForType(type).value = routeName
  }

  fun openWalkbackRoutePickerForType(type: Int) {
    if (UICombatWalkbackRoutesPanel.showPicker(type)) {
      return
    }
    WalkbackRoutePickerPopup.open(walkbackRouteTypeName(type), walkbackRouteForType(type))
  }

  // Per-type walkback route action buttons (open route picker popup)
  private val zombieWalkbackAction = ActionSetting(
    "Zombie Walkback Route", "Route to follow back to the zombie farming area after boss kill.",
    "None", { zombieWalkbackRoute.value.ifBlank { "None" } }
  ) { openWalkbackRoutePickerForType(0) }
  private val wolfWalkbackAction = ActionSetting(
    "Wolf Walkback Route", "Route to follow back to the wolf farming area after boss kill.",
    "None", { wolfWalkbackRoute.value.ifBlank { "None" } }
  ) { openWalkbackRoutePickerForType(1) }
  private val spiderWalkbackAction = ActionSetting(
    "Spider Walkback Route", "Route to follow back to the spider farming area after boss kill.",
    "None", { spiderWalkbackRoute.value.ifBlank { "None" } }
  ) { openWalkbackRoutePickerForType(2) }
  private val endermanWalkbackAction = ActionSetting(
    "Enderman Walkback Route", "Route to follow back to the enderman farming area after boss kill.",
    "None", { endermanWalkbackRoute.value.ifBlank { "None" } }
  ) { openWalkbackRoutePickerForType(3) }
  private val vampireWalkbackAction = ActionSetting(
    "Vampire Walkback Route", "Route to follow back to the vampire farming area after boss kill.",
    "None", { vampireWalkbackRoute.value.ifBlank { "None" } }
  ) { openWalkbackRoutePickerForType(4) }
  private val blazeWalkbackAction = ActionSetting(
    "Blaze Walkback Route", "Route to follow back to the blaze farming area after boss kill.",
    "None", { blazeWalkbackRoute.value.ifBlank { "None" } }
  ) { openWalkbackRoutePickerForType(5) }

  // -- Patrol settings (mirror of Combat Patrol module, settable from slayer tab) ---------------
  private val patrolRouteNameProxy = TextSetting(
    "Patrol Route",
    "Patrol route name. Shared with the Combat Patrol module.",
    CombatPatrolModule.routeName.value
  )
  private val patrolLoadAction = ActionSetting("Load Patrol Route", "Load the patrol route by name.", "Load") {
    CombatPatrolModule.routeName.value = patrolRouteNameProxy.value
    CombatPatrolModule.loadRoute()
  }
  private val patrolSaveAction = ActionSetting("Save Patrol Route", "Save the current patrol route.", "Save") {
    CombatPatrolModule.routeName.value = patrolRouteNameProxy.value
    CombatPatrolModule.saveRoute()
  }
  private val patrolStartAction = ActionSetting("Start Patrol", "Start patrol immediately.", "Start") {
    CombatPatrolModule.routeName.value = patrolRouteNameProxy.value
    CombatPatrolModule.startPatrol()
  }
  private val patrolStopAction = ActionSetting("Stop Patrol", "Stop the running patrol.", "Stop") {
    CombatPatrolModule.stopPatrol()
  }

  private val searchRange = SliderSetting(
    "Search Range",
    "Max distance to search for targets.",
    32.0,
    8.0,
    96.0
  )

  private val minCps = SliderSetting(
    "Min CPS",
    "Minimum clicks per second.",
    6.0,
    1.0,
    20.0
  )

  private val maxCps = SliderSetting(
    "Max CPS",
    "Maximum clicks per second.",
    10.0,
    1.0,
    20.0
  )

  private val attackRange = SliderSetting(
    "Attack Range",
    "Distance to start attacking.",
    3.2,
    2.0,
    6.0
  )

  private val chaseStopBuffer = SliderSetting(
    "Chase Stop Buffer",
    "Stop pathing this far before attack range to reduce strafe jitter.",
    1.1,
    0.0,
    3.0
  )

  private val stayNearStart = CheckboxSetting(
    "Stay Near Start",
    "Keep combat inside the general area where macro was enabled.",
    true
  )

  private val startAreaRadius = SliderSetting(
    "Start Area Radius",
    "Max horizontal distance from start area for combat targets.",
    24.0,
    8.0,
    96.0
  )

  private val autoHeal = CheckboxSetting(
    "Auto Heal",
    "Auto-use a healing item when health is low.",
    true
  )

  private val autoWandOfAtonement = CheckboxSetting(
    "Wand Of Atonement",
    "Use Wand of Atonement for auto-heal. Auto-enables when the item is detected in hotbar.",
    false
  )

  private val alwaysUseWandOfAtonement = CheckboxSetting(
    "Always Use Wand Of Atonement",
    "Use Wand of Atonement every 7 seconds while the combat macro is running.",
    false
  )

  private val autoZombieSword = CheckboxSetting(
    "Zombie Sword",
    "Use Zombie Sword variants for auto-heal. Auto-enables when the item is detected in hotbar.",
    false
  )

  private val autoHyperion = CheckboxSetting(
    "Hyperion",
    "Use Hyperion and other Wither blades for auto-heal. Auto-enables when one is detected in hotbar.",
    false
  )

  private val autoOverflux = CheckboxSetting(
    "Overflux",
    "Use Overflux when the Slayer boss spawns. Auto-enables when the item is detected in hotbar.",
    false
  )

  private val autoRagnarok = CheckboxSetting(
    "Ragnarok",
    "Use Ragnarok when the Slayer boss spawns. Auto-enables when the item is detected in hotbar.",
    false
  )

  private val autoReaperScythe = CheckboxSetting(
    "Reaper Scythe",
    "Use Reaper Scythe once when the Slayer boss is active. Auto-enables when the item is detected in hotbar.",
    false
  )

  private val oneTapMode = CheckboxSetting(
    "One Tap Mode",
    "Keep moving through mobs - don't stop at each kill. Switch immediately when target dies.",
    false
  )

  private val combatMode = ModeSetting(
    "Combat Mode",
    "Melee: left-click. Bow: right-click ranged with drop aim. Mage: right-click projectile with lead aim.",
    0,
    arrayOf("Melee", "Bow", "Mage")
  )

  private val zombieDynamicCombat = CheckboxSetting(
    "Zombie Auto Swap",
    "Zombie Slayer only: use the spawn weapon while farming, then swap to Dynamic Sword for the boss.",
    true
  )

  private val zombieSpawnWeapon = TextSetting(
    "Zombie Spawn Weapon",
    "Comma-separated hotbar keywords for the zombie spawn weapon. Used before the boss spawns.",
    "halberd"
  )

  private val zombieDynamicSword = TextSetting(
    "Dynamic Sword",
    "Comma-separated hotbar keywords for the zombie boss weapon.",
    "falchion, reaper, shredded, sword"
  )

  private val endermanDynamicCombat = CheckboxSetting(
    "Eman Auto Swap",
    "Enderman Slayer only: use bow for spawn farming and hit-shield phases, then swap to melee for boss DPS phases.",
    true
  )

  private val emanSpawnWeapon = ModeSetting(
    "Eman Spawn Weapon",
    "Choose the weapon style for Enderman Slayer spawn farming before the boss appears.",
    3,
    arrayOf("Terminator", "Shortbow", "Enderman Slayer Sword", "Dynamic")
  )

  private val emanDynamicSwapRange = SliderSetting(
    "Eman Dynamic Swap Range",
    "Enderman Slayer only: in Dynamic spawn mode, switch from bow to sword when the target is within this distance.",
    4.5,
    2.0,
    8.0,
    step = 0.1
  )

  private val emanHitPhaseStyle = ModeSetting(
    "Eman Hit Phase Style",
    "Choose the weapon style for Enderman Slayer hit-shield phases.",
    EMAN_HIT_PHASE_WEAPON_TERMINATOR,
    arrayOf("Shortbow", "Terminator", "End Slayer Sword")
  )

  private val emanHitPhaseSneakWhenHitting = CheckboxSetting(
    "Sneak When Hitting",
    "Hold sneak while attacking Enderman Slayer hit-shield phases.",
    false
  )

  private val emanBossWeapon = TextSetting(
    "Eman Boss Weapon",
    "Comma-separated hotbar keywords for Enderman Slayer boss DPS phases.",
    "atomsplit, vorpal, voidedge, katana"
  )

  private val spiderPhaseBowCombat = CheckboxSetting(
    "Spider Hatchling Phase",
    "Spider Slayer only: when the boss becomes invulnerable, step back and use bow mode on nearby hatchlings.",
    true
  )

  private val wolfIgnorePups = CheckboxSetting(
    "Ignore Wolf Pups",
    "Wolf Slayer only: during the pups phase, keep tracking the boss instead of retargeting the pups.",
    false
  )

  private val sepZombie = InfoSetting("Zombie", "", InfoType.SEPARATOR)
  private val sepEnderman = InfoSetting("Enderman", "", InfoType.SEPARATOR)
  private val sepSpider = InfoSetting("Spider", "", InfoType.SEPARATOR)
  private val sepWolf = InfoSetting("Wolf", "", InfoType.SEPARATOR)
  private val sepVampire = InfoSetting("Vampire", "", InfoType.SEPARATOR)
  private val sepBlaze = InfoSetting("Blaze", "", InfoType.SEPARATOR)

  private val swordKeepDistance = SliderSetting(
    "Sword Keep Distance",
    "Preferred stand-off distance in melee mode. Lower = closer. 0 = close in fully.",
    1.8,
    0.0,
    6.0,
    step = 0.1
  )

  private val slayerSwordKeepDistance = SliderSetting(
    "Slayer Sword Keep Distance",
    "Preferred stand-off distance in melee mode while the Slayer macro is active. Lower = closer. 0 = close in fully.",
    0.0,
    0.0,
    6.0,
    step = 0.1
  )

  private val bowMinRange = SliderSetting(
    "Bow Min Range",
    "Preferred stand-off distance in bow mode. 0 = use Attack Range.",
    8.0,
    0.0,
    20.0
  )

  private val bowElevationPerBlock = SliderSetting(
    "Bow Elevation /block",
    "Degrees to aim upward per block of distance to compensate for arrow drop. Tune to your bow.",
    0.15,
    0.0,
    1.0,
    step = 0.01
  )

  private val mageElevationPerBlock = SliderSetting(
    "Mage Elevation /block",
    "Degrees to aim upward per block of distance for slower projectiles. 0 for instant/no-drop weapons.",
    0.0,
    0.0,
    1.0,
    step = 0.01
  )

  private val autoSwordOfBadHealth = CheckboxSetting(
    "Sword Of Bad Health",
    "Use Sword of Bad Health during the Slayer boss fight. Auto-enables when the item is detected in hotbar.",
    false
  )

  private val healAtHealth = SliderSetting(
    "Heal At Health",
    "Use heal item at or below this health.",
    10.0,
    1.0,
    20.0
  )

  private val stuckTicksSetting = SliderSetting(
    "Stuck Ticks",
    "Ticks without movement before warp hub.",
    80.0,
    20.0,
    200.0
  )

  private val warpOnStuck = CheckboxSetting(
    "Warp Hub On Stuck",
    "Warp to hub if stuck while macro is active.",
    true
  )

  private val requireLos = CheckboxSetting(
    "Require LOS",
    "Only attack when you have line of sight.",
    true
  )


  private val aimTolerance = SliderSetting(
    "Aim Tolerance",
    "Max yaw/pitch error before attacking.",
    15.0,
    4.0,
    45.0
  )

  private val minAttackCooldown = SliderSetting(
    "Min Attack Cooldown",
    "Minimum vanilla cooldown needed before an attack.",
    0.2,
    0.0,
    1.0
  )

  private val stuckRepathTries = SliderSetting(
    "Stuck Repath Tries",
    "Repath attempts before optional hub warp.",
    2.0,
    0.0,
    8.0
  )

  private val autoLearnLastKill = CheckboxSetting(
    "Auto Learn Last Kill",
    "Set last killed enemy as target and whitelist entry.",
    true
  )

  private val whitelistOnly = CheckboxSetting(
    "Whitelist Only",
    "Only target entities matching learned whitelist names.",
    true
  )

  private val learnedWhitelistText = TextSetting(
    "Learned Whitelist",
    "Auto-learned target names from kills.",
    "EMPTY"
  )

  private val lastKillText = TextSetting(
    "Last Kill",
    "Most recently learned enemy name.",
    "-"
  )

  val isActive: Boolean get() = enabled.value
  val isRunning: Boolean get() = enabled.value
  val isSlayerHudVisible: Boolean get() = cryptZombieSlayer.value || slayerModeEnabled
  val modeDisplay: String get() = combatModeDisplayName(currentHudCombatMode())
  val slayerDisplay: String get() = if (cryptZombieSlayer.value) slayerStatus.value else "Disabled"
  val slayerQuestLevelDisplay: String
    get() = if (!isSlayerHudVisible) "--" else trackedSlayerQuestLabel()
  val slayerQuestStateDisplay: String
    get() = if (!isSlayerHudVisible) "--" else trackedSlayerQuestHudStageLabel()
  val slayerKillsLeftDisplay: String
    get() = if (!isSlayerHudVisible) "--" else (currentSlayerKillsLeft()?.toString() ?: "--")
  val slayerKillsPerHourDisplay: String
    get() = if (!isSlayerHudVisible) "--" else formatSessionRateDisplay(slayerSessionMobKills)
  val slayerQuestsCompletedDisplay: String
    get() = if (!isSlayerHudVisible) "--" else slayerSessionQuestCompletions.toString()
  val slayerQuestsPerHourDisplay: String
    get() = if (!isSlayerHudVisible) "--" else formatSessionRateDisplay(slayerSessionQuestCompletions)
  val slayerQuestsFailedDisplay: String
    get() = if (!isSlayerHudVisible) "--" else slayerSessionQuestFailures.toString()
  val slayerQuestFailsPerHourDisplay: String
    get() = if (!isSlayerHudVisible) "--" else formatSessionRateDisplay(slayerSessionQuestFailures)
  val statusDisplay: String
    get() =
      when {
        !enabled.value -> "Off"
        cryptZombieSlayer.value -> slayerStatus.value
        currentTargetId != null && startedPath && nativeActive() -> "Pathing To Target"
        currentTargetId != null -> "Engaging Target"
        startedPath && nativeActive() -> "Pathing"
        else -> "Searching"
      }
  val targetDisplay: String
    get() {
      val activeTargetName = resolveCurrentTargetName()
      if (!activeTargetName.isNullOrBlank()) {
        return activeTargetName
      }
      if (cryptZombieSlayer.value) {
        if (slayerBossActive) return "Slayer Boss"
        val activeName = resolveCurrentTargetName()
        if (!activeName.isNullOrBlank()) {
          val norm = normalizeNameForMatch(activeName)
          if (isSlayerPriorityMobName(norm)) return "\u2B50 $activeName"
        }
        return when (slayerType.value) {
          0 -> "Zombie / Ghoul"
          1 -> "Wolf"
          2 -> "Spider"
          3 -> "Voidling"
          4 -> "Vampire"
          5 -> "Blaze"
          else -> "Mob"
        }
      }
      val filter = targetName.value.trim()
      return if (filter.isNotEmpty()) filter else "Nearest Mob"
    }
  val targetHealthDisplay: String
    get() {
      val target = resolveCurrentTarget() ?: return "-- / --"
      return "${formatHudHealth(target.health)} / ${formatHudHealth(target.maxHealth)}"
    }
  val targetHealthRatio: Float
    get() {
      val target = resolveCurrentTarget() ?: return 0f
      val maxHealth = target.maxHealth.coerceAtLeast(1f)
      return (target.health.coerceAtLeast(0f) / maxHealth).coerceIn(0f, 1f)
    }

  private fun currentHudCombatMode(): Int {
    val target = resolveCurrentTarget()
    if (target != null) return effectiveCombatMode(target)
    if (!cryptZombieSlayer.value) return combatMode.value
    return fallbackSlayerCombatModeForHud()
  }

  private fun fallbackSlayerCombatModeForHud(): Int {
    if (shouldUseSpiderPhaseBowCombat() && slayerBossActive && isSpiderBossHatchlingsPhaseActive()) {
      return 1
    }
    if (shouldUseEndermanDynamicCombat()) {
      val boss = resolveNearestSlayerBoss()
      if (boss != null) {
        return if (isEndermanBossHitPhase(boss)) effectiveEndermanHitPhaseCombatMode() else 0
      }
      return when (emanSpawnWeapon.value) {
        EMAN_SPAWN_WEAPON_ENDERMAN_SWORD -> 0
        else -> 1
      }
    }
    return combatMode.value
  }

  private fun combatModeDisplayName(mode: Int): String =
    when (mode) {
      0 -> "Melee"
      1 -> "Bow"
      2 -> "Mage"
      else -> "Unknown"
    }

  fun startForAutomation(mobName: String) {
    cryptZombieSlayer.value = false
    targetName.value = mobName.trim()
    automationBypassWhitelist = true
    whitelistOnly.value = false
    mc.player?.takeIf { prefersDrillForTargetName(targetName.value) }?.let { player ->
      ensureWalkerDrillSelected(player, mc.level?.gameTime ?: 0L, targetName.value)
    }
    enabled.value = true
  }

  fun stopForAutomation() {
    automationBypassWhitelist = false
    enabled.value = false
  }

  fun matchesAutomationTarget(living: LivingEntity, rawTargetName: String): Boolean {
    val filter = normalizeNameForMatch(rawTargetName)
    if (filter.isBlank()) return false
    return targetMatchNames(living).any { name -> name.contains(filter) }
  }

  private var lastTargetPos: BlockPos? = null
  private var lastMoveX = 0.0
  private var lastMoveY = 0.0
  private var lastMoveZ = 0.0
  private var stuckTicks = 0
  private var nextAttackNs = 0L
  private var startedPath = false
  private var currentTargetId: UUID? = null
  private var automationBypassWhitelist = false
  private var closeChaseActive = false
  private var closeChaseTargetId: UUID? = null
  private var losScanStrafeRight = false
  private var losScanLastFlipTick = 0L
  private var lastPathStartTick = 0L
  private var killCandidateId: UUID? = null
  private var killCandidateName: String? = null
  private var killCandidateWasSlayerMob = false
  private var killCandidateWasSlayerBoss = false
  private var killCandidateExpiresTick = 0L
  private var killCandidateAttackTick = 0L
  private val learnedWhitelist = LinkedHashSet<String>()
  private var lastSyncedWhitelistRaw = ""
  private var drillWarnTick = 0L
  private var lastHealUseTick = 0L
  private var lastAlwaysWandUseTick = 0L
  private var stuckRepathCount = 0
  private var startAreaOrigin: BlockPos? = null
  private var pendingHealRelease = false
  private var pendingHealRestoreSlot = -1
  private var pendingOverfluxLookDownTicks = 0
  private var pendingOverfluxRecoverLookTicks = 0
  private var pendingOverfluxRestoreSlot = -1
  private var slayerBossActive = false
  private var slayerSessionStartMs = 0L
  private var slayerTrackedQuestActive = false
  private var slayerTrackedQuestType = -1
  private var slayerTrackedQuestTier = 0
  private var slayerTrackedQuestProgressKills = 0
  private var slayerTrackedQuestTargetKills = 0
  private var slayerTrackedQuestSawMobKill = false
  private var slayerTrackedQuestBossSeen = false
  private var slayerTrackedQuestCompletionPendingRestart = false
  private var slayerSessionMobKills = 0
  private var slayerSessionQuestCompletions = 0
  private var slayerSessionQuestFailures = 0
  private var slayerBossLastSeenTick = 0L
  private var slayerOverfluxUsedThisBoss = false
  private var slayerRagnarokUsedThisBoss = false
  private var slayerReaperScytheUsedThisBoss = false
  private var slayerLastBadHealthUseTick = -1L
  private var slayerLastOverfluxUseTick = -1L
  private var slayerLastRagnarokUseTick = -1L
  private var slayerLastReaperScytheUseTick = -1L
  private var slayerLastTabScanTick = -1L
  private var slayerTabCache: List<String> = emptyList()
  private var slayerNeedsQuestRestart = false
  private var slayerPendingTierSelection = false
  private var slayerQuestReady = false
  private var slayerRagnarokUsedPreBoss = false
  private var slayerAutoDetected = false
  private var slayerDetectStartTick = -1L
  private var slayerNeedsQuestClaim = false
  private var slayerNeedsWalkback = false
  private var slayerWalkbackJustFarm = false  // true = walkback is walk-IN to farm area (skip quest restart)
  private var slayerWalkInDelayUntilTick = -1L  // wait for warp to finish before starting walkin route
  private var slayerWalkInJustFarm = true       // justFarm value to use when the walkin-delay expires
  private var slayerDeathRespawnPending = false  // player died; trigger walkback once they respawn
  private var lastKnownLevel: net.minecraft.client.multiplayer.ClientLevel? = null  // server-switch detection
  private var slayerBossLastPos: net.minecraft.world.phys.Vec3? = null
  // Cached per-tick: entity UUID → highlight type, used by renderSlayerHighlights to avoid O(N²) per frame.
  private var slayerHighlightCache: Map<UUID, SlayerHighlightState> = emptyMap()
  private val slayerGlowingEntities = mutableMapOf<UUID, String>()
  private var slayerClaimStartTick = -1L
  private var slayerClaimLastClickTick = -1L
  private var slayerLastBatphoneAttemptTick = -1L
  private var slayerLastBatphoneUseTick = -1L
  private var slayerLastGuiActionTick = -1L
  private var slayerWarnNoBatphoneTick = -1L
  private var slayerModeEnabled = false
  private var slayerQuestStateGraceUntilTick = -1L
  private var spiderHatchlingsPhaseActive = false
  private var spiderHatchlingsPhaseUntilTick = -1L
  private var spiderHatchlingsBossId: UUID? = null
  private var spiderHatchlingsBossAnchor: net.minecraft.world.phys.Vec3? = null
  private var wolfPupsPhaseUntilTick = -1L
  /** True once the player has physically been confirmed inside the crypt since the last warp-hub.
   *  The outside-crypt recovery check only fires when this is true, preventing the startup spam
   *  loop where the player warps to hub and the check immediately re-triggers before they arrive. */
  private var slayerEnteredCrypt = false
  /** True once the player has been confirmed near a patrol point since the last macro start or walkback.
   *  Used to detect area-exit (teleport/push) and trigger walkback for non-crypt slayer types. */
  private var enteredFarmingArea = false
  private var wandWasInHotbar = false
  private var hyperionWasInHotbar = false
  private var zombieSwordWasInHotbar = false
  private var overfluxWasInHotbar = false
  private var ragnarokWasInHotbar = false
  private var reaperScytheWasInHotbar = false
  private var badHealthWasInHotbar = false
  private var emanHitPhaseBossWeaponPrimed = false
  private var emanHitPhaseSneakApplied = false
  private var emanLaserPhaseActive = false
  private var emanLaserPhaseStartTick = -1L
  private var slayerRagnarokUsedForLaserPhase = false
  private val overfluxLookDownStrategy = TimedEaseStrategy(EasingType.LINEAR, EasingType.LINEAR, 220L)

  init {
    assignSettingGroups()
      addSetting(
        enabled,
        toggleKeybind,
        info,
        targetName,
        cryptZombieSlayer,
        slayerToggleKeybind,
        slayerStatus,
        slayerType,
      slayerTier,
      slayerAutoWarp,
      slayerBossNotification,
      slayerBossEsp,
      slayerEspTargets,
      slayerEspStyle,
      slayerOwnBossOnly,
      slayerHighlightMiniBosses,
      slayerBossEspColor,
      slayerMiniBossEspColor,
      slayerHighTierMiniEspColor,
      slayerBlazeAttunementColors,
      zombieWalkbackRoute,
      wolfWalkbackRoute,
      spiderWalkbackRoute,
      endermanWalkbackRoute,
      vampireWalkbackRoute,
      blazeWalkbackRoute,
      patrolRouteNameProxy,
      patrolLoadAction,
      patrolSaveAction,
      patrolStartAction,
      patrolStopAction,
      searchRange,
      minCps,
      maxCps,
      attackRange,
      chaseStopBuffer,
      stayNearStart,
      startAreaRadius,
      oneTapMode,
      combatMode,
      sepZombie,
      slayerLocation,
      zombieWalkbackAction,
      zombieDynamicCombat,
      zombieSpawnWeapon,
      zombieDynamicSword,
      sepEnderman,
      endermanLocation,
      endermanVoidWarp,
      endermanWalkbackAction,
      endermanDynamicCombat,
      emanSpawnWeapon,
      emanDynamicSwapRange,
      emanHitPhaseStyle,
      autoReaperScythe,
      emanHitPhaseSneakWhenHitting,
      emanBossWeapon,
      sepSpider,
      spiderLocation,
      spiderWalkbackAction,
      spiderPhaseBowCombat,
      sepWolf,
      wolfLocation,
      wolfWalkbackAction,
      wolfIgnorePups,
      sepVampire,
      vampireLocation,
      vampireWalkbackAction,
      sepBlaze,
      blazeLocation,
      blazeWalkbackAction,
      swordKeepDistance,
      slayerSwordKeepDistance,
      bowMinRange,
      bowElevationPerBlock,
      mageElevationPerBlock,
      autoHeal,
      autoWandOfAtonement,
      alwaysUseWandOfAtonement,
      autoZombieSword,
      autoHyperion,
      autoOverflux,
      autoRagnarok,
      autoSwordOfBadHealth,
      healAtHealth,
      stuckTicksSetting,
      warpOnStuck,
      requireLos,
      aimTolerance,
      minAttackCooldown,
      stuckRepathTries,
      autoLearnLastKill,
      whitelistOnly,
      learnedWhitelistText,
      lastKillText
    )
    EventBus.register(this)
    EventBus.register(WalkbackRoutePickerPopup)
  }

  private fun assignSettingGroups() {
    // General — enable, targeting, area constraints, whitelist
    enabled.inGroup(TAB_COMBAT_GROUP)
    toggleKeybind.inGroup(TAB_COMBAT_GROUP)
    info.inGroup(TAB_COMBAT_GROUP)
    targetName.inGroup(TAB_COMBAT_GROUP)
    searchRange.inGroup(TAB_COMBAT_GROUP)
    stayNearStart.inGroup(TAB_COMBAT_GROUP)
    startAreaRadius.inGroup(TAB_COMBAT_GROUP)
    requireLos.inGroup(TAB_COMBAT_GROUP)
    autoLearnLastKill.inGroup(TAB_COMBAT_GROUP)
    whitelistOnly.inGroup(TAB_COMBAT_GROUP)
    learnedWhitelistText.inGroup(TAB_COMBAT_GROUP)
    lastKillText.inGroup(TAB_COMBAT_GROUP)

    // Combat — attack behavior, timing, movement, stuck handling
    combatMode.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    minCps.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    maxCps.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    attackRange.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    chaseStopBuffer.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    aimTolerance.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    minAttackCooldown.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    oneTapMode.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    swordKeepDistance.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    bowMinRange.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    bowElevationPerBlock.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    mageElevationPerBlock.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    stuckTicksSetting.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    warpOnStuck.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)
    stuckRepathTries.inGroup(TAB_COMBAT_BEHAVIOR_GROUP)

    // Slayer — quest settings, boss options
    cryptZombieSlayer.inGroup(TAB_SLAYER_GROUP)
    slayerToggleKeybind.inGroup(TAB_SLAYER_GROUP)
    slayerStatus.inGroup(TAB_SLAYER_GROUP)
    slayerType.inGroup(TAB_SLAYER_GROUP)
    slayerTier.inGroup(TAB_SLAYER_GROUP)
    slayerAutoWarp.inGroup(TAB_SLAYER_GROUP)
    slayerSwordKeepDistance.inGroup(TAB_SLAYER_GROUP)
    slayerBossNotification.inGroup(TAB_SLAYER_GROUP)
    slayerBossEsp.inGroup(TAB_SLAYER_GROUP)
    slayerEspTargets.inGroup(TAB_SLAYER_GROUP)
    slayerEspStyle.inGroup(TAB_SLAYER_GROUP)
    slayerOwnBossOnly.inGroup(TAB_SLAYER_GROUP)
    slayerHighlightMiniBosses.inGroup(TAB_SLAYER_GROUP)
    slayerBossEspColor.inGroup(TAB_SLAYER_GROUP)
    slayerMiniBossEspColor.inGroup(TAB_SLAYER_GROUP)
    slayerHighTierMiniEspColor.inGroup(TAB_SLAYER_GROUP)
    slayerBlazeAttunementColors.inGroup(TAB_SLAYER_GROUP)

    // Backing route settings — persisted but hidden from UI (rendered via action buttons above)
    zombieWalkbackRoute.inGroup(UIModuleList.SIDE_GROUP)
    wolfWalkbackRoute.inGroup(UIModuleList.SIDE_GROUP)
    spiderWalkbackRoute.inGroup(UIModuleList.SIDE_GROUP)
    endermanWalkbackRoute.inGroup(UIModuleList.SIDE_GROUP)
    vampireWalkbackRoute.inGroup(UIModuleList.SIDE_GROUP)
    blazeWalkbackRoute.inGroup(UIModuleList.SIDE_GROUP)

    // Slayer Weapons — per-type locations and weapon swap configurations
    sepZombie.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    slayerLocation.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    zombieWalkbackAction.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    zombieDynamicCombat.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    zombieSpawnWeapon.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    zombieDynamicSword.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    sepEnderman.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    endermanLocation.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    endermanVoidWarp.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    endermanWalkbackAction.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    endermanDynamicCombat.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    emanSpawnWeapon.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    emanDynamicSwapRange.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    emanHitPhaseStyle.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    autoReaperScythe.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    emanHitPhaseSneakWhenHitting.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    emanBossWeapon.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    sepSpider.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    spiderLocation.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    spiderWalkbackAction.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    spiderPhaseBowCombat.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    sepWolf.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    wolfLocation.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    wolfWalkbackAction.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    wolfIgnorePups.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    sepVampire.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    vampireLocation.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    vampireWalkbackAction.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    sepBlaze.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    blazeLocation.inGroup(TAB_SLAYER_WEAPONS_GROUP)
    blazeWalkbackAction.inGroup(TAB_SLAYER_WEAPONS_GROUP)

    // Patrol
    patrolRouteNameProxy.inGroup(TAB_PATROL_GROUP)
    patrolLoadAction.inGroup(TAB_PATROL_GROUP)
    patrolSaveAction.inGroup(TAB_PATROL_GROUP)
    patrolStartAction.inGroup(TAB_PATROL_GROUP)
    patrolStopAction.inGroup(TAB_PATROL_GROUP)

    // Auto Items
    autoHeal.inGroup(TAB_AUTO_ITEMS_GROUP)
    autoWandOfAtonement.inGroup(TAB_AUTO_ITEMS_GROUP)
    alwaysUseWandOfAtonement.inGroup(TAB_AUTO_ITEMS_GROUP)
    autoZombieSword.inGroup(TAB_AUTO_ITEMS_GROUP)
    autoHyperion.inGroup(TAB_AUTO_ITEMS_GROUP)
    autoOverflux.inGroup(TAB_AUTO_ITEMS_GROUP)
    autoRagnarok.inGroup(TAB_AUTO_ITEMS_GROUP)
    autoSwordOfBadHealth.inGroup(TAB_AUTO_ITEMS_GROUP)
    healAtHealth.inGroup(TAB_AUTO_ITEMS_GROUP)
  }

  @SubscribeEvent
  fun onTick(@Suppress("UNUSED_PARAMETER") event: TickEvent.Start) {
    if (toggleKeybind.value.isPressed()) {
      enabled.value = !enabled.value
    }
    if (slayerToggleKeybind.value.isPressed()) {
      cryptZombieSlayer.value = !cryptZombieSlayer.value
    }

    // Server-switch detection: if level instance changes while macro is active, stop pathfinding
    // and queue a walkback so the player returns to the farming area on reconnect.
    val currentLevel = mc.level
    if (currentLevel !== lastKnownLevel) {
      clearSlayerGlowState(lastKnownLevel)
      if (lastKnownLevel != null && (enabled.value || slayerModeEnabled)) {
        val wasSlayerActive = slayerModeEnabled
        val hasWalkbackRoute = walkbackRouteForCurrentType().value.isNotBlank()
        stopMacro()
        enteredFarmingArea = false
        if (wasSlayerActive && hasWalkbackRoute) {
          slayerNeedsWalkback = true
          slayerWalkbackJustFarm = false
          ChatUtils.sendMessage("Combat macro: server change detected, will walk back on reconnect.")
        } else {
          ChatUtils.sendMessage("Combat macro stopped: server change detected.")
        }
      }
      lastKnownLevel = currentLevel
    }

    // Release macro-managed keys before reevaluating combat state this tick.
    releaseEmanHitPhaseSneak()

    // Release heal key and restore slot from previous heal use
    if (pendingHealRelease) {
      mc.options.keyUse?.setDown(false)
      pendingHealRelease = false
    }
    if (pendingHealRestoreSlot >= 0) {
      InventoryUtils.holdHotbarSlot(pendingHealRestoreSlot)
      pendingHealRestoreSlot = -1
    }

    val player = mc.player ?: run {
      clearPendingOverfluxPlacement()
      return
    }
    if (pendingOverfluxLookDownTicks > 0) {
      pendingOverfluxLookDownTicks--
      MovementManager.clearForcedMovement()
      RotationExecutor.rotateTo(Rotation(player.yRot, OVERFLUX_PLACE_PITCH), overfluxLookDownStrategy)
      if (pendingOverfluxLookDownTicks <= 0) {
        RotationExecutor.stopRotating()
        mc.options.keyUse?.setDown(true)
        pendingHealRelease = true
        pendingHealRestoreSlot = pendingOverfluxRestoreSlot
        pendingOverfluxRecoverLookTicks = OVERFLUX_RECOVER_LOOK_TICKS
        pendingOverfluxRestoreSlot = -1
      }
      return
    }
    if (pendingOverfluxRecoverLookTicks > 0) {
      pendingOverfluxRecoverLookTicks--
      applyOverfluxRecoverLook(player)
    }
    syncAutoItemToggles(player)
    if (startedPath && !nativeActive()) {
      startedPath = false
      lastTargetPos = null
    }
    if (startedPath && nativeActive() && !CombatPatrolModule.patrolOwnsPathfinder && !slayerNeedsWalkback) {
      val cmd = NativePathfinder.tick()
      if (cmd != null) cmd.applyToPlayer()
      else {
        when (NativePathfinder.status) {
          PathStatus.IDLE, PathStatus.ARRIVED, PathStatus.FAILED -> MovementManager.clearForcedMovement()
          else -> Unit
        }
      }
    }
    syncLearnedWhitelistFromSetting()
    if (cryptZombieSlayer.value && !slayerModeEnabled && enabled.value) {
      slayerModeEnabled = true
      beginSlayerSession()
      beginSlayerQuestDetection(mc.level?.gameTime ?: -1L)
      slayerRagnarokUsedPreBoss = false
      slayerEnteredCrypt = false
      enteredFarmingArea = false
      slayerLastBatphoneAttemptTick = -1L
      slayerLastBatphoneUseTick = -1L
      slayerLastGuiActionTick = -1L
      // If not already in the farming area, navigate there via walkback route.
      if (slayerLocation.value == 1) {
        val initPos = mc.player?.blockPosition()
        val alreadyInCrypt = initPos != null && CRYPT_PATROL_WAYPOINTS.any { wp ->
          val dx = wp.x - initPos.x; val dz = wp.z - initPos.z
          dx * dx + dz * dz < CRYPT_PROXIMITY_RANGE_SQ
        }
        if (!alreadyInCrypt) {
          slayerEnteredCrypt = false
          triggerWalkToFarmArea(justFarm = true)
        } else {
          slayerEnteredCrypt = true
        }
      } else if (walkbackRouteForCurrentType().value.isNotBlank()) {
        // Walk to farm if player is not already there.
        // If patrol points are configured, use them for proximity; if not, assume not at farm
        // (since we can't confirm location and have a route configured, use it).
        val initPos = mc.player?.blockPosition()
        val nearFarm = initPos != null
          && CombatPatrolModule.patrolPoints.isNotEmpty()
          && CombatPatrolModule.patrolPoints.any { p ->
            val dx = p.x - initPos.x; val dz = p.z - initPos.z
            dx * dx + dz * dz < GRAVEYARD_PROXIMITY_RANGE_SQ
          }
        if (!nearFarm) triggerWalkToFarmArea(justFarm = true)
      }
    }
    if (!cryptZombieSlayer.value) {
      slayerModeEnabled = false
    }
    if (!cryptZombieSlayer.value && !automationBypassWhitelist && !whitelistOnly.value) {
      whitelistOnly.value = true
    }
    if (cryptZombieSlayer.value && whitelistOnly.value) {
      whitelistOnly.value = false
    }
    if (!enabled.value) {
      clearSlayerGlowState(currentLevel)
      stopMacro()
      return
    }

    if (!cryptZombieSlayer.value || !slayerBossEsp.value || slayerEspStyle.value != SLAYER_ESP_STYLE_GLOW) {
      clearSlayerGlowState(currentLevel)
    }

    val level = mc.level ?: return
    PathfindingModule.ensureEnabledForAutomation("combat macro")
    updateKillTracking(level)
    if (cryptZombieSlayer.value) {
      if (!slayerAutoDetected) tryAutoDetectSlayerQuest(level)
      updateSlayerBossState(level.gameTime)
      if (slayerNeedsQuestClaim) {
        if (handleClaimSlayerQuest(player, level)) return
      }
      // Warp-then-walkback delay: issued by triggerWalkToFarmArea when a pre-warp is needed
      // (e.g. spider slayer warps to den before running the walkback route).
      if (slayerWalkInDelayUntilTick >= 0L) {
        if (level.gameTime < slayerWalkInDelayUntilTick) {
          slayerStatus.value = "Warping..."
          return
        }
        slayerWalkInDelayUntilTick = -1L
        triggerWalkToFarmArea(justFarm = slayerWalkInJustFarm, skipPreWarp = true)
      }
      if (slayerNeedsWalkback) {
        // Walkback owns the pathfinder - prevent CombatMacroModule from double-ticking it.
        startedPath = false
        lastTargetPos = null
        if (WalkbackBridge.isRunning?.invoke() == true) {
          // Boss spawned during walkback - interrupt immediately and engage.
          if (slayerBossActive) {
            WalkbackBridge.stopWalkback?.invoke()
            slayerNeedsWalkback = false
            startAreaOrigin = null
            slayerStatus.value = "Boss! Engaging..."
            // fall through to combat resolution below
          } else {
            slayerStatus.value = if (slayerWalkbackJustFarm) "Walking to Farm..." else "Walking Back..."
            currentTargetId = null
          }
        } else {
          slayerNeedsWalkback = false
          startAreaOrigin = null
          // Set enteredFarmingArea based on actual proximity rather than always resetting to false.
          // Blindly clearing it here means the area-exit detection stays dead if the macro's
          // quest-restart logic blocks the per-tick proximity check for even a brief window
          // (e.g., while calling the batphone), leaving the player unrecovered if displaced.
          val walkbackEndPos = mc.player?.blockPosition()
          enteredFarmingArea = slayerLocation.value != 1
            && walkbackEndPos != null
            && CombatPatrolModule.patrolPoints.isNotEmpty()
            && CombatPatrolModule.patrolPoints.any { p ->
              val dx = p.x - walkbackEndPos.x; val dz = p.z - walkbackEndPos.z
              dx * dx + dz * dz < GRAVEYARD_PROXIMITY_RANGE_SQ
            }
          if (slayerWalkbackJustFarm) {
            slayerWalkbackJustFarm = false
            // Walkback complete - ensure quest detection runs for fresh quest
            beginSlayerQuestDetection(mc.level?.gameTime ?: -1L)
          } else {
            queueSlayerQuestRestart(countFailure = false)
          }
        }
      }
      if (handleMaddoxGui(level.gameTime)) {
        return
      }
      if (tryRestartSlayerQuest(player, level.gameTime)) {
        return
      }
      // Use Ragnarok pre-emptively when quest is ready (boss spawns on next kill)
      if (slayerQuestReady && !slayerBossActive && !slayerRagnarokUsedPreBoss && autoRagnarok.value
        && level.gameTime - slayerLastRagnarokUseTick >= SLAYER_RAGNAROK_COOLDOWN_TICKS) {
        if (useHotbarUtilityItem(player, SLAYER_RAGNAROK_KEYWORDS)) {
          slayerRagnarokUsedPreBoss = true
          slayerRagnarokUsedThisBoss = true
          slayerLastRagnarokUseTick = level.gameTime
        }
      }
    } else {
      slayerStatus.value = "Off"
      clearSlayerBossState(false)
      slayerNeedsQuestRestart = false
      slayerPendingTierSelection = false
    }

    if (player.isDeadOrDying || player.health <= 0f) {
      if (slayerModeEnabled && !slayerDeathRespawnPending) {
        // Slayer: don't stop - queue walkback for when the player respawns.
        slayerDeathRespawnPending = true
        if (CombatPatrolModule.isPatrolRunning) CombatPatrolModule.stopPatrol()
        if (PathfindingModule.isPatrolActive) PathfindingModule.stopPatrol()
        if (slayerNeedsWalkback) WalkbackBridge.stopWalkback?.invoke()
        slayerNeedsWalkback = false
        nativeStop()
        slayerStatus.value = "Died - respawning..."
      } else if (!cryptZombieSlayer.value) {
        stopMacro()
      }
      return
    }
    // Respawn after slayer death: trigger walkback so player returns to farm area.
    if (slayerDeathRespawnPending) {
      slayerDeathRespawnPending = false
      startAreaOrigin = null
      triggerWalkToFarmArea(justFarm = false)
    }

    if (stayNearStart.value && startAreaOrigin == null) {
      val pos = player.blockPosition()
      // For crypt location, only anchor the start area when the player is actually
      // inside the crypt - prevents hub spawn from being used as the anchor point
      // which would block the walk-in route.
      val shouldAnchor = !(cryptZombieSlayer.value && slayerLocation.value == 1) ||
        CRYPT_PATROL_WAYPOINTS.any { wp ->
          val dx = wp.x - pos.x; val dz = wp.z - pos.z
          dx * dx + dz * dz < CRYPT_PROXIMITY_RANGE_SQ
        }
      if (shouldAnchor) startAreaOrigin = pos
    }

    tryAutoHeal(player, level.gameTime)
    tryAlwaysUseWandOfAtonement(player, level.gameTime)
    if (!cryptZombieSlayer.value && prefersDrillForTargetName(targetName.value)) {
      ensureWalkerDrillSelected(player, level.gameTime, targetName.value)
    }
    // For crypt slayer: track when the player is confirmed inside the crypt, and recover
    // (warp hub + walk-in) only if they previously entered and then unexpectedly left.
    // The slayerEnteredCrypt guard prevents the startup spam loop where the player warps to
    // hub and the outside-crypt check immediately re-fires before they have walked back in.
    if (cryptZombieSlayer.value && slayerLocation.value == 1 && !slayerBossActive
      && slayerWalkInDelayUntilTick < 0L && !slayerNeedsWalkback) {
      val inCrypt = CRYPT_PATROL_WAYPOINTS.any { wp ->
        val dx = wp.x - player.x; val dz = wp.z - player.z
        dx * dx + dz * dz < CRYPT_PROXIMITY_RANGE_SQ
      }
      if (inCrypt) {
        slayerEnteredCrypt = true   // confirmed inside - enable recovery trigger
      } else if (slayerEnteredCrypt) {
        // Was inside the crypt but now isn't - navigate back via walkback route.
        ChatUtils.sendMessage("Combat macro: outside crypt, walking back.")
        startAreaOrigin = null
        slayerEnteredCrypt = false
        triggerWalkToFarmArea(justFarm = false)
        return
      }
      // If !inCrypt && !slayerEnteredCrypt: still making initial walk-in, do nothing here
    }
    // For non-crypt slayer types: track area entry/exit using patrol points.
    if (cryptZombieSlayer.value && slayerLocation.value != 1
      && CombatPatrolModule.patrolPoints.isNotEmpty()
      && walkbackRouteForCurrentType().value.isNotBlank()) {
      val pos = player.blockPosition()
      val nearAnyPoint = CombatPatrolModule.patrolPoints.any { p ->
        val dx = p.x - pos.x; val dz = p.z - pos.z
        dx * dx + dz * dz < GRAVEYARD_PROXIMITY_RANGE_SQ
      }
      if (nearAnyPoint) {
        enteredFarmingArea = true
      } else if (enteredFarmingArea && !slayerBossActive
        && WalkbackBridge.isRunning?.invoke() != true
        && !slayerNeedsWalkback && !slayerDeathRespawnPending) {
        ChatUtils.sendMessage("Combat macro: left farming area, walking back.")
        enteredFarmingArea = false
        startAreaOrigin = null
        triggerWalkToFarmArea(justFarm = false)
        return
      }
    }
    // Walkback owns pathfinding - yield before enforceStartArea can override it.
    if (slayerNeedsWalkback && WalkbackBridge.isRunning?.invoke() == true && !slayerBossActive) {
      currentTargetId = null
      return
    }
    // Don't enforce start area when the slayer boss is active - chase it wherever it goes
    if (!(cryptZombieSlayer.value && slayerBossActive) && enforceStartArea(player, level)) {
      return
    }

    val target = if (cryptZombieSlayer.value) resolveSlayerTarget(player, level) else resolveTarget(player)
    if (cryptZombieSlayer.value) {
      tryUseSlayerSupportItems(player, target, level.gameTime)
    }
    if (target == null) {
      resetCloseChase()
      // Boss is active but not yet visible - walk toward its last known position so we can find it.
      if (cryptZombieSlayer.value && slayerBossActive) {
        val bossPos = slayerBossLastPos
        if (bossPos != null) {
          val bossBlockPos = BlockPos(bossPos.x.toInt(), bossPos.y.toInt(), bossPos.z.toInt())
          if (!nativeActive() || lastTargetPos != bossBlockPos) {
            if (level.gameTime - lastPathStartTick >= MIN_PATH_START_INTERVAL_TICKS) {
              lastPathStartTick = level.gameTime
              NativePathfinder.setTarget(bossBlockPos.x + 0.5, bossBlockPos.y.toDouble(), bossBlockPos.z + 0.5)
              val started = true
              if (started) {
                lastTargetPos = bossBlockPos
                startedPath = true
              }
            }
          }
          currentTargetId = null
          return
        }
      }
      // No target - hand off to CombatPatrolModule if patrol points are configured.
      if (CombatPatrolModule.patrolPoints.isNotEmpty() && !CombatPatrolModule.isPatrolRunning) {
        CombatPatrolModule.startPatrol()
      }
      if (CombatPatrolModule.isPatrolRunning) {
        when (CombatPatrolModule.patrolState) {
          CombatPatrolModule.PatrolState.COMBAT_INTERRUPT -> CombatPatrolModule.onCombatResume()
          CombatPatrolModule.PatrolState.AT_KILL_ZONE     -> CombatPatrolModule.onKillZoneCleared()
          else -> { /* NAVIGATING/WARPING - patrol owns movement */ }
        }
        if (startedPath && nativeActive() && !CombatPatrolModule.patrolOwnsPathfinder) nativeStop()
        startedPath = false; lastTargetPos = null; currentTargetId = null
        return
      }

      if (startedPath && nativeActive()) {
        nativeStop()
      } else {
        MovementManager.setMovementLock(false)
      }
      startedPath = false
      lastTargetPos = null
      currentTargetId = null
      return
    }

    val dist = player.distanceTo(target)
    val pathActiveNow = startedPath && nativeActive()
    val hasLos = player.hasLineOfSight(target)
    val activeCombatMode = effectiveCombatMode(target)
    val engageRange = combatEngageRange(activeCombatMode)
    val keepDistance = combatKeepDistance(activeCombatMode)
    val suppressAttack = cryptZombieSlayer.value && shouldSuppressSlayerAttack(target, level.gameTime)
    val inAttackRange =
      when (activeCombatMode) {
        0 -> dist <= attackRange.value
        else -> hasLos && dist <= engageRange
      }
    val inKeepDistanceZone =
      when (activeCombatMode) {
        0 -> dist <= keepDistance
        else -> hasLos && dist <= keepDistance
      }
    val inCloseChaseRange = dist <= engageRange + chaseStopBuffer.value

    ensurePreferredWeapon(player, target, level.gameTime)
    val delayedByEmanPreSwap =
      if (cryptZombieSlayer.value) {
        ensureSlayerWeapon(player, target)
      } else {
        false
      }
    if (cryptZombieSlayer.value) {
      applyEmanHitPhaseSneak(target, inAttackRange || inKeepDistanceZone)
    }

    val aimRotation = if (activeCombatMode != 0) rangedAimRotation(player, target, activeCombatMode) else AngleUtils.getRotation(target)
    val phaseMovementActive =
      if (cryptZombieSlayer.value) {
        handleSlayerPhaseMovement(player, target, dist.toDouble(), hasLos, activeCombatMode, level.gameTime)
      } else {
        false
      }
    if (inCloseChaseRange && (hasLos || inAttackRange)) {
      // Let native path rotation steer the player until it has fully arrived;
      // overriding it early makes the movement drift off-path and circle.
      if (!pathActiveNow || inAttackRange) {
        RotationExecutor.rotateTo(aimRotation, rotationStrategy)
      }
    } else if (!pathActiveNow && !inCloseChaseRange && dist > attackRange.value + chaseStopBuffer.value + ROTATION_STOP_HYSTERESIS) {
      RotationExecutor.stopRotating()
    }

    if (inAttackRange || inKeepDistanceZone) {
      if (!oneTapMode.value && inKeepDistanceZone && startedPath && nativeActive()) {
        nativeStop()
      }
      if (!oneTapMode.value && inKeepDistanceZone) {
        startedPath = false
        lastTargetPos = null
      }
      stuckRepathCount = 0
      if (inAttackRange) {
        losScanLastFlipTick = 0L
        val keepRangedMomentum = activeCombatMode != 0 && oneTapMode.value && pathActiveNow
        if (!keepRangedMomentum && !phaseMovementActive) {
          MovementManager.clearForcedMovement()
        }
        if (!suppressAttack && !delayedByEmanPreSwap) {
          attemptAttack(player, target, activeCombatMode)
        }
      } else {
        // In range but no LOS - face target and strafe to find a clear angle
        RotationExecutor.rotateTo(aimRotation, rotationStrategy)
        applyLosStrafeScan(level.gameTime)
      }
    } else if (slayerNeedsWalkback) {
      // Walkback owns movement - don't chase, just rotate toward target so we can attack when it comes in range.
      RotationExecutor.rotateTo(aimRotation, rotationStrategy)
    } else {
      // Target spotted - stop kill patrol so combat macro can take over pathfinding.
      if (PathfindingModule.isPatrolActive) PathfindingModule.stopPatrol()
      if (CombatPatrolModule.patrolState == CombatPatrolModule.PatrolState.NAVIGATING ||
          CombatPatrolModule.patrolState == CombatPatrolModule.PatrolState.WARPING) {
        CombatPatrolModule.onCombatInterrupt()
      }
      val targetPos = target.blockPosition()
      val last = lastTargetPos
      val targetMovedFar = last == null || last.distSqr(targetPos) > TARGET_REPATH_DISTANCE_SQ
      val pathDone = !pathActiveNow
      val directChaseZone = activeCombatMode == 0 && shouldUseDirectChase(target, hasLos, dist.toDouble())
      if (directChaseZone) {
        // Once LOS is established and the target is close enough, stop letting the
        // pathfinder keep re-solving around the mob and finish the approach with
        // strict forward-only chase.
        if (pathActiveNow) {
          nativeStop()
        }
        startedPath = false
        lastTargetPos = null
        handleSoftChaseMovement(player, target, dist.toDouble())
      } else if (pathDone || targetMovedFar) {
        if (level.gameTime - lastPathStartTick >= MIN_PATH_START_INTERVAL_TICKS) {
          lastPathStartTick = level.gameTime
          val started = startCombatPathToTarget(level, targetPos, activeCombatMode)
          if (started) {
            lastTargetPos = targetPos
            startedPath = true
          } else {
            startedPath = false
            if (!nativeActive()) {
              lastTargetPos = null
            }
          }
        }
      }
    }

    updateStuck(player, inAttackRange || inKeepDistanceZone, level)
  }

  @SubscribeEvent
  fun onRender(event: WorldRenderEvent.Last) {
    if (!enabled.value) return
    val level = mc.level ?: return

    if (cryptZombieSlayer.value && slayerBossEsp.value && slayerEspStyle.value == SLAYER_ESP_STYLE_BOX) {
      renderSlayerHighlights(event.context, level)
    }

    val targetId = currentTargetId ?: return
    val target = level.entitiesForRendering().firstOrNull { it.uuid == targetId } as? LivingEntity ?: return
    if (!target.isAlive || target.health <= 0f) return

    val color = currentTargetRenderColor()
    Render3D.drawBox(event.context, target.boundingBox.inflate(TARGET_BOX_INFLATE), color, true)
  }

  private fun resolveTarget(player: Player): LivingEntity? {
    val level = mc.level ?: return null
    // Kill zone mode: only target mobs near the current kill point.
    val killPoint = CombatPatrolModule.currentKillPoint
    if (killPoint != null) {
      val kx = killPoint.x + 0.5; val ky = killPoint.y.toDouble(); val kz = killPoint.z + 0.5
      val radiusSq = CombatPatrolModule.killZoneRadiusValue * CombatPatrolModule.killZoneRadiusValue
      val blacklisted = builtInBlacklistedNames
      val filter = targetName.value.trim().lowercase()
      var best: LivingEntity? = null
      var bestDist = Double.POSITIVE_INFINITY
      for (entity in level.entitiesForRendering()) {
        val living = entity as? LivingEntity ?: continue
        if (!isValidTarget(living, player, blacklisted, filter, true)) continue
        val dx = living.x - kx; val dy = living.y - ky; val dz = living.z - kz
        val distSq = dx * dx + dy * dy + dz * dz
        if (distSq > radiusSq) continue
        val playerDist = player.distanceToSqr(living)
        if (playerDist < bestDist) { best = living; bestDist = playerDist }
      }
      if (best != null) currentTargetId = best.uuid
      return best
    }
    val filter = targetName.value.trim().lowercase()
    val blacklisted = builtInBlacklistedNames
    // Patrol running (non-kill-zone): bypass stayNearStart - patrol route defines the area.
    val startOrigin =
      if (CombatPatrolModule.isPatrolRunning || !stayNearStart.value) {
        null
      } else {
        startAreaOrigin ?: player.blockPosition().also { startAreaOrigin = it }
      }
    val startAreaRangeSq = startAreaRadius.value * startAreaRadius.value

    val searchRangeSq = searchRange.value * searchRange.value
    var best: LivingEntity? = null
    var bestDist = Double.POSITIVE_INFINITY
    for (entity in level.entitiesForRendering()) {
      val living = entity as? LivingEntity ?: continue
      if (!isValidTarget(living, player, blacklisted, filter, true)) continue
      if (startOrigin != null) {
        val ox = living.x - (startOrigin.x + 0.5)
        val oz = living.z - (startOrigin.z + 0.5)
        if (ox * ox + oz * oz > startAreaRangeSq) continue
      }
      val dx = living.x - player.x
      val dy = living.y - player.y
      val dz = living.z - player.z
      val distSq = dx * dx + dy * dy + dz * dz
      if (distSq > searchRangeSq) continue
      if (distSq < bestDist) {
        best = living
        bestDist = distSq
      }
    }
    if (best != null) {
      currentTargetId = best.uuid
    }
    return best
  }

  private fun resolveSlayerTarget(player: Player, level: ClientLevel): LivingEntity? {
    val blacklisted = builtInBlacklistedNames
    // Kill zone mode: when patrol is AT_KILL_ZONE, anchor the mob search around the kill
    // point instead of startAreaOrigin. This matches how resolveTarget() works and prevents
    // the slayer from marking the kill zone "cleared" before any mobs there are targeted.
    val killPoint = CombatPatrolModule.currentKillPoint
    val patrolRunning = CombatPatrolModule.isPatrolRunning
    val startOrigin = when {
      // Kill zone: anchor search around the kill point
      killPoint != null -> BlockPos(killPoint.x, killPoint.y, killPoint.z)
      // Patrol navigating: don't constrain by startAreaOrigin - patrol route defines the area
      patrolRunning -> null
      stayNearStart.value -> startAreaOrigin ?: player.blockPosition().also { startAreaOrigin = it }
      else -> null
    }
    val startAreaRangeSq = when {
      killPoint != null -> CombatPatrolModule.killZoneRadiusValue.let { it * it }
      else -> startAreaRadius.value * startAreaRadius.value
    }
    // In kill zone mode the kill-point radius already constrains the search; skip the
    // player-distance searchRange filter so mobs at the kill zone are never missed.
    val searchRangeSq = if (killPoint != null) Double.POSITIVE_INFINITY else searchRange.value * searchRange.value
    var bestBoss: LivingEntity? = null
    var bestBossDist = Double.POSITIVE_INFINITY
    var bestPriorityMob: LivingEntity? = null
    var bestPriorityMobDist = Double.POSITIVE_INFINITY
    var bestFarmMob: LivingEntity? = null
    var bestFarmMobDist = Double.POSITIVE_INFINITY

    val newHighlightCache = mutableMapOf<UUID, SlayerHighlightState>()
    for (entity in level.entitiesForRendering()) {
      val living = entity as? LivingEntity ?: continue
      if (!isValidTarget(living, player, blacklisted, "", true, ignoreWhitelist = true)) continue

      // Compute names once — avoids 3 separate findAttachedArmorStandNames scans per entity.
      val names = targetMatchNames(living)
      val isBoss = names.any(::isSlayerBossName) &&
        (!cryptZombieSlayer.value || !slayerOwnBossOnly.value || isSlayerBossOwnedByPlayer(living))
      val isPriority = names.any(::isSlayerPriorityMobName)
      val isFarmMob = isSlayerFarmMobNames(names)
      if (!isBoss && !isPriority && !isFarmMob) continue

      // Populate highlight cache so renderSlayerHighlights can skip its own entity scan.
      if (isBoss) {
        newHighlightCache[living.uuid] = buildSlayerHighlightState(names, SlayerHighlightType.BOSS)
      } else if (isPriority && slayerHighlightMiniBosses.value) {
        val type =
          if (names.any(::isHighTierSlayerPriorityMobName)) SlayerHighlightType.HIGH_TIER_MINIBOSS
          else SlayerHighlightType.MINIBOSS
        newHighlightCache[living.uuid] = buildSlayerHighlightState(names, type)
      }

      if (startOrigin != null && !isBoss) {
        // Boss ignores start area - chase it wherever it goes
        val ox = living.x - (startOrigin.x + 0.5)
        val oz = living.z - (startOrigin.z + 0.5)
        if (ox * ox + oz * oz > startAreaRangeSq) continue
      }

      val dx = living.x - player.x
      val dy = living.y - player.y
      val dz = living.z - player.z
      val distSq = dx * dx + dy * dy + dz * dz
      if (!isBoss && distSq > searchRangeSq) continue // boss ignores search range

      if (isBoss && distSq < bestBossDist) {
        bestBoss = living
        bestBossDist = distSq
      }
      if (isPriority && distSq < bestPriorityMobDist) {
        bestPriorityMob = living
        bestPriorityMobDist = distSq
      }
      if (isFarmMob && distSq < bestFarmMobDist) {
        bestFarmMob = living
        bestFarmMobDist = distSq
      }
    }
    slayerHighlightCache = newHighlightCache
    if (slayerBossEsp.value && slayerEspStyle.value == SLAYER_ESP_STYLE_GLOW) {
      syncSlayerGlowState(level, newHighlightCache)
    } else {
      clearSlayerGlowState(level)
    }

    if (bestBoss != null) {
      onSlayerBossDetected(level.gameTime)
      slayerBossLastPos = bestBoss.position()
    } else if (slayerBossActive && level.gameTime - slayerBossLastSeenTick > SLAYER_BOSS_ENTITY_LOST_TICKS) {
      clearSlayerBossState()
    }

    updateSlayerBossPhaseState(level, bestBoss)
    val phaseTarget = if (slayerBossActive) resolveSlayerPhaseTarget(player, level, bestBoss) else null

    // Priority: boss > priority farm mob (rare/bonus) > regular farm mob
    val selected = when {
      phaseTarget != null -> phaseTarget
      slayerBossActive -> bestBoss
      else -> bestBoss ?: bestPriorityMob ?: bestFarmMob
    }
    if (selected != null) {
      currentTargetId = selected.uuid
    }
    return selected
  }

  private fun updateSlayerBossState(nowTick: Long) {
    val tabLines = readTabListLines(nowTick)
    val scoreboardLines = readScoreboardSidebarLines(mc.level)
    for (line in scoreboardLines) {
      applyQuestDetection(line, "scoreboard", nowTick)
      applyQuestProgressDetection(line, nowTick)
    }
    for (line in tabLines) {
      applyQuestDetection(line, "tab", nowTick)
      applyQuestProgressDetection(line, nowTick)
    }
    val questLines = tabLines + scoreboardLines
    val hasBossTabLine = questLines.any { line -> SLAYER_BOSS_TAB_KEYWORDS.any { keyword -> line.contains(keyword) } }
    val hasClearTabLine = questLines.any { line -> SLAYER_BOSS_CLEAR_KEYWORDS.any { keyword -> line.contains(keyword) } }
    val hasQuestTabLine = questLines.any { line ->
      lineHasActiveSlayerQuestSignal(line)
    }
    val questStateSettling = isSlayerQuestStateSettling(nowTick)

    if (hasBossTabLine) {
      onSlayerBossDetected(nowTick)
      confirmActiveSlayerQuest(nowTick)
      slayerQuestReady = false
    } else {
      if (hasClearTabLine) {
        if (slayerBossActive) {
          clearSlayerBossState()
        }
        if (!questStateSettling) {
          queueSlayerQuestRestart()
        }
      } else if (hasQuestTabLine) {
        confirmActiveSlayerQuest(nowTick)
      }
      if (slayerBossActive && nowTick - slayerBossLastSeenTick > SLAYER_BOSS_TAB_LOST_TICKS) {
        clearSlayerBossState()
      }
    }

    slayerStatus.value =
      when {
        slayerBossActive && isSpiderBossHatchlingsPhaseActive(nowTick) -> "Boss Active - Hatchlings"
        slayerBossActive && isWolfBossPupsPhaseActive(nowTick) ->
          if (wolfIgnorePups.value) "Boss Active - Pups (Ignored)" else "Boss Active - Pups"
        slayerBossActive -> "Boss Active"
        slayerNeedsQuestClaim -> "Claiming Loot"
        slayerQuestReady -> "Quest Ready!"
        slayerNeedsQuestRestart -> "Restarting Quest"
        else -> "Farming ${when (slayerType.value) { 0 -> "Zombies"; 1 -> "Wolves"; 2 -> "Spiders"; 3 -> "Voidlings"; 4 -> "Vampires"; 5 -> "Blazes"; else -> "Mobs" }}"
      }
  }

  private fun onSlayerBossDetected(nowTick: Long) {
    val wasActive = slayerBossActive
    slayerBossActive = true
    slayerTrackedQuestBossSeen = true
    slayerBossLastSeenTick = nowTick
    slayerNeedsQuestRestart = false
    if (!wasActive) {
      slayerOverfluxUsedThisBoss = false
      slayerRagnarokUsedThisBoss = false
      slayerReaperScytheUsedThisBoss = false
      slayerLastBadHealthUseTick = -1L
      slayerLastOverfluxUseTick = -1L
      slayerLastReaperScytheUseTick = -1L
      val bossName = slayerBossDisplayName()
      ChatUtils.sendMessage("Combat macro: $bossName spawned.")
      if (slayerBossNotification.value) {
        NotificationManager.queue("Slayer Boss Spawned", bossName, 3200L)
      }
    }
  }

  private fun clearSlayerBossState(announce: Boolean = true) {
    if (slayerBossActive && announce) {
      ChatUtils.sendMessage("Combat macro: Slayer boss no longer detected.")
    }
    clearPendingOverfluxPlacement()
    clearSpiderHatchlingsPhase()
    clearEndermanLaserPhase()
    slayerRagnarokUsedForLaserPhase = false
    wolfPupsPhaseUntilTick = -1L
    slayerBossActive = false
    slayerBossLastSeenTick = 0L
    slayerOverfluxUsedThisBoss = false
    slayerRagnarokUsedThisBoss = false
    slayerReaperScytheUsedThisBoss = false
    slayerRagnarokUsedPreBoss = false
    slayerQuestReady = false
    slayerLastBadHealthUseTick = -1L
    slayerLastReaperScytheUseTick = -1L
    slayerBossLastPos = null
    emanHitPhaseBossWeaponPrimed = false
  }

  private fun tryUseSlayerSupportItems(player: Player, target: LivingEntity?, nowTick: Long) {
    if (!slayerBossActive) return
    if (pendingHealRelease || pendingHealRestoreSlot >= 0 || pendingOverfluxLookDownTicks > 0) return

    if (autoOverflux.value && !slayerOverfluxUsedThisBoss && nowTick - slayerLastOverfluxUseTick >= SLAYER_OVERFLUX_COOLDOWN_TICKS) {
      if (useHotbarOverflux(player)) {
        slayerOverfluxUsedThisBoss = true
        slayerLastOverfluxUseTick = nowTick
        return
      }
    }

    // Laser phase: fire ragnarok at the start of each laser phase (separate from the general boss ragnarok).
    if (autoRagnarok.value && emanLaserPhaseActive && !slayerRagnarokUsedForLaserPhase &&
        nowTick - slayerLastRagnarokUseTick >= SLAYER_RAGNAROK_COOLDOWN_TICKS) {
      if (useHotbarUtilityItem(player, SLAYER_RAGNAROK_KEYWORDS)) {
        slayerRagnarokUsedForLaserPhase = true
        slayerLastRagnarokUseTick = nowTick
        return
      }
    }

    if (autoRagnarok.value && !slayerRagnarokUsedThisBoss && nowTick - slayerLastRagnarokUseTick >= SLAYER_RAGNAROK_COOLDOWN_TICKS) {
      if (useHotbarUtilityItem(player, SLAYER_RAGNAROK_KEYWORDS)) {
        slayerRagnarokUsedThisBoss = true
        slayerLastRagnarokUseTick = nowTick
        return
      }
    }

    if (autoReaperScythe.value && !slayerReaperScytheUsedThisBoss && nowTick - slayerLastReaperScytheUseTick >= SLAYER_REAPER_SCYTHE_COOLDOWN_TICKS) {
      val bossTarget = target?.takeIf(::isSlayerBossEntity) ?: resolveNearestSlayerBoss()
      if (bossTarget != null && player.hasLineOfSight(bossTarget)) {
        val rotation = AngleUtils.getRotation(bossTarget)
        RotationExecutor.rotateTo(rotation, rotationStrategy)
        val yawError = abs(AngleUtils.getRotationDelta(player.yRot, rotation.yaw))
        val pitchError = abs(rotation.pitch - player.xRot)
        if (yawError <= REAPER_SCYTHE_USE_AIM_TOLERANCE &&
          pitchError <= REAPER_SCYTHE_USE_AIM_TOLERANCE &&
          useHotbarUtilityItem(player, SLAYER_REAPER_SCYTHE_KEYWORDS)
        ) {
          slayerReaperScytheUsedThisBoss = true
          slayerLastReaperScytheUseTick = nowTick
          return
        }
      }
    }

    if (autoSwordOfBadHealth.value && nowTick - slayerLastBadHealthUseTick >= SLAYER_BAD_HEALTH_REUSE_TICKS) {
      if (useHotbarUtilityItem(player, SLAYER_BAD_HEALTH_KEYWORDS)) {
        slayerLastBadHealthUseTick = nowTick
      }
    }
  }

  private fun tryRestartSlayerQuest(player: Player, nowTick: Long): Boolean {
    if (!slayerNeedsQuestRestart || slayerBossActive) return false
    // Don't fire the batphone until quest detection has settled
    if (!slayerAutoDetected) return true
    if (isLikelyMaddoxScreen(nowTick)) return true
    if (mc.screen is AbstractContainerScreen<*>) return false
    if (pendingHealRelease || pendingHealRestoreSlot >= 0) return true
    if (slayerLastBatphoneAttemptTick >= 0L && nowTick - slayerLastBatphoneAttemptTick < SLAYER_BATPHONE_RETRY_TICKS) {
      return true
    }

    var batphoneSlot = findHotbarSlotByKeywords(player, SLAYER_BATPHONE_KEYWORDS)
    if (batphoneSlot !in 0..8) {
      val moved = moveBatphoneToHotbar(player)
      if (!moved) {
        slayerStatus.value = "Need Maddox Batphone"
        if (slayerWarnNoBatphoneTick < 0L || nowTick - slayerWarnNoBatphoneTick >= SLAYER_NO_BATPHONE_WARN_TICKS) {
          slayerWarnNoBatphoneTick = nowTick
          ChatUtils.sendMessage("Combat macro: Maddox Batphone not found in inventory/hotbar.")
        }
        slayerLastBatphoneAttemptTick = nowTick
        return true
      }
      batphoneSlot = findHotbarSlotByKeywords(player, SLAYER_BATPHONE_KEYWORDS)
    }

    if (batphoneSlot !in 0..8) {
      slayerLastBatphoneAttemptTick = nowTick
      return true
    }

    if (useHotbarUtilityItem(player, SLAYER_BATPHONE_KEYWORDS)) {
      slayerLastBatphoneAttemptTick = nowTick
      slayerLastBatphoneUseTick = nowTick
      slayerStatus.value = "Calling Maddox..."
      return true
    }

    return false
  }

  private fun handleMaddoxGui(nowTick: Long): Boolean {
    if (!slayerNeedsQuestRestart) return false
    if (!isLikelyMaddoxScreen(nowTick)) return false
    if (nowTick - slayerLastGuiActionTick < SLAYER_GUI_ACTION_COOLDOWN_TICKS) return true

    val player = mc.player ?: return true
    val menu = player.containerMenu
    val action = findMaddoxMenuAction(menu.slots)
    if (action.slotIndex >= 0) {
      InventoryUtils.clickSlot(action.slotIndex)
      slayerLastGuiActionTick = nowTick
      slayerLastBatphoneAttemptTick = nowTick
      slayerPendingTierSelection = action.actionType == SlayerMaddoxActionType.TIER_SELECT
      if (action.actionType == SlayerMaddoxActionType.FINAL_PURCHASE) {
        player.closeContainer()
        beginSlayerQuestDetection(nowTick)
        startTrackedSlayerQuest(slayerType.value, slayerTier.value.toInt())
        slayerRagnarokUsedPreBoss = false
        startAreaOrigin = null
        if (cryptZombieSlayer.value && slayerLocation.value == 1) {
          // Crypt: check if already inside the farming area - if so skip the warp and walk-in.
          val alreadyInCrypt = CRYPT_PATROL_WAYPOINTS.any { wp ->
            val dx = wp.x - player.x; val dz = wp.z - player.z
            dx * dx + dz * dz < CRYPT_PROXIMITY_RANGE_SQ
          }
          if (alreadyInCrypt) {
            slayerEnteredCrypt = true
          } else {
            slayerEnteredCrypt = false
            triggerWalkToFarmArea(justFarm = true)
          }
        } else if (slayerAutoWarp.value) {
          val warp = slayerWarpCommand
          if (warp.isNotEmpty()) player.connection?.sendCommand(warp)
        }
      }
      slayerStatus.value = "Restarting Slayer..."
      return true
    }

    if (slayerLastBatphoneUseTick >= 0L && nowTick - slayerLastBatphoneUseTick >= SLAYER_MADDOX_GUI_TIMEOUT_TICKS) {
      player.closeContainer()
      slayerLastGuiActionTick = nowTick
      slayerLastBatphoneAttemptTick = nowTick
      slayerPendingTierSelection = false
      return true
    }

    return true
  }

  /** Called when the loot claim step finishes (success or timeout). Starts the walkback route
   *  or proceeds directly to quest restart. */
  private fun finishSlayerClaim() {
    slayerNeedsQuestClaim = false
    slayerBossLastPos = null
    val routeName = walkbackRouteForCurrentType().value.trim()
    if (!slayerAutoWarp.value && routeName.isNotBlank()) {
      if (startedPath && nativeActive()) nativeStop()
      startedPath = false
      lastTargetPos = null
      currentTargetId = null
      stuckTicks = 0
      stuckRepathCount = 0
      RotationExecutor.stopRotating()
      MovementManager.clearForcedMovement()
      val started = WalkbackBridge.startWalkback?.invoke(routeName, 5, true) ?: false
      if (started) {
        slayerNeedsWalkback = true
        return
      }
    }
    queueSlayerQuestRestart(countFailure = false)
  }

  /**
   * Walks to the boss death position, right-clicks the loot bag entity, then transitions
   * to quest restart. Returns true while the claim step is still in progress.
   */
  private fun handleClaimSlayerQuest(player: LocalPlayer, level: ClientLevel): Boolean {
    val nowTick = level.gameTime

    // Timeout - give up and restart the quest anyway
    if (slayerClaimStartTick >= 0L && nowTick - slayerClaimStartTick > SLAYER_CLAIM_TIMEOUT_TICKS) {
      finishSlayerClaim()
      return false
    }

    val deathPos = slayerBossLastPos
    if (deathPos == null) {
      // No tracked position - skip straight to restart
      finishSlayerClaim()
      return false
    }

    // Search for a loot bag ArmorStand near the death position
    val lootEntity = level.entitiesForRendering()
      .filterIsInstance<ArmorStand>()
      .filter { entity ->
        val dx = entity.x - deathPos.x
        val dy = entity.y - deathPos.y
        val dz = entity.z - deathPos.z
        dx * dx + dy * dy + dz * dz < SLAYER_LOOT_SEARCH_RADIUS_SQ
      }
      .filter { entity ->
        val name = normalizeNameForMatch(entity.name.string)
        SLAYER_LOOT_KEYWORDS.any { name.contains(it) }
      }
      .minByOrNull { entity ->
        val dx = entity.x - player.x
        val dy = entity.y - player.y
        val dz = entity.z - player.z
        dx * dx + dy * dy + dz * dz
      }

    if (lootEntity == null) {
      // No loot bag found yet - walk to death pos and keep waiting
      val targetPos = BlockPos(deathPos.x.toInt(), deathPos.y.toInt(), deathPos.z.toInt())
      if (!nativeActive() || lastTargetPos != targetPos) {
        if (nowTick - lastPathStartTick >= MIN_PATH_START_INTERVAL_TICKS) {
          lastPathStartTick = nowTick
          NativePathfinder.setTarget(targetPos.x + 0.5, targetPos.y.toDouble(), targetPos.z + 0.5)
          val started = true
          if (started) {
            lastTargetPos = targetPos
            startedPath = true
          }
        }
      }
      return true
    }

    // Loot entity found - stop pathing, look at it and right-click
    if (startedPath && nativeActive()) {
      nativeStop()
      startedPath = false
    }

    val dx = lootEntity.x - player.x
    val dy = lootEntity.y - player.y
    val dz = lootEntity.z - player.z
    val distSq = dx * dx + dy * dy + dz * dz

    if (distSq > SLAYER_LOOT_CLAIM_RANGE_SQ) {
      val targetPos = lootEntity.blockPosition()
      if (!nativeActive()) {
        if (nowTick - lastPathStartTick >= MIN_PATH_START_INTERVAL_TICKS) {
          lastPathStartTick = nowTick
          NativePathfinder.setTarget(targetPos.x + 0.5, targetPos.y.toDouble(), targetPos.z + 0.5)
          lastTargetPos = targetPos
          startedPath = true
        }
      }
      return true
    }

    val rotation = AngleUtils.getRotation(lootEntity)
    RotationExecutor.rotateTo(rotation, rotationStrategy)

    if (nowTick - slayerClaimLastClickTick >= SLAYER_CLAIM_CLICK_INTERVAL_TICKS) {
      slayerClaimLastClickTick = nowTick
      MouseUtils.rightClick()
    }

    // After a short dwell at the loot bag, assume claimed and move on
    if (nowTick - slayerClaimStartTick > SLAYER_CLAIM_DWELL_TICKS) {
      finishSlayerClaim()
    }

    return true
  }

  private fun isLikelyMaddoxScreen(nowTick: Long): Boolean {
    val screen = mc.screen as? AbstractContainerScreen<*> ?: return false
    val title = normalizeNameForMatch(screen.title.string)
    if (SLAYER_MADDOX_SCREEN_KEYWORDS.any { keyword -> title.contains(keyword) }) return true
    return slayerLastBatphoneUseTick >= 0L && nowTick - slayerLastBatphoneUseTick <= SLAYER_MADDOX_GUI_TIMEOUT_TICKS
  }

  @SubscribeEvent
  fun onChatReceive(event: ChatEvent.Receive) {
    val raw = event.message ?: return
    val msg = ChatFormatting.stripFormatting(raw)?.lowercase(Locale.ROOT)?.trim() ?: return

    if (enabled.value) {
      // Player name mentioned in chat -> play system alert sound.
      val ign = mc.player?.gameProfile?.name?.lowercase(Locale.ROOT) ?: ""
      if (ign.isNotEmpty() && msg.contains(ign)) {
        java.awt.Toolkit.getDefaultToolkit().beep()
      }
      // Evacuated from hub or moved to different server -> walk back to farm area.
      if (msg.contains("evacuated from") || msg.contains("moved to a different server")) {
        triggerWalkToFarmArea(justFarm = false)
        return
      }
    }

    if (!cryptZombieSlayer.value) return

    if (SLAYER_QUEST_READY_CHAT_KEYWORDS.any { msg.contains(it) }) {
      confirmActiveSlayerQuest(mc.level?.gameTime ?: -1L)
      slayerQuestReady = true
      ChatUtils.sendMessage("Combat macro: Quest ready - Ragnarok prepped for boss spawn.")
    }

    if (SLAYER_BOSS_SPAWNED_CHAT_KEYWORDS.any { msg.contains(it) }) {
      val level = mc.level ?: return
      onSlayerBossDetected(level.gameTime)
      confirmActiveSlayerQuest(level.gameTime)
      slayerQuestReady = false
    }

    if (shouldUseSpiderPhaseBowCombat() &&
      msg.contains("broodfather's hatchlings") &&
      msg.contains("before it can be damaged again")
    ) {
      activateSpiderHatchlingsPhase(mc.level?.gameTime ?: -1L)
    }

    if (SLAYER_BOSS_KILLED_CHAT_KEYWORDS.any { msg.contains(it) }) {
      completeTrackedSlayerQuest()
      clearSlayerBossState(false)
      slayerNeedsQuestClaim = true
      slayerClaimStartTick = mc.level?.gameTime ?: -1L
    }
  }

  private fun tryAutoDetectSlayerQuest(level: ClientLevel) {
    val nowTick = level.gameTime
    if (isSlayerQuestStateSettling(nowTick)) return

    // Scan scoreboard sidebar
    for (line in readScoreboardSidebarLines(level)) {
      if (applyQuestDetection(line, "scoreboard", nowTick)) return
    }

    // Scan tab list
    val tabLines = readTabListLines(nowTick)
    for (line in tabLines) {
      if (applyQuestDetection(line, "tab", nowTick)) return
    }

    // Nothing found yet - only conclude "no quest" after the detection window expires
    if (slayerDetectStartTick >= 0L && nowTick - slayerDetectStartTick >= SLAYER_DETECT_WINDOW_TICKS) {
      slayerAutoDetected = true
      queueSlayerQuestRestart() // no quest found in window -> buy one
    }
    // else: still within window - farming continues normally, detection runs next tick
  }

  /** Returns true and updates state if the line matches any active slayer quest. */
  private fun applyQuestDetection(line: String, source: String, nowTick: Long): Boolean {
    val typeIdx = detectSlayerTypeFromLine(line)
    if (typeIdx < 0) return false

    val tier = parseSlayerTierFromLine(line)
    if (slayerType.value != typeIdx) {
      slayerType.value = typeIdx
      ChatUtils.sendMessage("Combat macro: Detected ${slayerType.options[typeIdx]} Slayer from $source.")
    }
    if (tier in 1..5) slayerTier.value = tier.toDouble()
    confirmActiveSlayerQuest(nowTick, typeIdx, tier)
    return true
  }

  private fun beginSlayerQuestDetection(nowTick: Long) {
    slayerNeedsQuestRestart = false
    slayerPendingTierSelection = false
    slayerQuestReady = false
    slayerAutoDetected = false
    slayerDetectStartTick = nowTick
    slayerQuestStateGraceUntilTick =
      if (nowTick >= 0L) nowTick + SLAYER_QUEST_STATE_GRACE_TICKS else -1L
  }

  private fun confirmActiveSlayerQuest(
    nowTick: Long,
    detectedType: Int = slayerType.value,
    detectedTier: Int = slayerTier.value.toInt(),
  ) {
    val resolvedType = detectedType.takeIf { it in slayerType.options.indices } ?: slayerType.value
    val resolvedTier = detectedTier.takeIf { it in 1..5 } ?: slayerTier.value.toInt().coerceIn(1, 5)
    slayerNeedsQuestRestart = false
    slayerAutoDetected = true
    slayerDetectStartTick = -1L
    if (!slayerTrackedQuestActive || slayerTrackedQuestCompletionPendingRestart) {
      startTrackedSlayerQuest(resolvedType, resolvedTier)
    } else {
      slayerTrackedQuestType = resolvedType
      slayerTrackedQuestTier = resolvedTier
    }
    if (nowTick >= 0L) {
      slayerQuestStateGraceUntilTick = nowTick + SLAYER_QUEST_STATE_GRACE_TICKS
    }
  }

  private fun isSlayerQuestStateSettling(nowTick: Long): Boolean {
    return slayerQuestStateGraceUntilTick >= 0L && nowTick < slayerQuestStateGraceUntilTick
  }

  private fun applyQuestProgressDetection(line: String, nowTick: Long): Boolean {
    val progress = parseSlayerQuestProgress(line) ?: return false
    val resolvedTier =
      progress.tier.takeIf { it in 1..5 }
        ?: slayerTrackedQuestTier.takeIf { slayerTrackedQuestActive && it in 1..5 }
        ?: slayerTier.value.toInt().coerceIn(1, 5)
    if (!slayerTrackedQuestActive || slayerTrackedQuestCompletionPendingRestart || slayerTrackedQuestType != progress.typeIndex) {
      startTrackedSlayerQuest(progress.typeIndex, resolvedTier)
    }
    confirmActiveSlayerQuest(nowTick, progress.typeIndex, resolvedTier)
    slayerTrackedQuestTargetKills = progress.target.coerceAtLeast(progress.progress)
    slayerTrackedQuestProgressKills = max(slayerTrackedQuestProgressKills, progress.progress)
    slayerTrackedQuestSawMobKill = slayerTrackedQuestSawMobKill || progress.progress > 0
    return true
  }

  private fun parseSlayerQuestProgress(line: String): SlayerQuestProgress? {
    val match = SLAYER_PROGRESS_PATTERN.find(line) ?: return null
    val progress = match.groupValues[1].toIntOrNull() ?: return null
    val target = match.groupValues[2].toIntOrNull() ?: return null
    if (target <= 0 || progress !in 0..target) return null
    val detectedType = detectSlayerTypeFromLine(line)
    val hasTrackedQuestContext = slayerTrackedQuestActive && slayerTrackedQuestType in slayerType.options.indices
    val relevant =
      detectedType >= 0 ||
        line.contains("slayer quest") ||
        SLAYER_GENERIC_QUEST_KEYWORDS.any { keyword -> line.contains(keyword) } ||
        hasTrackedQuestContext
    if (!relevant) return null
    val typeIndex =
      when {
        detectedType >= 0 -> detectedType
        hasTrackedQuestContext -> slayerTrackedQuestType
        else -> slayerType.value
      }
    val resolvedTier =
      parseSlayerTierFromLine(line).takeIf { it in 1..5 }
        ?: slayerTrackedQuestTier.takeIf { hasTrackedQuestContext && it in 1..5 }
        ?: -1
    return SlayerQuestProgress(typeIndex, resolvedTier, progress, target)
  }

  private fun detectSlayerTypeFromLine(line: String): Int =
    when {
      line.contains("zombie slayer") || line.contains("revenant horror") || line.contains("atoned horror") || (line.contains("revenant") && line.contains("slayer")) -> 0
      line.contains("wolf slayer") || line.contains("sven packmaster") || (line.contains("sven") && line.contains("slayer")) -> 1
      line.contains("spider slayer") || line.contains("tarantula broodfather") || (line.contains("tarantula") && line.contains("slayer")) -> 2
      line.contains("enderman slayer") || line.contains("voidgloom seraph") || (line.contains("voidgloom") && line.contains("slayer")) -> 3
      line.contains("vampire slayer") || line.contains("riftstalker bloodfiend") || (line.contains("riftstalker") && line.contains("slayer")) -> 4
      line.contains("blaze slayer") || line.contains("inferno demonlord") || (line.contains("inferno") && line.contains("slayer")) -> 5
      else -> -1
    }

  private fun parseSlayerTierFromLine(line: String): Int =
    when {
      line.contains(" v") && !line.contains(" vi") -> 5
      line.contains(" iv") -> 4
      line.contains(" iii") -> 3
      line.contains(" ii") -> 2
      line.contains(" i") -> 1
      else -> -1
    }

  private fun slayerMenuQuestNames(): Array<String> =
    when (slayerType.value) {
      0 -> arrayOf("revenant horror", "atoned horror", "zombie slayer")
      1 -> arrayOf("sven packmaster", "wolf slayer")
      2 -> arrayOf("tarantula broodfather", "spider slayer")
      3 -> arrayOf("voidgloom seraph", "enderman slayer")
      4 -> arrayOf("riftstalker bloodfiend", "vampire slayer")
      5 -> arrayOf("inferno demonlord", "blaze slayer")
      else -> emptyArray()
    }

  private fun slayerTierFromToken(token: String): Int =
    when (token) {
      "5", "v" -> 5
      "4", "iv" -> 4
      "3", "iii" -> 3
      "2", "ii" -> 2
      "1", "i" -> 1
      else -> -1
    }

  private fun parseSlayerTierFromMenuText(text: String): Int {
    val normalized = normalizeNameForMatch(text)
    for (questName in slayerMenuQuestNames()) {
      val start = normalized.indexOf(questName)
      if (start < 0) continue
      val suffixTokens =
        normalized.substring(start + questName.length)
          .split(Regex("[^a-z0-9]+"))
          .filter { it.isNotBlank() }
      val tier = suffixTokens.firstOrNull()?.let(::slayerTierFromToken) ?: -1
      if (tier in 1..5) return tier
    }
    return -1
  }

  private fun lineHasActiveSlayerQuestSignal(line: String): Boolean {
    return detectSlayerTypeFromLine(line) >= 0 ||
      SLAYER_GENERIC_QUEST_KEYWORDS.any { keyword -> line.contains(keyword) } ||
      parseSlayerQuestProgress(line) != null
  }

  private fun readScoreboardSidebarLines(level: ClientLevel?): List<String> {
    val liveLevel = level ?: return emptyList()
    val scoreboard = liveLevel.scoreboard
    val objective = scoreboard.getDisplayObjective(DisplaySlot.SIDEBAR) ?: return emptyList()
    return scoreboard.listPlayerScores(objective)
      .mapNotNull { score ->
        val ownerName = score.owner()
        val team = scoreboard.getPlayersTeam(ownerName)
        val raw = if (team != null) team.playerPrefix.string + ownerName + team.playerSuffix.string else ownerName
        ChatFormatting.stripFormatting(raw)?.lowercase(Locale.ROOT)?.trim()
      }
      .filter { it.isNotBlank() }
  }

  private fun moveBatphoneToHotbar(player: Player): Boolean {
    val sourceSlot = findFirstContainerSlotByKeywords(player.containerMenu.slots, SLAYER_BATPHONE_KEYWORDS) ?: return false
    if (sourceSlot in PLAYER_HOTBAR_MENU_SLOT_START..PLAYER_HOTBAR_MENU_SLOT_END) return true

    val targetHotbarSlot = findBestHotbarSwapSlot(player)
    InventoryUtils.swapSlotWithHotbar(sourceSlot, targetHotbarSlot)
    return true
  }

  private fun findFirstContainerSlotByKeywords(
    slots: List<net.minecraft.world.inventory.Slot>,
    keywords: Array<String>
  ): Int? {
    for (slot in slots) {
      if (!slot.hasItem()) continue
      val normalizedName = normalizeNameForMatch(slot.item.hoverName.string)
      if (keywords.any { keyword -> normalizedName.contains(keyword) }) {
        return slot.index
      }
    }
    return null
  }

  private fun findBestHotbarSwapSlot(player: Player): Int {
    val inventory = player.inventory
    for (i in 0..8) {
      if (inventory.getItem(i).isEmpty) {
        return i
      }
    }
    return inventory.selectedSlot.coerceIn(0, 8)
  }

  private enum class SlayerMaddoxActionType {
    NAVIGATION,
    TIER_SELECT,
    FINAL_PURCHASE
  }

  private data class SlayerMaddoxAction(
    val slotIndex: Int,
    val actionType: SlayerMaddoxActionType
  )

  /**
   * Returns the next Maddox GUI action to take.
   * Navigation opens the slayer page, tier-select changes the chosen level,
   * and final-purchase actually starts or confirms the quest.
   */
  private fun findMaddoxMenuAction(slots: List<net.minecraft.world.inventory.Slot>): SlayerMaddoxAction {
    val desiredTier = slayerTier.value.toInt().coerceIn(1, 5)
    var slayerNavigationSlot = -1
    var desiredTierSelectSlot = -1
    var typedRestartSlot = -1
    var typedConfirmSlot = -1
    var genericRestartSlot = -1
    var genericConfirmSlot = -1

    for (slot in slots) {
      if (!slot.hasItem()) continue
      val stack = slot.item
      val name = normalizeNameForMatch(stack.hoverName.string)
      val lore = stack.getLoreLines().joinToString(" ") { normalizeNameForMatch(it.string) }
      val text = "$name $lore"
      val nameTier = parseSlayerTierFromMenuText(name)
      val textTier = if (nameTier in 1..5) nameTier else parseSlayerTierFromMenuText(text)

      val hasRevenantKeyword = SLAYER_MADDOX_REVENANT_KEYWORDS.any { keyword -> text.contains(keyword) }
      val hasRestartKeyword = SLAYER_MADDOX_RESTART_KEYWORDS.any { keyword -> text.contains(keyword) }
      val hasConfirmKeyword = SLAYER_MADDOX_CONFIRM_KEYWORDS.any { keyword -> text.contains(keyword) }

      if (hasConfirmKeyword && textTier == desiredTier) {
        return SlayerMaddoxAction(slot.index, SlayerMaddoxActionType.FINAL_PURCHASE)
      }
      if (hasRestartKeyword && hasRevenantKeyword && nameTier == desiredTier) {
        return SlayerMaddoxAction(slot.index, SlayerMaddoxActionType.FINAL_PURCHASE)
      }

      if (hasRevenantKeyword && nameTier == desiredTier && desiredTierSelectSlot == -1) {
        desiredTierSelectSlot = slot.index
      }
      if (hasConfirmKeyword && hasRevenantKeyword && typedConfirmSlot == -1) {
        typedConfirmSlot = slot.index
      }
      if (hasRevenantKeyword && nameTier !in 1..5 && slayerNavigationSlot == -1) {
        slayerNavigationSlot = slot.index
      }
      if (hasRestartKeyword && hasRevenantKeyword && typedRestartSlot == -1) {
        typedRestartSlot = slot.index
      }
      if (hasRestartKeyword && genericRestartSlot == -1) genericRestartSlot = slot.index
      if (hasConfirmKeyword && genericConfirmSlot == -1) genericConfirmSlot = slot.index
    }

    return if (slayerPendingTierSelection) {
      when {
        typedConfirmSlot >= 0 -> SlayerMaddoxAction(typedConfirmSlot, SlayerMaddoxActionType.FINAL_PURCHASE)
        typedRestartSlot >= 0 -> SlayerMaddoxAction(typedRestartSlot, SlayerMaddoxActionType.FINAL_PURCHASE)
        genericConfirmSlot >= 0 -> SlayerMaddoxAction(genericConfirmSlot, SlayerMaddoxActionType.FINAL_PURCHASE)
        genericRestartSlot >= 0 -> SlayerMaddoxAction(genericRestartSlot, SlayerMaddoxActionType.FINAL_PURCHASE)
        desiredTierSelectSlot >= 0 -> SlayerMaddoxAction(desiredTierSelectSlot, SlayerMaddoxActionType.TIER_SELECT)
        slayerNavigationSlot >= 0 -> SlayerMaddoxAction(slayerNavigationSlot, SlayerMaddoxActionType.NAVIGATION)
        else -> SlayerMaddoxAction(-1, SlayerMaddoxActionType.NAVIGATION)
      }
    } else {
      when {
        // Pick the requested tier first so the follow-up confirm/restart uses the right level.
        desiredTierSelectSlot >= 0 -> SlayerMaddoxAction(desiredTierSelectSlot, SlayerMaddoxActionType.TIER_SELECT)
        slayerNavigationSlot >= 0 -> SlayerMaddoxAction(slayerNavigationSlot, SlayerMaddoxActionType.NAVIGATION)
        typedConfirmSlot >= 0 -> SlayerMaddoxAction(typedConfirmSlot, SlayerMaddoxActionType.FINAL_PURCHASE)
        typedRestartSlot >= 0 -> SlayerMaddoxAction(typedRestartSlot, SlayerMaddoxActionType.FINAL_PURCHASE)
        genericConfirmSlot >= 0 -> SlayerMaddoxAction(genericConfirmSlot, SlayerMaddoxActionType.FINAL_PURCHASE)
        genericRestartSlot >= 0 -> SlayerMaddoxAction(genericRestartSlot, SlayerMaddoxActionType.FINAL_PURCHASE)
        else -> SlayerMaddoxAction(-1, SlayerMaddoxActionType.NAVIGATION)
      }
    }
  }

  private fun useHotbarUtilityItem(player: Player, keywords: Array<String>): Boolean {
    if (pendingOverfluxLookDownTicks > 0) return false
    val slot = findHotbarSlotByKeywords(player, keywords)
    if (slot !in 0..8) return false

    val previousSlot = player.inventory.selectedSlot
    if (previousSlot != slot) {
      InventoryUtils.holdHotbarSlot(slot)
    }

    mc.options.keyUse?.setDown(true)
    pendingHealRelease = true
    pendingHealRestoreSlot = if (previousSlot != slot) previousSlot else -1
    return true
  }

  private fun useHotbarOverflux(player: Player): Boolean {
    if (pendingOverfluxLookDownTicks > 0) return false
    val slot = findHotbarSlotByKeywords(player, SLAYER_OVERFLUX_KEYWORDS)
    if (slot !in 0..8) return false

    val previousSlot = player.inventory.selectedSlot
    if (previousSlot != slot) {
      InventoryUtils.holdHotbarSlot(slot)
    }

    pendingOverfluxLookDownTicks = OVERFLUX_LOOK_DOWN_TICKS
    pendingOverfluxRestoreSlot = if (previousSlot != slot) previousSlot else -1
    return true
  }

  private fun clearPendingOverfluxPlacement() {
    if (pendingOverfluxLookDownTicks > 0) {
      RotationExecutor.stopRotating()
    }
    pendingOverfluxLookDownTicks = 0
    pendingOverfluxRecoverLookTicks = 0
    pendingOverfluxRestoreSlot = -1
  }

  private fun applyOverfluxRecoverLook(player: Player) {
    val target = resolveCurrentTarget() ?: if (cryptZombieSlayer.value) resolveNearestSlayerBoss() else null
    if (target != null) {
      val activeCombatMode = effectiveCombatMode(target)
      val rotation =
        if (activeCombatMode != 0) {
          rangedAimRotation(player, target, activeCombatMode)
        } else {
          AngleUtils.getRotation(target)
        }
      RotationExecutor.rotateTo(rotation, rotationStrategy)
      return
    }

    if (cryptZombieSlayer.value) {
      val bossPos = slayerBossLastPos
      if (bossPos != null) {
        RotationExecutor.rotateTo(AngleUtils.getRotation(bossPos), rotationStrategy)
      }
    }
  }

  private fun findHotbarSlotByKeywords(player: Player, keywords: Array<String>): Int {
    val inventory = player.inventory
    for (i in 0..8) {
      val stack = inventory.getItem(i)
      if (stack.isEmpty) continue
      val normalizedName = normalizeNameForMatch(stack.hoverName?.string.orEmpty())
      if (keywords.any { keyword -> normalizedName.contains(keyword) }) {
        return i
      }
    }
    return -1
  }

  private fun isSlayerBossName(normalizedName: String): Boolean {
    return SLAYER_BOSS_ENTITY_KEYWORDS.any { keyword -> normalizedName.contains(keyword) }
  }

  private fun isSlayerPriorityMobName(normalizedName: String): Boolean {
    return SLAYER_PRIORITY_MOB_KEYWORDS.any { keyword -> normalizedName.contains(keyword) }
  }

  private fun isHighTierSlayerPriorityMobName(normalizedName: String): Boolean {
    return SLAYER_HIGH_TIER_PRIORITY_MOB_KEYWORDS.any { keyword -> normalizedName.contains(keyword) }
  }

  private fun isSlayerFarmMobName(normalizedName: String): Boolean {
    if (slayerType.value == 3) {
      return isEndermanFarmMobLabel(normalizedName)
    }
    return SLAYER_FARM_MOB_KEYWORDS.any { keyword -> normalizedName.contains(keyword) }
  }

  private fun isSlayerFarmMobNames(normalizedNames: Collection<String>): Boolean {
    if (slayerType.value == 3) {
      return isEndermanFarmMobNames(normalizedNames)
    }
    return normalizedNames.any(::isSlayerFarmMobName)
  }

  private fun isEndermanFarmMobLabel(normalizedName: String): Boolean {
    val isBruiser = normalizedName.contains(ENDERMAN_HIDEOUT_FARM_MOB_KEYWORD)
    val isVoidling = normalizedName.contains(ENDERMAN_VOID_FARM_MOB_KEYWORD)
    val isEnderman = normalizedName.contains(ENDERMAN_END_FARM_MOB_KEYWORD)
    return when (endermanLocation.value) {
      0 -> isEnderman && !isBruiser && !isVoidling
      1 -> isBruiser
      2 -> isVoidling
      else -> false
    }
  }

  private fun isEndermanFarmMobNames(normalizedNames: Collection<String>): Boolean {
    val hasBruiser = normalizedNames.any { it.contains(ENDERMAN_HIDEOUT_FARM_MOB_KEYWORD) }
    val hasVoidling = normalizedNames.any { it.contains(ENDERMAN_VOID_FARM_MOB_KEYWORD) }
    val hasEnderman = normalizedNames.any { it.contains(ENDERMAN_END_FARM_MOB_KEYWORD) }
    return when (endermanLocation.value) {
      0 -> hasEnderman && !hasBruiser && !hasVoidling
      1 -> hasBruiser
      2 -> hasVoidling
      else -> false
    }
  }

  private fun readTabListLines(nowTick: Long): List<String> {
    if (slayerLastTabScanTick >= 0L && nowTick - slayerLastTabScanTick < SLAYER_TAB_SCAN_INTERVAL_TICKS) {
      return slayerTabCache
    }
    slayerLastTabScanTick = nowTick
    val connection = mc.connection ?: run {
      slayerTabCache = emptyList()
      return slayerTabCache
    }
    slayerTabCache =
      try {
        resolveTabEntries(connection)
          .mapNotNull { resolveEntryDisplayName(it) }
          .map { ChatFormatting.stripFormatting(it)?.lowercase(Locale.ROOT)?.trim() ?: "" }
          .filter { it.isNotBlank() }
      } catch (_: Exception) {
        emptyList()
      }
    return slayerTabCache
  }

  private fun resolveTabEntries(connection: Any): List<Any> {
    for (name in listOf("listPlayerEntries", "getListedOnlinePlayers", "getOnlinePlayers")) {
      val method = connection.javaClass.methods.firstOrNull { it.name == name && it.parameterCount == 0 } ?: continue
      val result = runCatching { method.invoke(connection) }.getOrNull() ?: continue
      when (result) {
        is Collection<*> -> return result.filterNotNull()
        is Iterable<*> -> return result.filterNotNull()
      }
    }
    return emptyList()
  }

  private fun resolveEntryDisplayName(entry: Any): String? {
    for (name in listOf("getTabListDisplayName", "tabListDisplayName", "getDisplayName", "displayName")) {
      val method = entry.javaClass.methods.firstOrNull { it.name == name && it.parameterCount == 0 } ?: continue
      val text = coerceText(runCatching { method.invoke(entry) }.getOrNull())
      if (!text.isNullOrBlank()) return text
    }
    for (name in listOf("getProfile", "getGameProfile", "profile")) {
      val method = entry.javaClass.methods.firstOrNull { it.name == name && it.parameterCount == 0 } ?: continue
      val profile = runCatching { method.invoke(entry) }.getOrNull() ?: continue
      val nameMethod = profile.javaClass.methods.firstOrNull { it.name == "getName" && it.parameterCount == 0 } ?: continue
      val profileName = runCatching { nameMethod.invoke(profile) as? String }.getOrNull()
      if (!profileName.isNullOrBlank()) return profileName
    }
    return null
  }

  private fun coerceText(value: Any?): String? {
    if (value == null) return null
    if (value is String) return value
    val m = value.javaClass.methods.firstOrNull { it.name == "getString" && it.parameterCount == 0 }
    val raw = m?.let { runCatching { it.invoke(value) }.getOrNull() }
    return if (raw is String) raw else value.toString()
  }

  private fun isValidTarget(
    living: LivingEntity,
    player: Player,
    blacklisted: Set<String>,
    nameFilter: String,
    requireRange: Boolean,
    ignoreWhitelist: Boolean = false
  ): Boolean {
    if (living is ArmorStand) return false
    if (living == player) return false
    if (!living.isAlive) return false
    if (living is Player && mc.connection?.getPlayerInfo(living.uuid) != null) return false
    val displayName = normalizedTargetDisplayName(living)
    if (blacklisted.contains(displayName)) return false
    if (nameFilter.isNotEmpty() && !displayName.contains(nameFilter)) return false
    if (!ignoreWhitelist && whitelistOnly.value && !automationBypassWhitelist) {
      // Only apply whitelist if there are user-learned entries beyond the default seed.
      // The default "ice walker" entry is always present and must not block all other mobs.
      val effectiveWhitelist = learnedWhitelist.filter { it != DEFAULT_WHITELIST_ENTRY && !blacklisted.contains(it) }
      if (effectiveWhitelist.isNotEmpty()) {
        val whitelistMatch = effectiveWhitelist.any { entry ->
          displayName.contains(entry) || entry.contains(displayName)
        }
        if (!whitelistMatch) return false
      }
    }
    return true
  }

  private fun enforceStartArea(
    player: Player,
    level: ClientLevel
  ): Boolean {
    if (!stayNearStart.value) return false
    // Don't fight the patrol: it defines the operational area, so overriding its
    // pathfinder here would cause false ARRIVED signals and premature point advances.
    if (CombatPatrolModule.isPatrolRunning) return false
    val origin = startAreaOrigin ?: return false
    val radius = startAreaRadius.value + START_AREA_RETURN_BUFFER
    val distSq = horizontalDistSq(player.x, player.z, origin.x + 0.5, origin.z + 0.5)
    if (distSq <= radius * radius) {
      return false
    }

    val pathAlreadyReturning = startedPath && lastTargetPos == origin && nativeActive()
    if (!pathAlreadyReturning && level.gameTime - lastPathStartTick >= MIN_PATH_START_INTERVAL_TICKS) {
      lastPathStartTick = level.gameTime
      NativePathfinder.setTarget(origin.x + 0.5, origin.y.toDouble(), origin.z + 0.5)
      if (true) {
        lastTargetPos = origin
        startedPath = true
      }
    }
    currentTargetId = null
    RotationExecutor.stopRotating()
    return true
  }

  private fun horizontalDistSq(ax: Double, az: Double, bx: Double, bz: Double): Double {
    val dx = ax - bx
    val dz = az - bz
    return dx * dx + dz * dz
  }

  private fun attemptAttack(player: Player, target: LivingEntity, activeCombatMode: Int) {
    when (activeCombatMode) {
      1    -> attemptBowAttack(player, target)
      2    -> attemptMageAttack(player, target)
      else -> attemptMeleeAttack(player, target)
    }
  }

  private fun attemptMeleeAttack(player: Player, target: LivingEntity) {
    if (!isAttackReady(player, target)) return
    val now = System.nanoTime()
    if (now < nextAttackNs) return
    val minRate = min(minCps.value, maxCps.value).coerceAtLeast(0.1)
    val maxRate = max(minCps.value, maxCps.value).coerceAtLeast(minRate)
    val cps = minRate + (Math.random() * (maxRate - minRate))
    val delayNs = (1_000_000_000.0 / cps).toLong()
    nextAttackNs = now + delayNs
    MouseUtils.leftClick()
    registerKillCandidate(target)
  }

  private fun attemptBowAttack(player: Player, target: LivingEntity) {
    if (!isRangedAttackReady(player, target, 1)) return
    val now = System.nanoTime()
    if (now < nextAttackNs) return
    val minRate = min(minCps.value, maxCps.value).coerceAtLeast(0.1)
    val maxRate = max(minCps.value, maxCps.value).coerceAtLeast(minRate)
    val cps = minRate + (Math.random() * (maxRate - minRate))
    nextAttackNs = now + (1_000_000_000.0 / cps).toLong()
    MouseUtils.rightClick()
    registerKillCandidate(target)
    if (oneTapMode.value) currentTargetId = null
  }

  private fun attemptMageAttack(player: Player, target: LivingEntity) {
    if (!isRangedAttackReady(player, target, 2)) return
    val now = System.nanoTime()
    if (now < nextAttackNs) return
    val minRate = min(minCps.value, maxCps.value).coerceAtLeast(0.1)
    val maxRate = max(minCps.value, maxCps.value).coerceAtLeast(minRate)
    val cps = minRate + (Math.random() * (maxRate - minRate))
    nextAttackNs = now + (1_000_000_000.0 / cps).toLong()
    MouseUtils.rightClick()
    registerKillCandidate(target)
    if (oneTapMode.value) currentTargetId = null
  }

  private fun isRangedAttackReady(player: Player, target: LivingEntity, activeCombatMode: Int): Boolean {
    if (!player.hasLineOfSight(target)) return false
    val aimed = rangedAimRotation(player, target, activeCombatMode)
    val yawError = abs(AngleUtils.getRotationDelta(player.yRot, aimed.yaw))
    val pitchError = abs(aimed.pitch - player.xRot)
    val tolerance = aimTolerance.value
    return yawError <= tolerance && pitchError <= tolerance
  }

  /**
   * Returns the aim rotation for ranged modes, including upward pitch correction for
   * projectile drop/lead. Falls back to standard rotation in melee mode.
   */
  private fun rangedAimRotation(
    player: Player,
    target: LivingEntity,
    activeCombatMode: Int = combatMode.value
  ): org.cobalt.api.util.helper.Rotation {
    val base = AngleUtils.getRotation(target)
    val elevPerBlock = when (activeCombatMode) {
      1    -> bowElevationPerBlock.value
      2    -> mageElevationPerBlock.value
      else -> return base
    }
    if (elevPerBlock <= 0.0) return base
    val dist = player.distanceTo(target).toFloat()
    val correction = (elevPerBlock * dist).toFloat().coerceIn(0f, 45f)
    return org.cobalt.api.util.helper.Rotation(base.yaw, base.pitch - correction)
  }

  private fun registerKillCandidate(target: LivingEntity) {
    val level = mc.level ?: return
    killCandidateId = target.uuid
    killCandidateName = resolveTargetDisplayName(target)
    killCandidateWasSlayerBoss = cryptZombieSlayer.value && isSlayerBossEntity(target)
    killCandidateWasSlayerMob =
      cryptZombieSlayer.value &&
        !killCandidateWasSlayerBoss &&
        (isSlayerPriorityMobEntity(target) || isSlayerFarmMobEntity(target))
    killCandidateAttackTick = level.gameTime
    killCandidateExpiresTick = level.gameTime + KILL_CANDIDATE_TTL_TICKS
  }

  private fun updateKillTracking(level: ClientLevel) {
    val candidateId = killCandidateId ?: return
    if (level.gameTime > killCandidateExpiresTick) {
      clearKillCandidate()
      return
    }

    val candidate = level.entitiesForRendering().firstOrNull { it.uuid == candidateId } as? LivingEntity
    if (candidate == null) {
      if (level.gameTime - killCandidateAttackTick >= KILL_DISAPPEAR_CONFIRM_TICKS) {
        onKillCandidateConfirmed(killCandidateName ?: "")
        clearKillCandidate()
      }
      return
    }
    if (candidate.isAlive && candidate.health > 0f) {
      return
    }

    onKillCandidateConfirmed(killCandidateName ?: resolveTargetDisplayName(candidate))
    clearKillCandidate()
  }

  private fun onKillCandidateConfirmed(resolvedName: String) {
    if (killCandidateWasSlayerMob) {
      slayerSessionMobKills++
      if (slayerTrackedQuestActive && !slayerBossActive) {
        slayerTrackedQuestSawMobKill = true
      }
    }
    if (autoLearnLastKill.value) {
      applyLearnedKillTarget(resolvedName)
    }
    if (oneTapMode.value) currentTargetId = null
  }

  private fun clearKillCandidate() {
    killCandidateId = null
    killCandidateName = null
    killCandidateWasSlayerMob = false
    killCandidateWasSlayerBoss = false
    killCandidateExpiresTick = 0L
    killCandidateAttackTick = 0L
  }

  private fun applyLearnedKillTarget(rawName: String) {
    val learnedName = sanitizeTargetName(rawName)
    if (learnedName.isBlank()) return
    var changed = false

    if (targetName.value != learnedName) {
      targetName.value = learnedName
      changed = true
    }
    if (lastKillText.value != learnedName) {
      lastKillText.value = learnedName
      changed = true
    }
    if (learnedWhitelist.add(learnedName.lowercase())) {
      changed = true
    }

    val serializedWhitelist = serializeWhitelist()
    if (learnedWhitelistText.value != serializedWhitelist) {
      learnedWhitelistText.value = serializedWhitelist
      changed = true
    }
    lastSyncedWhitelistRaw = learnedWhitelistText.value

    ChatUtils.sendMessage("Combat macro learned target: $learnedName")
    if (changed) {
      Config.saveModulesConfig()
    }
  }

  private fun sanitizeTargetName(raw: String): String {
    val noFormatting = raw.replace(Regex("\\u00A7."), "").trim()
    val noLevelPrefix = noFormatting.replace(Regex("^\\[[^\\]]+\\]\\s*"), "")
    val noSymbolsPrefix = noLevelPrefix.replace(Regex("^[^A-Za-z0-9]+"), "")
    val noHpSuffix = noSymbolsPrefix.replace(Regex("\\s+[0-9.,]+(?:/[0-9.,]+)?(?:[kKmMbB])?\\s*[\\u2764]?$"), "")
    return noHpSuffix.replace(Regex("\\s+"), " ").trim()
  }

  private fun normalizeNameForMatch(raw: String): String {
    return sanitizeTargetName(raw).lowercase()
  }

  private fun resolveTargetDisplayName(living: LivingEntity): String {
    val baseName = sanitizeTargetName(living.name.string)
    val standNames = findAttachedArmorStandNames(living)
    if (standNames.isEmpty()) return baseName
    val baseNormalized = normalizeNameForMatch(baseName)
    val preferred = standNames.maxByOrNull { name -> scoreAttachedDisplayName(normalizeNameForMatch(name), baseNormalized) }
      ?: return baseName
    return if (scoreAttachedDisplayName(normalizeNameForMatch(preferred), baseNormalized) > 0) preferred else baseName
  }

  private fun normalizedTargetDisplayName(living: LivingEntity): String =
    normalizeNameForMatch(resolveTargetDisplayName(living))

  private fun targetMatchNames(living: LivingEntity): List<String> {
    val names = LinkedHashSet<String>()
    val baseName = normalizeNameForMatch(sanitizeTargetName(living.name.string))
    if (baseName.isNotBlank()) {
      names.add(baseName)
    }
    for (standName in findAttachedArmorStandNames(living)) {
      val normalized = normalizeNameForMatch(standName)
      if (normalized.isNotBlank()) {
        names.add(normalized)
      }
    }
    return names.toList()
  }

  private fun isSlayerBossEntity(living: LivingEntity): Boolean =
    targetMatchNames(living).any(::isSlayerBossName)

  /** Returns true if an attached armor stand confirms this is the local player's boss.
   *  Falls back to true when no armor stands are present yet (they load slightly after the entity). */
  private fun isSlayerBossOwnedByPlayer(living: LivingEntity): Boolean {
    val playerName = mc.player?.name?.string?.lowercase(Locale.ROOT) ?: return true
    val standNames = findAttachedArmorStandNames(living)
    if (standNames.isEmpty()) return true
    return standNames.any { it.lowercase(Locale.ROOT).contains(playerName) }
  }

  private fun isSlayerPriorityMobEntity(living: LivingEntity): Boolean =
    targetMatchNames(living).any(::isSlayerPriorityMobName)

  private fun isSlayerFarmMobEntity(living: LivingEntity): Boolean =
    isSlayerFarmMobNames(targetMatchNames(living))

  private fun matchesEntityLabel(living: LivingEntity, matcher: (String) -> Boolean): Boolean =
    targetMatchNames(living).any(matcher)

  private fun scoreAttachedDisplayName(normalizedName: String, baseNormalized: String): Int {
    if (normalizedName.isBlank()) return Int.MIN_VALUE
    var score = 0
    if (normalizedName == baseNormalized) score += 300
    if (baseNormalized.isNotBlank() && (normalizedName.contains(baseNormalized) || baseNormalized.contains(normalizedName))) {
      score += 120
    }
    if (isSlayerBossName(normalizedName)) score += 1200
    if (isSlayerPriorityMobName(normalizedName)) score += 900
    if (isSlayerFarmMobName(normalizedName)) score += 700
    if (normalizedName.any(Char::isLetter)) score += 80
    if (isTransientAttachedLabel(normalizedName)) score -= 600
    return score
  }

  private fun isTransientAttachedLabel(normalizedName: String): Boolean {
    return ENDERMAN_HITS_PATTERNS.any { pattern -> pattern.containsMatchIn(normalizedName) } ||
      ATTACHED_LABEL_TRANSIENT_KEYWORDS.any { keyword -> normalizedName.contains(keyword) }
  }

  private fun findAttachedArmorStandNames(
    living: LivingEntity,
    horizontalRangeSq: Double = ATTACHED_NAMEPLATE_HORIZONTAL_RANGE_SQ
  ): List<String> {
    val level = mc.level ?: return emptyList()
    return level.entitiesForRendering()
      .asSequence()
      .filterIsInstance<ArmorStand>()
      .filter { it.isAlive }
      .filter { stand ->
        stand.y >= living.y - 0.5 &&
          stand.y <= living.y + 3.5 &&
          horizontalDistSq(stand.x, stand.z, living.x, living.z) <= horizontalRangeSq
      }
      .map { stand -> stand to sanitizeTargetName(stand.name.string) }
      .filter { (_, name) -> name.isNotBlank() }
      .filter { (_, name) -> !builtInBlacklistedNames.contains(normalizeNameForMatch(name)) }
      .sortedBy { (stand, _) ->
        horizontalDistSq(stand.x, stand.z, living.x, living.z) + kotlin.math.abs(stand.y - living.y)
      }
      .map { (_, name) -> name }
      .toList()
  }

  private fun resolveCurrentTarget(): LivingEntity? {
    val level = mc.level ?: return null
    val targetId = currentTargetId ?: return null
    val liveTarget = level.entitiesForRendering().firstOrNull { it.uuid == targetId } as? LivingEntity ?: return null
    if (!liveTarget.isAlive || liveTarget.health <= 0f) return null
    return liveTarget
  }

  private fun resolveCurrentTargetName(): String? {
    return resolveCurrentTarget()?.let { target ->
      resolveTargetDisplayName(target).ifBlank { null }
    }
  }

  private fun formatHudHealth(value: Float): String {
    val rounded = (value * 10f).toInt() / 10f
    return if (rounded % 1f == 0f) {
      rounded.toInt().toString()
    } else {
      rounded.toString()
    }
  }

  private fun syncAutoItemToggles(player: Player) {
    var changed = false

    val wandInHotbar = findHotbarSlotByKeywords(player, SLAYER_WAND_OF_ATONEMENT_KEYWORDS) in 0..8
    if (wandInHotbar && !wandWasInHotbar && !autoWandOfAtonement.value) {
      autoWandOfAtonement.value = true
      changed = true
    }
    wandWasInHotbar = wandInHotbar

    val hyperionInHotbar = findHotbarSlotByKeywords(player, SLAYER_HYPERION_KEYWORDS) in 0..8
    if (hyperionInHotbar && !hyperionWasInHotbar && !autoHyperion.value) {
      autoHyperion.value = true
      changed = true
    }
    hyperionWasInHotbar = hyperionInHotbar

    val zombieSwordInHotbar = findHotbarSlotByKeywords(player, SLAYER_ZOMBIE_SWORD_KEYWORDS) in 0..8
    if (zombieSwordInHotbar && !zombieSwordWasInHotbar && !autoZombieSword.value) {
      autoZombieSword.value = true
      changed = true
    }
    zombieSwordWasInHotbar = zombieSwordInHotbar

    val overfluxInHotbar = findHotbarSlotByKeywords(player, SLAYER_OVERFLUX_KEYWORDS) in 0..8
    if (overfluxInHotbar && !overfluxWasInHotbar && !autoOverflux.value) {
      autoOverflux.value = true
      changed = true
    }
    overfluxWasInHotbar = overfluxInHotbar

    val ragnarokInHotbar = findHotbarSlotByKeywords(player, SLAYER_RAGNAROK_KEYWORDS) in 0..8
    if (ragnarokInHotbar && !ragnarokWasInHotbar && !autoRagnarok.value) {
      autoRagnarok.value = true
      changed = true
    }
    ragnarokWasInHotbar = ragnarokInHotbar

    val reaperScytheInHotbar = findHotbarSlotByKeywords(player, SLAYER_REAPER_SCYTHE_KEYWORDS) in 0..8
    if (reaperScytheInHotbar && !reaperScytheWasInHotbar && !autoReaperScythe.value) {
      autoReaperScythe.value = true
      changed = true
    }
    reaperScytheWasInHotbar = reaperScytheInHotbar

    val badHealthInHotbar = findHotbarSlotByKeywords(player, SLAYER_BAD_HEALTH_KEYWORDS) in 0..8
    if (badHealthInHotbar && !badHealthWasInHotbar && !autoSwordOfBadHealth.value) {
      autoSwordOfBadHealth.value = true
      changed = true
    }
    badHealthWasInHotbar = badHealthInHotbar

    if (changed) {
      Config.saveModulesConfig()
    }
  }

  private fun syncLearnedWhitelistFromSetting() {
    val raw = learnedWhitelistText.value
    if (raw == lastSyncedWhitelistRaw) return

    learnedWhitelist.clear()
    deserializeWhitelist(raw).forEach { learnedWhitelist.add(it) }
    learnedWhitelist.add(DEFAULT_WHITELIST_ENTRY)

    val normalized = serializeWhitelist()
    lastSyncedWhitelistRaw = normalized
    if (learnedWhitelistText.value != normalized) {
      learnedWhitelistText.value = normalized
    }
  }

  private fun deserializeWhitelist(raw: String): List<String> {
    if (raw.isBlank() || raw.equals("EMPTY", ignoreCase = true)) return emptyList()
    return raw
      .split(",")
      .asSequence()
      .map { it.trim().removeSuffix("...") }
      .filter { it.isNotEmpty() }
      .map(::normalizeNameForMatch)
      .filter { it.isNotBlank() && it != "empty" }
      .distinct()
      .toList()
  }

  private fun serializeWhitelist(): String {
    if (learnedWhitelist.isEmpty()) return "EMPTY"
    return learnedWhitelist.joinToString(", ")
  }

  private fun effectiveCombatMode(target: LivingEntity?): Int {
    if (target == null) return combatMode.value
    if (shouldUseSpiderPhaseBowCombat() && slayerBossActive && isSpiderBossHatchlingsPhaseActive()) {
      if (isSlayerBossEntity(target) || matchesEntityLabel(target, ::isSpiderPhaseAddName)) return 1
    }
    if (shouldUseEndermanDynamicCombat()) {
      if (!isSlayerBossEntity(target)) return effectiveEndermanSpawnCombatMode(target)
      return if (isEndermanBossHitPhase(target)) effectiveEndermanHitPhaseCombatMode() else 0
    }
    return combatMode.value
  }

  private fun shouldUseZombieDynamicCombat(): Boolean {
    return cryptZombieSlayer.value && slayerType.value == 0 && zombieDynamicCombat.value
  }

  private fun shouldUseSpiderPhaseBowCombat(): Boolean {
    return cryptZombieSlayer.value && slayerType.value == 2 && spiderPhaseBowCombat.value
  }

  private fun shouldUseWolfPupsLogic(): Boolean {
    return cryptZombieSlayer.value && slayerType.value == 1
  }

  private fun shouldUseEndermanDynamicCombat(): Boolean {
    return cryptZombieSlayer.value && slayerType.value == 3 && endermanDynamicCombat.value
  }

  private fun effectiveEndermanSpawnCombatMode(target: LivingEntity): Int {
    return when (emanSpawnWeapon.value) {
      EMAN_SPAWN_WEAPON_ENDERMAN_SWORD -> 0
      EMAN_SPAWN_WEAPON_DYNAMIC -> if (shouldUseDynamicEndermanSpawnMelee(target)) 0 else 1
      else -> 1
    }
  }

  private fun effectiveEndermanHitPhaseCombatMode(): Int {
    return when (emanHitPhaseStyle.value) {
      EMAN_HIT_PHASE_WEAPON_ENDERMAN_SWORD -> 0
      else -> 1
    }
  }

  private fun shouldUseDynamicEndermanSpawnMelee(target: LivingEntity): Boolean {
    if (isSlayerPriorityMobEntity(target)) return true
    val player = mc.player ?: return false
    return player.distanceTo(target).toDouble() <= emanDynamicSwapRange.value
  }


  private fun shouldSuppressSlayerAttack(target: LivingEntity, nowTick: Long): Boolean {
    if (!cryptZombieSlayer.value) return false
    if (!isSlayerBossEntity(target)) return false
    return isSpiderBossHatchlingsPhaseActive(nowTick) || isWolfBossPupsPhaseActive(nowTick)
  }

  private fun handleSlayerPhaseMovement(
    player: Player,
    target: LivingEntity,
    distanceToTarget: Double,
    hasLos: Boolean,
    activeCombatMode: Int,
    nowTick: Long
  ): Boolean {
    if (!cryptZombieSlayer.value) return false
    // Laser phase takes priority over hits phase movement.
    if (shouldUseEndermanDynamicCombat() && emanLaserPhaseActive && isSlayerBossEntity(target)) {
      return applyEndermanLaserPhaseMovement(player)
    }
    if (shouldUseEndermanDynamicCombat() && isSlayerBossEntity(target) && isEndermanBossHitPhase(target)) {
      if (effectiveEndermanHitPhaseCombatMode() == 0) return false
      return applyEmanHitsPhaseStandoffMovement(player, target, distanceToTarget)
    }
    if (shouldUseSpiderPhaseBowCombat() && activeCombatMode == 1 && hasLos && isSpiderBossHatchlingsPhaseActive(nowTick)) {
      if (isSlayerBossEntity(target) || matchesEntityLabel(target, ::isSpiderPhaseAddName)) {
        return applySpiderPhaseStepBackMovement(player, target, distanceToTarget)
      }
    }
    if (shouldUseWolfPupsLogic() && wolfIgnorePups.value && isWolfBossPupsPhaseActive(nowTick)) {
      if (isSlayerBossEntity(target)) {
        MovementManager.clearForcedMovement()
        return true
      }
    }
    return false
  }

  private fun applySpiderPhaseStepBackMovement(
    player: Player,
    target: LivingEntity,
    distanceToTarget: Double
  ): Boolean {
    val desiredDistance = max(SPIDER_PHASE_MIN_BACKSTEP_DISTANCE, combatEngageRange(1) - SPIDER_PHASE_STEPBACK_BUFFER)
    if (distanceToTarget > desiredDistance + SPIDER_PHASE_STEPBACK_HYSTERESIS) return false

    val rotation = rangedAimRotation(player, target, 1)
    RotationExecutor.rotateTo(rotation, rotationStrategy)
    val yawError = abs(AngleUtils.getRotationDelta(player.yRot, rotation.yaw))
    val pitchError = abs(rotation.pitch - player.xRot)
    val aligned = yawError <= SPIDER_PHASE_STEPBACK_YAW_TOLERANCE &&
      pitchError <= SPIDER_PHASE_STEPBACK_PITCH_TOLERANCE

    if (aligned && distanceToTarget < desiredDistance) {
      MovementManager.setForcedMovement(
        forward = false, backward = true,
        left = false, right = false,
        jump = false, shift = false, sprint = false
      )
    } else {
      MovementManager.clearForcedMovement()
    }
    return true
  }

  private fun applyEmanHitsPhaseStandoffMovement(
    player: Player,
    target: LivingEntity,
    distanceToTarget: Double
  ): Boolean {
    // Bow mode: maintain the configured bow engage range (e.g. 7 blocks for term/shortbow).
    // Sword mode: keep the original close-in standoff (attackRange + buffer).
    val hitPhaseCombatMode = effectiveEndermanHitPhaseCombatMode()
    val standoffMin: Double
    val standoffMax: Double
    if (hitPhaseCombatMode != 0) {
      val bowRange = combatEngageRange(1)
      standoffMin = (bowRange - EMAN_HITS_PHASE_STANDOFF_BUFFER).coerceAtLeast(EMAN_HITS_PHASE_MIN_STANDOFF)
      standoffMax = bowRange + EMAN_HITS_PHASE_STANDOFF_BUFFER
    } else {
      standoffMin = EMAN_HITS_PHASE_MIN_STANDOFF
      standoffMax = attackRange.value + EMAN_HITS_PHASE_STANDOFF_BUFFER
    }
    if (distanceToTarget > standoffMax + EMAN_HITS_PHASE_STANDOFF_HYSTERESIS) return false
    val rotation = AngleUtils.getRotation(target)
    RotationExecutor.rotateTo(rotation, rotationStrategy)
    val yawError = abs(AngleUtils.getRotationDelta(player.yRot, rotation.yaw))
    val aligned = yawError <= EMAN_HITS_PHASE_YAW_TOLERANCE
    if (aligned && distanceToTarget < standoffMin) {
      MovementManager.setForcedMovement(
        forward = false, backward = true,
        left = false, right = false,
        jump = false, shift = false, sprint = false
      )
    } else if (aligned && distanceToTarget > combatEngageRange(hitPhaseCombatMode)) {
      MovementManager.setForcedMovement(
        forward = true, backward = false,
        left = false, right = false,
        jump = false, shift = false, sprint = true
      )
    } else {
      MovementManager.clearForcedMovement()
    }
    return true
  }

  /** During the enderman laser phase: jump continuously to dodge beams, then try to AOTV onto any nearby beacons. */
  private fun applyEndermanLaserPhaseMovement(player: Player): Boolean {
    // Look straight up for AOTV upward use.
    val lookUpRotation = Rotation(player.yRot, -90f)
    RotationExecutor.rotateTo(lookUpRotation, rotationStrategy)

    val shouldAotvUp = player.onGround() &&
      findHotbarSlotByKeywords(player, EMAN_LASER_AOTV_KEYWORDS) in 0..8
    if (shouldAotvUp) {
      // Look up and use AOTV to teleport ~11 blocks upward.
      useHotbarUtilityItem(player, EMAN_LASER_AOTV_KEYWORDS)
    } else {
      // Fallback: jump continuously to dodge beams.
      MovementManager.setForcedMovement(
        forward = false, backward = false,
        left = false, right = false,
        jump = player.onGround(), shift = false, sprint = false
      )
    }

    // AOTV onto nearby beacon blocks to disable them.
    tryAotvOntoBeacon(player)

    return true
  }

  private fun tryAotvOntoBeacon(player: Player) {
    val level = mc.level ?: return
    val aotvSlot = findHotbarSlotByKeywords(player, EMAN_LASER_AOTV_KEYWORDS)
    if (aotvSlot !in 0..8) return

    val px = player.blockX
    val py = player.blockY
    val pz = player.blockZ

    for (dx in -EMAN_BEACON_SCAN_RADIUS..EMAN_BEACON_SCAN_RADIUS) {
      for (dz in -EMAN_BEACON_SCAN_RADIUS..EMAN_BEACON_SCAN_RADIUS) {
        for (dy in -EMAN_BEACON_SCAN_RADIUS..EMAN_BEACON_SCAN_RADIUS) {
          val pos = net.minecraft.core.BlockPos(px + dx, py + dy, pz + dz)
          val state = level.getBlockState(pos)
          if (state.`is`(net.minecraft.world.level.block.Blocks.BEACON)) {
            // Aim at the top of the beacon and use AOTV.
            val beaconTop = net.minecraft.world.phys.Vec3(pos.x + 0.5, pos.y + 1.0, pos.z + 0.5)
            val rotation = AngleUtils.getRotation(player.eyePosition, beaconTop)
            RotationExecutor.rotateTo(rotation, rotationStrategy)
            useHotbarUtilityItem(player, EMAN_LASER_AOTV_KEYWORDS)
            return
          }
        }
      }
    }
  }

  private fun updateSlayerBossPhaseState(level: ClientLevel, boss: LivingEntity?) {
    updateSpiderHatchlingsPhaseState(level, boss)
    updateWolfPupsPhaseState(level, boss)
    updateEndermanLaserPhaseState(level, boss)
  }

  private fun updateEndermanLaserPhaseState(level: ClientLevel, boss: LivingEntity?) {
    if (!shouldUseEndermanDynamicCombat()) {
      if (emanLaserPhaseActive) clearEndermanLaserPhase()
      return
    }
    val detected = boss != null && isEndermanBossLaserPhase(boss)
    if (detected && !emanLaserPhaseActive) {
      emanLaserPhaseActive = true
      emanLaserPhaseStartTick = level.gameTime
      slayerRagnarokUsedForLaserPhase = false
    } else if (!detected && emanLaserPhaseActive) {
      clearEndermanLaserPhase()
    }
  }

  private fun clearEndermanLaserPhase() {
    emanLaserPhaseActive = false
    emanLaserPhaseStartTick = -1L
  }

  private fun isEndermanBossLaserPhase(target: LivingEntity): Boolean {
    if (!shouldUseEndermanDynamicCombat()) return false
    if (!isSlayerBossEntity(target)) return false
    return findAttachedArmorStandNames(target, ENDERMAN_HITS_HORIZONTAL_RANGE_SQ)
      .asSequence()
      .map(::normalizeNameForMatch)
      .any { name -> ENDERMAN_LASER_TEXT_KEYWORDS.any { kw -> name.contains(kw) } }
  }

  private fun resolveSlayerPhaseTarget(
    player: Player,
    level: ClientLevel,
    boss: LivingEntity?
  ): LivingEntity? {
    val wantsSpiderAdds = shouldUseSpiderPhaseBowCombat() && isSpiderBossHatchlingsPhaseActive(level.gameTime)
    val wantsWolfAdds = shouldUseWolfPupsLogic() && !wolfIgnorePups.value && isWolfBossPupsPhaseActive(level.gameTime)
    if (!wantsSpiderAdds && !wantsWolfAdds) return null

    val bossPos = boss?.position() ?: slayerBossLastPos ?: return null
    val blacklisted = builtInBlacklistedNames
    var best: LivingEntity? = null
    var bestDistSq = Double.POSITIVE_INFINITY

    for (entity in level.entitiesForRendering()) {
      val living = entity as? LivingEntity ?: continue
      if (!isValidTarget(living, player, blacklisted, "", true, ignoreWhitelist = true)) continue
      if (isSlayerBossEntity(living)) continue

      val matchesPhaseTarget =
        when {
          wantsSpiderAdds -> matchesEntityLabel(living, ::isSpiderPhaseAddName)
          wantsWolfAdds -> matchesEntityLabel(living, ::isWolfPhaseAddName)
          else -> false
        }
      if (!matchesPhaseTarget) continue
      if (horizontalDistSq(living.x, living.z, bossPos.x, bossPos.z) > SLAYER_PHASE_ADD_SEARCH_RADIUS_SQ) continue

      val dx = living.x - player.x
      val dy = living.y - player.y
      val dz = living.z - player.z
      val distSq = dx * dx + dy * dy + dz * dz
      if (distSq < bestDistSq) {
        best = living
        bestDistSq = distSq
      }
    }

    return best
  }

  private fun activateSpiderHatchlingsPhase(nowTick: Long) {
    if (!shouldUseSpiderPhaseBowCombat()) return
    spiderHatchlingsPhaseActive = true
    spiderHatchlingsPhaseUntilTick =
      if (nowTick >= 0L) nowTick + SPIDER_HATCHLING_PHASE_FALLBACK_TICKS else -1L
    val boss = resolveNearestSlayerBoss()
    spiderHatchlingsBossId = boss?.uuid
    spiderHatchlingsBossAnchor = boss?.position() ?: slayerBossLastPos
  }

  private fun clearSpiderHatchlingsPhase() {
    spiderHatchlingsPhaseActive = false
    spiderHatchlingsPhaseUntilTick = -1L
    spiderHatchlingsBossId = null
    spiderHatchlingsBossAnchor = null
  }

  private fun updateSpiderHatchlingsPhaseState(level: ClientLevel, boss: LivingEntity?) {
    if (!shouldUseSpiderPhaseBowCombat()) {
      clearSpiderHatchlingsPhase()
      return
    }
    if (!spiderHatchlingsPhaseActive) return
    if (!slayerBossActive) {
      clearSpiderHatchlingsPhase()
      return
    }

    val trackedBoss = resolveTrackedSpiderPhaseBoss(level, boss)
    if (trackedBoss != null) {
      if (spiderHatchlingsBossId == null) spiderHatchlingsBossId = trackedBoss.uuid
      if (spiderHatchlingsBossAnchor == null) spiderHatchlingsBossAnchor = trackedBoss.position()
      val anchor = spiderHatchlingsBossAnchor
      if (anchor != null && trackedBoss.position().distanceTo(anchor) >= SPIDER_HATCHLING_CLEAR_DISTANCE) {
        clearSpiderHatchlingsPhase()
        return
      }
    }

    if (spiderHatchlingsPhaseUntilTick >= 0L && level.gameTime >= spiderHatchlingsPhaseUntilTick) {
      if (trackedBoss != null && hasNearbySpiderPhaseAdds(level, trackedBoss)) {
        spiderHatchlingsPhaseUntilTick = level.gameTime + SPIDER_HATCHLING_PHASE_REFRESH_TICKS
      } else {
        clearSpiderHatchlingsPhase()
      }
    }
  }

  private fun updateWolfPupsPhaseState(level: ClientLevel, boss: LivingEntity?) {
    if (!shouldUseWolfPupsLogic()) {
      wolfPupsPhaseUntilTick = -1L
      return
    }
    if (!slayerBossActive || boss == null) {
      wolfPupsPhaseUntilTick = -1L
      return
    }

    if (hasNearbyAttachedText(boss, SLAYER_WOLF_PUPS_TEXT_KEYWORDS)) {
      wolfPupsPhaseUntilTick = level.gameTime + SLAYER_WOLF_PUPS_PHASE_TICKS
    } else if (wolfPupsPhaseUntilTick >= 0L && level.gameTime >= wolfPupsPhaseUntilTick) {
      wolfPupsPhaseUntilTick = -1L
    }
  }

  private fun isSpiderBossHatchlingsPhaseActive(nowTick: Long = mc.level?.gameTime ?: -1L): Boolean {
    if (!shouldUseSpiderPhaseBowCombat() || !spiderHatchlingsPhaseActive) return false
    return spiderHatchlingsPhaseUntilTick < 0L || nowTick < spiderHatchlingsPhaseUntilTick
  }

  private fun isWolfBossPupsPhaseActive(nowTick: Long = mc.level?.gameTime ?: -1L): Boolean {
    if (!shouldUseWolfPupsLogic()) return false
    return wolfPupsPhaseUntilTick >= 0L && nowTick < wolfPupsPhaseUntilTick
  }

  private fun resolveNearestSlayerBoss(): LivingEntity? {
    val level = mc.level ?: return null
    val player = mc.player
    return level.entitiesForRendering()
      .asSequence()
      .filterIsInstance<LivingEntity>()
      .filter { it.isAlive && it.health > 0f }
      .filter(::isSlayerBossEntity)
      .minByOrNull { entity ->
        if (player != null) {
          val dx = entity.x - player.x
          val dy = entity.y - player.y
          val dz = entity.z - player.z
          dx * dx + dy * dy + dz * dz
        } else {
          0.0
        }
      }
  }

  private fun resolveTrackedSpiderPhaseBoss(level: ClientLevel, fallbackBoss: LivingEntity?): LivingEntity? {
    val trackedId = spiderHatchlingsBossId
    if (trackedId != null) {
      val tracked = level.entitiesForRendering().firstOrNull { it.uuid == trackedId } as? LivingEntity
      if (tracked != null && tracked.isAlive && tracked.health > 0f) {
        return tracked
      }
    }
    return fallbackBoss?.takeIf { it.isAlive && it.health > 0f && isSlayerBossEntity(it) }
  }

  private fun hasNearbySpiderPhaseAdds(level: ClientLevel, boss: LivingEntity): Boolean {
    val bossPos = boss.position()
    return level.entitiesForRendering()
      .asSequence()
      .filterIsInstance<LivingEntity>()
      .filter { it.isAlive && it.health > 0f }
      .filter { entity -> !isSlayerBossEntity(entity) }
      .any { entity ->
        matchesEntityLabel(entity, ::isSpiderPhaseAddName) &&
          horizontalDistSq(entity.x, entity.z, bossPos.x, bossPos.z) <= SLAYER_PHASE_ADD_SEARCH_RADIUS_SQ
      }
  }

  private fun hasNearbyAttachedText(target: LivingEntity, keywords: Array<String>): Boolean {
    val level = mc.level ?: return false
    return level.entitiesForRendering()
      .asSequence()
      .filterIsInstance<ArmorStand>()
      .filter { it.isAlive }
      .filter { stand ->
        stand.y >= target.y - 0.5 &&
          stand.y <= target.y + 3.5 &&
          horizontalDistSq(stand.x, stand.z, target.x, target.z) <= ATTACHED_NAMEPLATE_HORIZONTAL_RANGE_SQ
      }
      .map { stand -> normalizeNameForMatch(stand.name.string) }
      .any { text -> keywords.any { keyword -> text.contains(keyword) } }
  }

  private fun isSpiderPhaseAddName(normalizedName: String): Boolean {
    return SLAYER_SPIDER_PHASE_ADD_KEYWORDS.any { keyword -> normalizedName.contains(keyword) }
  }

  private fun isWolfPhaseAddName(normalizedName: String): Boolean {
    return SLAYER_WOLF_PHASE_ADD_KEYWORDS.any { keyword -> normalizedName.contains(keyword) }
  }

  private fun isEndermanBossHitPhase(target: LivingEntity): Boolean {
    if (!shouldUseEndermanDynamicCombat()) return false
    if (!isSlayerBossEntity(target)) return false
    return findAttachedArmorStandNames(target, ENDERMAN_HITS_HORIZONTAL_RANGE_SQ)
      .asSequence()
      .map(::normalizeNameForMatch)
      .any { name ->
        ENDERMAN_HITS_PATTERNS.any { pattern -> pattern.containsMatchIn(name) } ||
          ENDERMAN_HITS_TEXT_KEYWORDS.any { keyword -> name.contains(keyword) }
      }
  }

  private fun keywordSettingValues(raw: String, fallback: Array<String>): Array<String> {
    val parsed = raw
      .split(',', ';', '\n')
      .map(::normalizeNameForMatch)
      .filter { it.isNotBlank() }
      .distinct()
    return if (parsed.isEmpty()) fallback else parsed.toTypedArray()
  }

  private fun preferredEndermanSpawnWeaponKeywords(target: LivingEntity?): Array<String> {
    return when (emanSpawnWeapon.value) {
      EMAN_SPAWN_WEAPON_TERMINATOR -> SLAYER_ENDERMAN_TERMINATOR_WEAPON_KEYWORDS
      EMAN_SPAWN_WEAPON_SHORTBOW -> SLAYER_ENDERMAN_SHORTBOW_WEAPON_KEYWORDS
      EMAN_SPAWN_WEAPON_ENDERMAN_SWORD ->
        keywordSettingValues(emanBossWeapon.value, SLAYER_ENDERMAN_BOSS_WEAPON_DEFAULT_KEYWORDS)
      EMAN_SPAWN_WEAPON_DYNAMIC ->
        if (target != null && shouldUseDynamicEndermanSpawnMelee(target)) {
          keywordSettingValues(emanBossWeapon.value, SLAYER_ENDERMAN_BOSS_WEAPON_DEFAULT_KEYWORDS)
        } else {
          SLAYER_ENDERMAN_DYNAMIC_BOW_WEAPON_KEYWORDS
        }
      else -> SLAYER_ENDERMAN_DYNAMIC_BOW_WEAPON_KEYWORDS
    }
  }

  private fun preferredEndermanHitPhaseWeaponKeywords(): Array<String> {
    return when (emanHitPhaseStyle.value) {
      EMAN_HIT_PHASE_WEAPON_SHORTBOW -> SLAYER_ENDERMAN_SHORTBOW_WEAPON_KEYWORDS
      EMAN_HIT_PHASE_WEAPON_ENDERMAN_SWORD ->
        keywordSettingValues(emanBossWeapon.value, SLAYER_ENDERMAN_BOSS_WEAPON_DEFAULT_KEYWORDS)
      else -> SLAYER_ENDERMAN_TERMINATOR_WEAPON_KEYWORDS
    }
  }

  private fun preferredSlayerWeaponKeywords(activeCombatMode: Int, target: LivingEntity?): Array<String> {
    return when {
      shouldUseZombieDynamicCombat() && slayerBossActive ->
        keywordSettingValues(zombieDynamicSword.value, SLAYER_ZOMBIE_DYNAMIC_SWORD_DEFAULT_KEYWORDS)
      shouldUseZombieDynamicCombat() ->
        keywordSettingValues(zombieSpawnWeapon.value, SLAYER_ZOMBIE_SPAWN_WEAPON_DEFAULT_KEYWORDS)
      shouldUseEndermanDynamicCombat() && target != null &&
        isSlayerBossEntity(target) && isEndermanBossHitPhase(target) ->
        preferredEndermanHitPhaseWeaponKeywords()
      shouldUseEndermanDynamicCombat() && target != null &&
        isSlayerBossEntity(target) ->
        keywordSettingValues(emanBossWeapon.value, SLAYER_ENDERMAN_BOSS_WEAPON_DEFAULT_KEYWORDS)
      shouldUseEndermanDynamicCombat() ->
        preferredEndermanSpawnWeaponKeywords(target)
      activeCombatMode == 0 -> SLAYER_MELEE_WEAPON_KEYWORDS
      activeCombatMode == 1 -> SLAYER_BOW_WEAPON_KEYWORDS
      activeCombatMode == 2 -> SLAYER_MAGE_WEAPON_KEYWORDS
      else -> SLAYER_ANY_WEAPON_KEYWORDS
    }
  }

  private fun findPreferredSlayerWeaponSlot(player: Player, activeCombatMode: Int, target: LivingEntity?): Int {
    val primaryKeywords = preferredSlayerWeaponKeywords(activeCombatMode, target)
    val primarySlot = findHotbarSlotByKeywords(player, primaryKeywords)
    if (primarySlot in 0..8) return primarySlot
    return findHotbarSlotByKeywords(player, SLAYER_ANY_WEAPON_KEYWORDS)
  }

  private fun isSlayerWeaponForMode(normalizedName: String, activeCombatMode: Int, target: LivingEntity?): Boolean {
    val keywords = preferredSlayerWeaponKeywords(activeCombatMode, target)
    return keywords.any { keyword -> normalizedName.contains(keyword) }
  }

  private fun ensurePreferredWeapon(player: Player, target: LivingEntity, nowTick: Long) {
    val name = normalizedTargetDisplayName(target)
    if (!prefersDrillForTargetName(name)) return
    ensureWalkerDrillSelected(player, nowTick, name)
  }

  private fun prefersDrillForTargetName(rawName: String): Boolean {
    val normalized = normalizeNameForMatch(rawName)
    return normalized.contains("ice walker") || normalized.contains("glacite walker")
  }

  private fun ensureWalkerDrillSelected(player: Player, nowTick: Long, rawTargetName: String) {
    val selected = player.inventory.getItem(player.inventory.selectedSlot)
    val selectedName = normalizeNameForMatch(selected.hoverName?.string.orEmpty())
    if (selectedName.contains("drill")) return

    val drillSlot = InventoryUtils.findItemInHotbar("drill")
    if (drillSlot in 0..8) {
      InventoryUtils.holdHotbarSlot(drillSlot)
      return
    }

    if (nowTick - drillWarnTick >= DRILL_WARN_INTERVAL_TICKS) {
      drillWarnTick = nowTick
      val label = normalizeNameForMatch(rawTargetName).ifBlank { "glacite walker" }
      ChatUtils.sendMessage("Combat macro: no drill found in hotbar for $label target.")
    }
  }

  /** Ensures a weapon is selected when in slayer mode. Switches away from utility items
   *  (batphone, overflux, etc.) to the nearest sword/weapon in the hotbar. */
  private fun ensureSlayerWeapon(player: Player, target: LivingEntity?): Boolean {
    if (pendingHealRelease || pendingHealRestoreSlot >= 0) return false
    val activeCombatMode = effectiveCombatMode(target)
    val currentSlot = player.inventory.selectedSlot
    if (shouldPrimeEmanHitPhaseBossWeapon(target)) {
      val bossSlot = findHotbarSlotByKeywords(
        player,
        keywordSettingValues(emanBossWeapon.value, SLAYER_ENDERMAN_BOSS_WEAPON_DEFAULT_KEYWORDS)
      )
      if (!emanHitPhaseBossWeaponPrimed) {
        emanHitPhaseBossWeaponPrimed = true
        if (bossSlot in 0..8 && currentSlot != bossSlot) {
          InventoryUtils.holdHotbarSlot(bossSlot)
          return true
        }
      }
    } else {
      emanHitPhaseBossWeaponPrimed = false
    }
    val current = player.inventory.getItem(currentSlot)
    val currentName = normalizeNameForMatch(current.hoverName?.string.orEmpty())
    if (!current.isEmpty) {
      if (isSlayerWeaponForMode(currentName, activeCombatMode, target)) return false
      val isUtility = SLAYER_NON_WEAPON_KEYWORDS.any { currentName.contains(it) }
      val preferredSlot = findPreferredSlayerWeaponSlot(player, activeCombatMode, target)
      if (preferredSlot in 0..8 && preferredSlot != currentSlot) {
        InventoryUtils.holdHotbarSlot(preferredSlot)
        return false
      }
      if (!isUtility) return false
    }
    val weaponSlot = findPreferredSlayerWeaponSlot(player, activeCombatMode, target)
    if (weaponSlot in 0..8 && weaponSlot != currentSlot) {
      InventoryUtils.holdHotbarSlot(weaponSlot)
    }
    return false
  }

  private fun shouldPrimeEmanHitPhaseBossWeapon(target: LivingEntity?): Boolean {
    return shouldUseEndermanDynamicCombat() &&
      target != null &&
      isSlayerBossEntity(target) &&
      isEndermanBossHitPhase(target) &&
      effectiveEndermanHitPhaseCombatMode() == 1
  }

  private fun applyEmanHitPhaseSneak(target: LivingEntity?, shouldAttack: Boolean) {
    val shouldSneak =
      emanHitPhaseSneakWhenHitting.value &&
        shouldUseEndermanDynamicCombat() &&
        shouldAttack &&
        target != null &&
        isSlayerBossEntity(target) &&
        isEndermanBossHitPhase(target)
    if (shouldSneak) {
      mc.options.keyShift?.setDown(true)
      emanHitPhaseSneakApplied = true
    }
  }

  private fun releaseEmanHitPhaseSneak() {
    if (!emanHitPhaseSneakApplied) return
    mc.options.keyShift?.setDown(false)
    emanHitPhaseSneakApplied = false
  }

  private fun tryAutoHeal(player: Player, nowTick: Long) {
    if (!autoHeal.value) return
    val effectiveHealth = player.health + player.absorptionAmount
    if (effectiveHealth > healAtHealth.value.toFloat()) return
    if (nowTick - lastHealUseTick < AUTO_HEAL_COOLDOWN_TICKS) return

    val healSlot = findHealHotbarSlot(player)
    if (healSlot !in 0..8) return

    lastHealUseTick = nowTick
    val previousSlot = player.inventory.selectedSlot

    if (previousSlot != healSlot) {
      InventoryUtils.holdHotbarSlot(healSlot)
    }

    mc.options.keyUse?.setDown(true)
    pendingHealRelease = true
    pendingHealRestoreSlot = if (previousSlot != healSlot) previousSlot else -1
  }

  private fun tryAlwaysUseWandOfAtonement(player: Player, nowTick: Long) {
    if (!alwaysUseWandOfAtonement.value) return
    if (pendingHealRelease || pendingHealRestoreSlot >= 0 || pendingOverfluxLookDownTicks > 0) return
    if (nowTick - lastAlwaysWandUseTick < ALWAYS_WAND_OF_ATONEMENT_INTERVAL_TICKS) return

    if (useHotbarUtilityItem(player, SLAYER_WAND_OF_ATONEMENT_KEYWORDS)) {
      lastAlwaysWandUseTick = nowTick
    }
  }

  private fun findHealHotbarSlot(player: Player): Int {
    if (autoWandOfAtonement.value) {
      val wandSlot = findHotbarSlotByKeywords(player, SLAYER_WAND_OF_ATONEMENT_KEYWORDS)
      if (wandSlot in 0..8) {
        return wandSlot
      }
    }

    if (autoHyperion.value) {
      val hyperionSlot = findHotbarSlotByKeywords(player, SLAYER_HYPERION_KEYWORDS)
      if (hyperionSlot in 0..8) {
        return hyperionSlot
      }
    }

    if (autoZombieSword.value) {
      val zombieSwordSlot = findHotbarSlotByKeywords(player, SLAYER_ZOMBIE_SWORD_KEYWORDS)
      if (zombieSwordSlot in 0..8) {
        return zombieSwordSlot
      }
    }

    return -1
  }

  private fun currentTargetRenderColor(): Color {
    val phase = (System.currentTimeMillis() % TARGET_BOX_CYCLE_MS).toDouble() / TARGET_BOX_CYCLE_MS.toDouble()
    val t = 0.5 - 0.5 * cos(phase * Math.PI * 2.0)
    val r = lerpChannel(CYAN_COLOR.red, PINK_COLOR.red, t)
    val g = lerpChannel(CYAN_COLOR.green, PINK_COLOR.green, t)
    val b = lerpChannel(CYAN_COLOR.blue, PINK_COLOR.blue, t)
    return Color(r, g, b, TARGET_BOX_ALPHA)
  }

  private fun lerpChannel(start: Int, end: Int, t: Double): Int {
    return (start + (end - start) * t).toInt().coerceIn(0, 255)
  }

  private fun shouldUseDirectChase(target: LivingEntity, hasLos: Boolean, distanceToTarget: Double): Boolean {
    val slayerGapBonus =
      when {
        cryptZombieSlayer.value && isSlayerBossEntity(target) -> SLAYER_BOSS_DIRECT_CHASE_GAP_BONUS
        cryptZombieSlayer.value && isSlayerPriorityMobEntity(target) -> SLAYER_MINIBOSS_DIRECT_CHASE_GAP_BONUS
        else -> 0.0
      }
    val handoffGap = SOFT_CHASE_HANDOFF_GAP + slayerGapBonus
    val stickyExitGap = SOFT_CHASE_STICKY_EXIT_GAP + slayerGapBonus
    val losGraceGap = SOFT_CHASE_LOS_GRACE_GAP + min(slayerGapBonus, SOFT_CHASE_MAX_GAP)

    val enterDirectChase = hasLos && distanceToTarget <= attackRange.value + handoffGap
    val stayDirectChase =
      closeChaseActive &&
        closeChaseTargetId == target.uuid &&
        distanceToTarget <= attackRange.value + stickyExitGap &&
        (hasLos || distanceToTarget <= attackRange.value + losGraceGap)

    val active = enterDirectChase || stayDirectChase
    closeChaseActive = active
    closeChaseTargetId = if (active) target.uuid else null
    return active
  }

  private fun resetCloseChase() {
    closeChaseActive = false
    closeChaseTargetId = null
    losScanLastFlipTick = 0L
  }

  private fun renderSlayerHighlights(context: org.cobalt.api.event.impl.render.WorldRenderContext, level: ClientLevel) {
    val cache = slayerHighlightCache
    if (cache.isEmpty()) return
    val espMode = slayerEspTargets.value
    // Use the tick-computed cache to avoid re-running the O(N²) armor-stand scan every frame.
    for (entity in level.entitiesForRendering()) {
      val living = entity as? LivingEntity ?: continue
      if (!living.isAlive || living.health <= 0f) continue
      val highlightState = cache[living.uuid] ?: continue
      if (!slayerHighlightMatchesMode(highlightState.type, espMode)) continue
      drawSlayerAura(context, living.boundingBox.inflate(TARGET_BOX_INFLATE), highlightState)
    }
  }

  private fun slayerHighlightMatchesMode(type: SlayerHighlightType, mode: Int): Boolean =
    when (mode) {
      0 -> type == SlayerHighlightType.BOSS
      1 -> type != SlayerHighlightType.BOSS
      else -> true
    }

  private fun drawSlayerAura(
    context: org.cobalt.api.event.impl.render.WorldRenderContext,
    box: net.minecraft.world.phys.AABB,
    state: SlayerHighlightState,
  ) {
    val palette = paletteForSlayerHighlight(state)

    Render3D.drawStyledBox(
      context,
      box.inflate(SLAYER_ESP_OUTER_INFLATE),
      palette.outerStroke,
      palette.outerFill,
      esp = true,
      lineWidth = 3.2f
    )
    Render3D.drawStyledBox(
      context,
      box.inflate(SLAYER_ESP_MID_INFLATE),
      palette.stroke,
      palette.fill,
      esp = true,
      lineWidth = 2.8f
    )
    Render3D.drawStyledBox(
      context,
      box,
      palette.stroke,
      palette.fill,
      esp = true,
      lineWidth = 2.2f
    )
  }

  private fun buildSlayerHighlightState(
    names: Collection<String>,
    type: SlayerHighlightType
  ): SlayerHighlightState {
    val attunement =
      if (slayerType.value == 5 && slayerBlazeAttunementColors.value) resolveBlazeAttunement(names) else null
    return SlayerHighlightState(type, attunement)
  }

  private fun paletteForSlayerHighlight(state: SlayerHighlightState): SlayerEspPalette {
    val baseArgb =
      when {
        state.attunement != null -> state.attunement.argb
        state.type == SlayerHighlightType.BOSS -> slayerBossEspColor.value
        state.type == SlayerHighlightType.HIGH_TIER_MINIBOSS -> slayerHighTierMiniEspColor.value
        else -> slayerMiniBossEspColor.value
      }
    return buildPalette(Color(baseArgb, true))
  }

  private fun buildPalette(base: Color): SlayerEspPalette {
    val strokeAlpha = base.alpha.coerceAtLeast(220)
    val stroke = Color(base.red, base.green, base.blue, strokeAlpha)
    val fill = Color(base.red, base.green, base.blue, 26)
    val outerBase = blendColors(base, Color.WHITE, 0.38f)
    val outerStroke = Color(outerBase.red, outerBase.green, outerBase.blue, 170)
    val outerFill = Color(outerBase.red, outerBase.green, outerBase.blue, 10)
    return SlayerEspPalette(
      stroke = stroke,
      fill = fill,
      outerStroke = outerStroke,
      outerFill = outerFill,
    )
  }

  private fun blendColors(first: Color, second: Color, amount: Float): Color {
    val blend = amount.coerceIn(0f, 1f)
    val inv = 1f - blend
    return Color(
      (first.red * inv + second.red * blend).toInt().coerceIn(0, 255),
      (first.green * inv + second.green * blend).toInt().coerceIn(0, 255),
      (first.blue * inv + second.blue * blend).toInt().coerceIn(0, 255),
      (first.alpha * inv + second.alpha * blend).toInt().coerceIn(0, 255),
    )
  }

  private fun syncSlayerGlowState(
    level: ClientLevel,
    cache: Map<UUID, SlayerHighlightState>
  ) {
    val scoreboard = level.scoreboard
    ensureSlayerGlowTeams(scoreboard)

    val activeIds = cache.keys
    val glowIterator = slayerGlowingEntities.iterator()
    while (glowIterator.hasNext()) {
      val entry = glowIterator.next()
      if (entry.key in activeIds) continue
      val liveEntity = level.entitiesForRendering().firstOrNull { it.uuid == entry.key } as? LivingEntity
      liveEntity?.setGlowingTag(false)
      scoreboard.removePlayerFromTeam(entry.value)
      glowIterator.remove()
    }

    for ((uuid, state) in cache) {
      if (!slayerHighlightMatchesMode(state.type, slayerEspTargets.value)) continue
      val living = level.entitiesForRendering().firstOrNull { it.uuid == uuid } as? LivingEntity ?: continue
      val scoreHolder = living.scoreboardName
      val teamName = slayerGlowTeamName(state)
      val team = ensureSlayerGlowTeam(scoreboard, teamName, slayerGlowFormatting(state))
      val currentTeam = scoreboard.getPlayersTeam(scoreHolder)
      if (currentTeam == null || currentTeam.name != team.name) {
        if (currentTeam != null && currentTeam.name.startsWith(SLAYER_GLOW_TEAM_PREFIX)) {
          scoreboard.removePlayerFromTeam(scoreHolder, currentTeam)
        }
        scoreboard.addPlayerToTeam(scoreHolder, team)
      }
      living.setGlowingTag(true)
      slayerGlowingEntities[uuid] = scoreHolder
    }
  }

  private fun clearSlayerGlowState(level: ClientLevel? = mc.level) {
    if (slayerGlowingEntities.isEmpty()) return
    val scoreboard = level?.scoreboard
    val loadedLivingById =
      level?.entitiesForRendering()
        ?.filterIsInstance<LivingEntity>()
        ?.associateBy { it.uuid }
        .orEmpty()

    for ((uuid, scoreHolder) in slayerGlowingEntities) {
      loadedLivingById[uuid]?.setGlowingTag(false)
      scoreboard?.removePlayerFromTeam(scoreHolder)
    }
    slayerGlowingEntities.clear()
  }

  private fun ensureSlayerGlowTeams(scoreboard: net.minecraft.world.scores.Scoreboard) {
    ensureSlayerGlowTeam(scoreboard, SLAYER_GLOW_TEAM_BOSS, slayerGlowFormatting(SlayerHighlightState(SlayerHighlightType.BOSS, null)))
    ensureSlayerGlowTeam(scoreboard, SLAYER_GLOW_TEAM_MINI, slayerGlowFormatting(SlayerHighlightState(SlayerHighlightType.MINIBOSS, null)))
    ensureSlayerGlowTeam(scoreboard, SLAYER_GLOW_TEAM_HIGH, slayerGlowFormatting(SlayerHighlightState(SlayerHighlightType.HIGH_TIER_MINIBOSS, null)))
    ensureSlayerGlowTeam(scoreboard, SLAYER_GLOW_TEAM_ASHEN, nearestChatFormatting(BlazeAttunement.ASHEN.argb))
    ensureSlayerGlowTeam(scoreboard, SLAYER_GLOW_TEAM_SPIRIT, nearestChatFormatting(BlazeAttunement.SPIRIT.argb))
    ensureSlayerGlowTeam(scoreboard, SLAYER_GLOW_TEAM_AURIC, nearestChatFormatting(BlazeAttunement.AURIC.argb))
    ensureSlayerGlowTeam(scoreboard, SLAYER_GLOW_TEAM_CRYSTAL, nearestChatFormatting(BlazeAttunement.CRYSTAL.argb))
  }

  private fun ensureSlayerGlowTeam(
    scoreboard: net.minecraft.world.scores.Scoreboard,
    teamName: String,
    color: ChatFormatting,
  ): net.minecraft.world.scores.PlayerTeam {
    val team = scoreboard.getPlayerTeam(teamName) ?: scoreboard.addPlayerTeam(teamName)
    team.setColor(color)
    return team
  }

  private fun slayerGlowFormatting(state: SlayerHighlightState): ChatFormatting {
    return when (state.attunement) {
      BlazeAttunement.ASHEN -> nearestChatFormatting(BlazeAttunement.ASHEN.argb)
      BlazeAttunement.SPIRIT -> nearestChatFormatting(BlazeAttunement.SPIRIT.argb)
      BlazeAttunement.AURIC -> nearestChatFormatting(BlazeAttunement.AURIC.argb)
      BlazeAttunement.CRYSTAL -> nearestChatFormatting(BlazeAttunement.CRYSTAL.argb)
      null ->
        when (state.type) {
          SlayerHighlightType.BOSS -> nearestChatFormatting(slayerBossEspColor.value)
          SlayerHighlightType.HIGH_TIER_MINIBOSS -> nearestChatFormatting(slayerHighTierMiniEspColor.value)
          SlayerHighlightType.MINIBOSS -> nearestChatFormatting(slayerMiniBossEspColor.value)
        }
    }
  }

  private fun slayerGlowTeamName(state: SlayerHighlightState): String =
    when (state.attunement) {
      BlazeAttunement.ASHEN -> SLAYER_GLOW_TEAM_ASHEN
      BlazeAttunement.SPIRIT -> SLAYER_GLOW_TEAM_SPIRIT
      BlazeAttunement.AURIC -> SLAYER_GLOW_TEAM_AURIC
      BlazeAttunement.CRYSTAL -> SLAYER_GLOW_TEAM_CRYSTAL
      null ->
        when (state.type) {
          SlayerHighlightType.BOSS -> SLAYER_GLOW_TEAM_BOSS
          SlayerHighlightType.MINIBOSS -> SLAYER_GLOW_TEAM_MINI
          SlayerHighlightType.HIGH_TIER_MINIBOSS -> SLAYER_GLOW_TEAM_HIGH
        }
    }

  private fun resolveBlazeAttunement(names: Collection<String>): BlazeAttunement? =
    when {
      names.any { it.contains("ashen") } -> BlazeAttunement.ASHEN
      names.any { it.contains("spirit") } -> BlazeAttunement.SPIRIT
      names.any { it.contains("auric") } -> BlazeAttunement.AURIC
      names.any { it.contains("crystal") } -> BlazeAttunement.CRYSTAL
      else -> null
    }

  private fun nearestChatFormatting(argb: Int): ChatFormatting {
    val source = Color(argb, true)
    return CHAT_FORMATTING_COLORS.minByOrNull { (_, candidate) ->
      val dr = source.red - candidate.red
      val dg = source.green - candidate.green
      val db = source.blue - candidate.blue
      dr * dr + dg * dg + db * db
    }?.first ?: ChatFormatting.WHITE
  }

  private fun slayerBossDisplayName(): String =
    when (slayerType.value) {
      0 -> if (slayerTier.value.toInt() >= 5) "Atoned Horror" else "Revenant Horror"
      1 -> "Sven Packmaster"
      2 -> "Tarantula Broodfather"
      3 -> "Voidgloom Seraph"
      4 -> "Riftstalker Bloodfiend"
      5 -> "Inferno Demonlord"
      else -> "Slayer Boss"
    }

  private fun applyLosStrafeScan(nowTick: Long) {
    if (losScanLastFlipTick == 0L) {
      losScanLastFlipTick = nowTick
    }
    if (nowTick - losScanLastFlipTick >= LOS_SCAN_FLIP_TICKS) {
      losScanStrafeRight = !losScanStrafeRight
      losScanLastFlipTick = nowTick
    }
    MovementManager.setForcedMovement(
      forward = false, backward = false,
      left = !losScanStrafeRight, right = losScanStrafeRight,
      jump = false, shift = false, sprint = false
    )
  }

  private fun handleSoftChaseMovement(player: Player, target: LivingEntity, distanceToTarget: Double) {
    val rotation = AngleUtils.getRotation(target)
    RotationExecutor.rotateTo(rotation, rotationStrategy)

    val yawError = abs(AngleUtils.getRotationDelta(player.yRot, rotation.yaw))
    val pitchError = abs(rotation.pitch - player.xRot)
    val aligned = yawError <= SOFT_CHASE_YAW_TOLERANCE && pitchError <= SOFT_CHASE_PITCH_TOLERANCE
    val shouldStepForward = distanceToTarget > combatKeepDistance(0) + SOFT_CHASE_STOP_BUFFER

    if (aligned && shouldStepForward) {
      MovementManager.setMovementLock(true)
      val shouldJump = player.onGround() && player.horizontalCollision
      MovementManager.setForcedMovement(
        forward = true, backward = false,
        left = false, right = false,
        jump = shouldJump, shift = false, sprint = true
      )
    } else {
      MovementManager.setMovementLock(false)
    }
  }

  private fun isAttackReady(player: Player, target: LivingEntity): Boolean {
    val cooldown = player.getAttackStrengthScale(0.0f)
    if (cooldown < minAttackCooldown.value.toFloat()) return false
    if (requireLos.value && !player.hasLineOfSight(target)) return false

    val rotation = AngleUtils.getRotation(target)
    val yawError = abs(AngleUtils.getRotationDelta(player.yRot, rotation.yaw))
    val pitchError = abs(rotation.pitch - player.xRot)
    val tolerance = aimTolerance.value
    if (yawError > tolerance || pitchError > tolerance) return false

    return true
  }

  private fun updateStuck(
    player: Player,
    inAttackRange: Boolean,
    level: ClientLevel
  ) {
    if (inAttackRange || !startedPath || !nativeActive()) {
      stuckTicks = 0
      stuckRepathCount = 0
      lastMoveX = player.x
      lastMoveY = player.y
      lastMoveZ = player.z
      return
    }

    val dx = player.x - lastMoveX
    val dy = player.y - lastMoveY
    val dz = player.z - lastMoveZ
    val moved = dx * dx + dy * dy + dz * dz > 0.0008
    if (moved) {
      stuckTicks = 0
      stuckRepathCount = 0
      lastMoveX = player.x
      lastMoveY = player.y
      lastMoveZ = player.z
      return
    }

    stuckTicks++
    if (stuckTicks < stuckTicksSetting.value.toInt()) {
      return
    }
    stuckTicks = 0

    val maxRepaths = stuckRepathTries.value.toInt().coerceAtLeast(0)
    if (stuckRepathCount < maxRepaths) {
      val target =
        currentTargetId?.let { id ->
          level.entitiesForRendering().firstOrNull { it.uuid == id } as? LivingEntity
        }
      if (target != null && target.isAlive && target.health > 0f) {
        nativeStop()
        val targetPos = target.blockPosition()
        val restarted = startCombatPathToTarget(level, targetPos, effectiveCombatMode(target))
        if (restarted) {
          startedPath = true
          lastTargetPos = targetPos
          lastPathStartTick = level.gameTime
          stuckRepathCount++
          return
        }
      }
    }

    stuckRepathCount = 0
    if (warpOnStuck.value) {
      if (cryptZombieSlayer.value) {
        ChatUtils.sendMessage("Combat macro stuck. Triggering walkback.")
        startAreaOrigin = null
        stuckTicks = 0
        slayerEnteredCrypt = false
        triggerWalkToFarmArea(justFarm = false)
      } else {
        nativeStop()
        (player as? LocalPlayer)?.connection?.sendCommand("warp hub")
        ChatUtils.sendMessage("Combat macro stuck. Warping to hub.")
        stopMacro()
      }
    }
  }

  private fun startCombatPathToTarget(
    level: ClientLevel,
    targetPos: BlockPos,
    activeCombatMode: Int = combatMode.value
  ): Boolean {
    val resolved = findNearestWalkableAround(level, targetPos, CHASE_RESOLVE_RADIUS, CHASE_RESOLVE_VERTICAL) ?: targetPos
    val radius = combatPathRadius(activeCombatMode)
    if (!nativeActive()) {
      MovementManager.clearForcedMovement()
      RotationExecutor.stopRotating()
    }
    NativePathfinder.setTargetWithRadius(resolved.x + 0.5, resolved.y.toDouble(), resolved.z + 0.5, radius)
    return true
  }

  private fun combatEngageRange(activeCombatMode: Int = combatMode.value): Double {
    return when (activeCombatMode) {
      1 -> max(attackRange.value, bowMinRange.value.coerceAtLeast(0.0))
      else -> attackRange.value
    }
  }

  private fun combatKeepDistance(activeCombatMode: Int = combatMode.value): Double {
    return when (activeCombatMode) {
      0 -> {
        val configured = configuredSwordKeepDistance().coerceAtLeast(0.0)
        val desired = if (configured <= 0.0) MELEE_CLOSE_IN_DISTANCE else configured
        min(attackRange.value, desired)
      }
      1 -> combatEngageRange(activeCombatMode)
      else -> attackRange.value
    }
  }

  private fun configuredSwordKeepDistance(): Double {
    return when {
      cryptZombieSlayer.value || slayerModeEnabled -> slayerSwordKeepDistance.value
      else -> swordKeepDistance.value
    }
  }

  private fun combatPathRadius(activeCombatMode: Int = combatMode.value): Double {
    return (combatKeepDistance(activeCombatMode) - COMBAT_PATH_RADIUS_BUFFER).coerceAtLeast(COMBAT_MIN_STANDOFF)
  }

  private fun beginSlayerSession() {
    slayerSessionStartMs = System.currentTimeMillis()
    slayerSessionMobKills = 0
    slayerSessionQuestCompletions = 0
    slayerSessionQuestFailures = 0
    clearTrackedSlayerQuestState(clearIdentity = true)
  }

  private fun startTrackedSlayerQuest(typeIdx: Int, tier: Int) {
    slayerTrackedQuestActive = true
    slayerTrackedQuestType = typeIdx.takeIf { it in slayerType.options.indices } ?: slayerType.value
    slayerTrackedQuestTier = tier.takeIf { it in 1..5 } ?: slayerTier.value.toInt().coerceIn(1, 5)
    slayerTrackedQuestProgressKills = 0
    slayerTrackedQuestTargetKills = 0
    slayerTrackedQuestSawMobKill = false
    slayerTrackedQuestBossSeen = false
    slayerTrackedQuestCompletionPendingRestart = false
  }

  private fun clearTrackedSlayerQuestState(clearIdentity: Boolean) {
    slayerTrackedQuestActive = false
    slayerTrackedQuestProgressKills = 0
    slayerTrackedQuestTargetKills = 0
    slayerTrackedQuestSawMobKill = false
    slayerTrackedQuestBossSeen = false
    slayerTrackedQuestCompletionPendingRestart = false
    if (clearIdentity) {
      slayerTrackedQuestType = -1
      slayerTrackedQuestTier = 0
    }
  }

  private fun completeTrackedSlayerQuest() {
    if (slayerTrackedQuestCompletionPendingRestart) return
    slayerSessionQuestCompletions++
    slayerTrackedQuestActive = false
    slayerTrackedQuestSawMobKill = true
    slayerTrackedQuestBossSeen = true
    slayerTrackedQuestCompletionPendingRestart = true
  }

  private fun queueSlayerQuestRestart(countFailure: Boolean = true) {
    if (countFailure) {
      markTrackedSlayerQuestFailedIfNeeded()
    }
    slayerNeedsQuestRestart = true
    slayerPendingTierSelection = false
  }

  private fun markTrackedSlayerQuestFailedIfNeeded() {
    if (!slayerTrackedQuestActive) return
    if (slayerTrackedQuestCompletionPendingRestart || slayerNeedsQuestClaim) return
    slayerSessionQuestFailures++
    clearTrackedSlayerQuestState(clearIdentity = false)
  }

  private fun trackedSlayerQuestLabel(): String {
    val typeIndex =
      when {
        slayerTrackedQuestType in slayerType.options.indices -> slayerTrackedQuestType
        slayerType.value in slayerType.options.indices -> slayerType.value
        else -> return "--"
      }
    val tier =
      when {
        slayerTrackedQuestTier in 1..5 -> slayerTrackedQuestTier
        else -> slayerTier.value.toInt().coerceIn(1, 5)
      }
    return "${slayerType.options[typeIndex]} ${romanTierLabel(tier)}"
  }

  private fun trackedSlayerQuestHudStageLabel(): String =
    when {
      slayerNeedsQuestClaim || slayerTrackedQuestCompletionPendingRestart || slayerBossActive || slayerQuestReady || slayerTrackedQuestBossSeen ->
        "Killing Boss"
      slayerTrackedQuestSawMobKill || slayerTrackedQuestProgressKills > 0 -> "Killing Mobs"
      else -> "Started"
    }

  private fun currentSlayerKillsLeft(): Int? {
    if (slayerNeedsQuestClaim || slayerTrackedQuestCompletionPendingRestart || slayerBossActive || slayerQuestReady || slayerTrackedQuestBossSeen) {
      return 0
    }
    val targetKills = slayerTrackedQuestTargetKills
    if (targetKills <= 0) return null
    return (targetKills - slayerTrackedQuestProgressKills).coerceAtLeast(0)
  }

  private fun formatSessionRateDisplay(count: Int): String {
    val sessionStart = slayerSessionStartMs
    if (sessionStart <= 0L || count <= 0) return "0/h"
    val elapsedMs = (System.currentTimeMillis() - sessionStart).coerceAtLeast(1000L)
    val perHour = count * 3_600_000.0 / elapsedMs.toDouble()
    return if (perHour >= 100.0 || abs(perHour - perHour.toInt()) < 0.05) {
      "${perHour.toInt()}/h"
    } else {
      String.format(Locale.ROOT, "%.1f/h", perHour)
    }
  }

  private fun romanTierLabel(tier: Int): String =
    when (tier.coerceIn(1, 5)) {
      1 -> "I"
      2 -> "II"
      3 -> "III"
      4 -> "IV"
      5 -> "V"
      else -> "I"
    }

  /**
   * Navigate back to the farming area using the configured walkback route.
   * [justFarm] = true  -> just walk in; don't restart the quest after arriving.
   * [justFarm] = false -> buy a new quest once walkback completes.
   */
  private fun triggerWalkToFarmArea(justFarm: Boolean, skipPreWarp: Boolean = false) {
    if (CombatPatrolModule.isPatrolRunning) CombatPatrolModule.stopPatrol()
    if (PathfindingModule.isPatrolActive) PathfindingModule.stopPatrol()
    if (slayerNeedsWalkback) WalkbackBridge.stopWalkback?.invoke()
    nativeStop()
    startedPath = false
    lastTargetPos = null
    currentTargetId = null
    stuckTicks = 0
    stuckRepathCount = 0
    RotationExecutor.stopRotating()
    MovementManager.clearForcedMovement()
    val perTypeRoute = walkbackRouteForCurrentType().value.trim()
    val routeName = when {
      slayerLocation.value == 1 -> CRYPT_WALKBACK_ROUTE_NAME
      perTypeRoute.isNotBlank() -> perTypeRoute
      else -> ""
    }
    if (routeName.isBlank()) {
      if (!justFarm) queueSlayerQuestRestart(countFailure = false)
      return
    }
    // Spider slayer: warp to den first so the walkback route starts from the right place.
    // skipPreWarp is true when called from the delay-expiry tick (warp already issued).
    if (!skipPreWarp && slayerType.value == 2) {
      val warpCmd = slayerWarpCommand
      if (warpCmd.isNotBlank()) {
        mc.player?.connection?.sendCommand(warpCmd)
        slayerWalkInDelayUntilTick = (mc.level?.gameTime ?: 0L) + SPIDER_WARP_DELAY_TICKS
        slayerWalkInJustFarm = justFarm
        return
      }
    }
    // Crypt route is stored hub→crypt (walk-in direction), so reverse=false walks you in.
    // Per-type routes (graveyard etc.) are stored farm→boss to match finishSlayerClaim's
    // reverse=true convention, so reverse=true here to get boss→farm.
    val reverseRoute = slayerLocation.value != 1
    val started = WalkbackBridge.startWalkback?.invoke(routeName, 0, reverseRoute) ?: false
    if (started) {
      slayerNeedsWalkback = true
      slayerWalkbackJustFarm = justFarm
    } else {
      ChatUtils.sendMessage("Combat macro: walkback route \"$routeName\" not found.")
      if (!justFarm) queueSlayerQuestRestart(countFailure = false)
    }
  }

  private fun findNearestWalkableAround(
    level: ClientLevel,
    origin: BlockPos,
    radius: Int,
    vertical: Int
  ): BlockPos? {
    var best: BlockPos? = null
    var bestDistSq = Double.POSITIVE_INFINITY
    for (dy in -vertical..vertical) {
      for (dx in -radius..radius) {
        for (dz in -radius..radius) {
          val pos = origin.offset(dx, dy, dz)
          if (!MinecraftPathingRules.isWalkable(level, pos)) continue
          val distSq = pos.distSqr(origin).toDouble()
          if (distSq < bestDistSq) {
            bestDistSq = distSq
            best = pos
          }
        }
      }
    }
    return best
  }

  private fun nativeActive(): Boolean =
    NativePathfinder.status.let { it != PathStatus.IDLE && it != PathStatus.ARRIVED && it != PathStatus.FAILED }

  private fun nativeStop() {
    NativePathfinder.stop()
    MovementManager.setMovementLock(false)
  }

  private fun stopMacro() {
    automationBypassWhitelist = false
    clearSlayerGlowState(mc.level ?: lastKnownLevel)
    if (PathfindingModule.isPatrolActive) PathfindingModule.stopPatrol()
    if (CombatPatrolModule.isPatrolRunning) CombatPatrolModule.stopPatrol()
    if (startedPath && nativeActive()) {
      nativeStop()
    } else {
      MovementManager.setMovementLock(false)
    }
    RotationExecutor.stopRotating()
    lastTargetPos = null
    stuckTicks = 0
    nextAttackNs = 0L
    startedPath = false
    currentTargetId = null
    resetCloseChase()
    lastPathStartTick = 0L
    clearKillCandidate()
    drillWarnTick = 0L
    lastHealUseTick = 0L
    lastAlwaysWandUseTick = 0L
    stuckRepathCount = 0
    startAreaOrigin = null
    enteredFarmingArea = false
    emanHitPhaseBossWeaponPrimed = false
    if (pendingHealRelease) {
      mc.options.keyUse?.setDown(false)
      pendingHealRelease = false
    }
    releaseEmanHitPhaseSneak()
    pendingHealRestoreSlot = -1
    clearPendingOverfluxPlacement()
    slayerStatus.value = "Off"
    clearSlayerBossState(false)
    slayerLastTabScanTick = -1L
    slayerTabCache = emptyList()
    slayerNeedsQuestRestart = false
    slayerPendingTierSelection = false
    slayerQuestReady = false
    slayerRagnarokUsedPreBoss = false
    slayerAutoDetected = false
    slayerDetectStartTick = -1L
    slayerNeedsQuestClaim = false
    if (slayerNeedsWalkback) WalkbackBridge.stopWalkback?.invoke()
    slayerNeedsWalkback = false
    slayerWalkbackJustFarm = false
    slayerDeathRespawnPending = false
    slayerWalkInDelayUntilTick = -1L
    slayerWalkInJustFarm = true
    slayerBossLastPos = null
    slayerClaimStartTick = -1L
    slayerClaimLastClickTick = -1L
    slayerLastBatphoneAttemptTick = -1L
    slayerLastBatphoneUseTick = -1L
    slayerLastGuiActionTick = -1L
    slayerWarnNoBatphoneTick = -1L
    slayerModeEnabled = false
    slayerQuestStateGraceUntilTick = -1L
    slayerEnteredCrypt = false
    slayerSessionStartMs = 0L
    slayerSessionMobKills = 0
    slayerSessionQuestCompletions = 0
    slayerSessionQuestFailures = 0
    clearTrackedSlayerQuestState(clearIdentity = true)
  }

  private const val TAB_COMBAT_GROUP = "General"
  private const val TAB_COMBAT_BEHAVIOR_GROUP = "Combat"
  private const val TAB_SLAYER_GROUP = "Slayer"
  private const val TAB_SLAYER_WEAPONS_GROUP = "Slayer Weapons"
  private const val TAB_PATROL_GROUP = "Patrol"
  private const val TAB_AUTO_ITEMS_GROUP = "Auto Items"
  private const val KILL_CANDIDATE_TTL_TICKS = 80L
  private const val KILL_DISAPPEAR_CONFIRM_TICKS = 2L
  private const val DRILL_WARN_INTERVAL_TICKS = 60L
  private const val AUTO_HEAL_COOLDOWN_TICKS = 20L
  private const val ALWAYS_WAND_OF_ATONEMENT_INTERVAL_TICKS = 140L
  private const val SLAYER_TAB_SCAN_INTERVAL_TICKS = 5L
  private const val SLAYER_BOSS_TAB_LOST_TICKS = 30L
  private const val SLAYER_BOSS_ENTITY_LOST_TICKS = 20L
  private const val SLAYER_OVERFLUX_COOLDOWN_TICKS = 600L
  private const val OVERFLUX_LOOK_DOWN_TICKS = 4
  private const val OVERFLUX_RECOVER_LOOK_TICKS = 8
  private const val OVERFLUX_PLACE_PITCH = 80f
  private const val SLAYER_RAGNAROK_COOLDOWN_TICKS = 400L
  private const val SLAYER_REAPER_SCYTHE_COOLDOWN_TICKS = 100L
  private const val REAPER_SCYTHE_USE_AIM_TOLERANCE = 12.0
  private const val SLAYER_BAD_HEALTH_REUSE_TICKS = 80L
  private const val SLAYER_BATPHONE_RETRY_TICKS = 80L
  private const val SPIDER_WARP_DELAY_TICKS = 60L  // ~3 s to let the warp teleport complete
  private const val SLAYER_MADDOX_GUI_TIMEOUT_TICKS = 80L
  private const val SLAYER_GUI_ACTION_COOLDOWN_TICKS = 5L
  private const val SLAYER_NO_BATPHONE_WARN_TICKS = 200L
  private const val SLAYER_DETECT_WINDOW_TICKS = 100L  // 5 s to scan before assuming no quest
  private const val SLAYER_QUEST_STATE_GRACE_TICKS = 40L
  private const val SPIDER_HATCHLING_PHASE_FALLBACK_TICKS = 160L
  private const val SPIDER_HATCHLING_PHASE_REFRESH_TICKS = 40L
  private const val SLAYER_WOLF_PUPS_PHASE_TICKS = 60L
  private const val PLAYER_HOTBAR_MENU_SLOT_START = 36
  private const val PLAYER_HOTBAR_MENU_SLOT_END = 44
  private const val DEFAULT_WHITELIST_ENTRY = "ice walker"
  private const val MIN_PATH_START_INTERVAL_TICKS = 8L
  private const val TARGET_REPATH_DISTANCE_SQ = 9.0   // repath when mob moves ~3+ blocks
  private const val COMBAT_ROTATION_STEP_SCALE = 0.95
  private const val ROTATION_STOP_HYSTERESIS = 2.5     // don't stop rotating until clearly out of range
  private const val COMBAT_MIN_STANDOFF = 0.45
  private const val MELEE_CLOSE_IN_DISTANCE = 1.1
  private const val COMBAT_PATH_RADIUS_BUFFER = 0.18
  private const val SOFT_CHASE_HANDOFF_GAP = 3.5
  private const val SOFT_CHASE_STICKY_EXIT_GAP = 4.0
  private const val SOFT_CHASE_LOS_GRACE_GAP = 0.55
  private const val SOFT_CHASE_MAX_GAP = 0.45
  private const val SOFT_CHASE_STOP_BUFFER = 0.10
  private const val SOFT_CHASE_YAW_TOLERANCE = 7.5
  private const val SOFT_CHASE_PITCH_TOLERANCE = 18.0
  private const val SLAYER_BOSS_DIRECT_CHASE_GAP_BONUS = 0.85
  private const val SLAYER_MINIBOSS_DIRECT_CHASE_GAP_BONUS = 0.45
  private const val SLAYER_PHASE_ADD_SEARCH_RADIUS_SQ = 100.0
  private const val SPIDER_HATCHLING_CLEAR_DISTANCE = 0.9
  private const val SPIDER_PHASE_MIN_BACKSTEP_DISTANCE = 5.0
  private const val SPIDER_PHASE_STEPBACK_BUFFER = 1.35
  private const val SPIDER_PHASE_STEPBACK_HYSTERESIS = 0.35
  private const val SPIDER_PHASE_STEPBACK_YAW_TOLERANCE = 10.0
  private const val LOS_SCAN_FLIP_TICKS = 20L
  private const val EMAN_HITS_PHASE_MIN_STANDOFF = 2.5
  private const val EMAN_HITS_PHASE_STANDOFF_BUFFER = 0.5
  private const val EMAN_HITS_PHASE_STANDOFF_HYSTERESIS = 0.35
  private const val EMAN_HITS_PHASE_YAW_TOLERANCE = 25.0
  private const val EMAN_BEACON_SCAN_RADIUS = 16
  private const val SPIDER_PHASE_STEPBACK_PITCH_TOLERANCE = 22.0
  private const val CRYPT_WALKBACK_ROUTE_NAME = "cryptwalkback"
  private const val SLAYER_WALKIN_WARP_DELAY_TICKS = 40L  // ticks to wait after warp hub before starting walkin route
  private const val CRYPT_PROXIMITY_RANGE_SQ = 1600.0    // 40-block radius - if within this of any patrol point, already in crypt
  private const val GRAVEYARD_PROXIMITY_RANGE_SQ = 900.0  // 30-block radius - if within this of any patrol point, already at graveyard
  private const val CHASE_RESOLVE_RADIUS = 3
  private const val CHASE_RESOLVE_VERTICAL = 2
  private const val START_AREA_RETURN_BUFFER = 2.0
  private const val TARGET_BOX_CYCLE_MS = 4000L
  private const val TARGET_BOX_ALPHA = 170
  private const val ATTACHED_NAMEPLATE_HORIZONTAL_RANGE_SQ = 2.25
  private const val ENDERMAN_HITS_HORIZONTAL_RANGE_SQ = 9.0
  private const val TARGET_BOX_INFLATE = 0.08
  private const val SLAYER_ESP_MID_INFLATE = 0.22
  private const val SLAYER_ESP_OUTER_INFLATE = 0.38
  private const val BOW_REFIRE_DELAY_NS = 200_000_000L  // 200 ms between shots
  private const val COMBAT_ROTATION_SAMPLE_NS = 180_000_000L
  private const val COMBAT_ROTATION_RESEED_YAW = 16f
  private const val COMBAT_ROTATION_RESEED_PITCH = 10f
  private const val COMBAT_ROTATION_BASE_HZ = 20f
  private const val COMBAT_ROTATION_MIN_FRAME_SCALE = 0.28f
  private const val COMBAT_ROTATION_MAX_FRAME_SCALE = 1.08f
  private const val COMBAT_MAX_SNAP_THRESHOLD = 0.12f
  private val ENDERMAN_HITS_PATTERNS = arrayOf(
    Regex("\\b\\d+[,.]?\\d*\\s+hits?\\b"),
    Regex("\\bhits?\\s*[:x-]?\\s*\\d+[,.]?\\d*\\b"),
    Regex("\\b\\d+[,.]?\\d*\\s+hit shield\\b"),
  )
  private val ENDERMAN_HITS_TEXT_KEYWORDS = arrayOf("hits", "shield", "shielded", "immune")
  private val ENDERMAN_LASER_TEXT_KEYWORDS = arrayOf("aligning", "lasers", "laser", "align")
  private val EMAN_LASER_AOTV_KEYWORDS = arrayOf("aspect of the void", "aotv")
  private val ATTACHED_LABEL_TRANSIENT_KEYWORDS = arrayOf("hits", "hit shield", "shielded", "immune")
  private val SLAYER_PROGRESS_PATTERN = Regex("(\\d{1,5})\\s*/\\s*(\\d{1,5})")
  private data class SlayerQuestProgress(
    val typeIndex: Int,
    val tier: Int,
    val progress: Int,
    val target: Int,
  )
  private val SLAYER_BOSS_ENTITY_KEYWORDS get() = when (slayerType.value) {
    0 -> arrayOf("revenant horror", "atoned horror")
    1 -> arrayOf("sven packmaster")
    2 -> arrayOf("tarantula broodfather")
    3 -> arrayOf("voidgloom seraph")
    4 -> arrayOf("riftstalker bloodfiend")
    5 -> arrayOf("inferno demonlord")
    else -> arrayOf()
  }
  // Priority mobs: rare/high-XP mobs that should be targeted over regular farm mobs.
  // Only applies at the relevant tier (zombie: tier 3+).
  private val SLAYER_PRIORITY_MOB_KEYWORDS get() = when {
    slayerType.value == 0 && slayerTier.value >= 3 -> arrayOf(
      "revenant sycophant", "revenant champion", "deformed revenant",
      "atoned champion", "atoned revenant"
    )
    slayerType.value == 1 && slayerTier.value >= 3 -> arrayOf(
      "pack enforcer", "sven follower", "sven alpha"
    )
    slayerType.value == 2 && slayerTier.value >= 3 -> arrayOf(
      "tarantula vermin", "tarantula beast", "mutant tarantula",
      "primordial jockey", "primordial viscount"
    )
    slayerType.value == 3 && slayerTier.value >= 3 -> arrayOf(
      "voidling devotee", "voidling radical", "voidcrazed maniac"
    )
    slayerType.value == 5 && slayerTier.value >= 3 -> arrayOf(
      "flare demon", "kindleheart demon", "burningsoul demon"
    )
    else -> arrayOf()
  }
  private val SLAYER_HIGH_TIER_PRIORITY_MOB_KEYWORDS get() = when {
    slayerType.value == 0 && slayerTier.value >= 3 -> arrayOf(
      "revenant champion", "deformed revenant", "atoned champion", "atoned revenant"
    )
    slayerType.value == 1 && slayerTier.value >= 3 -> arrayOf(
      "sven alpha"
    )
    slayerType.value == 2 && slayerTier.value >= 3 -> arrayOf(
      "mutant tarantula", "primordial jockey", "primordial viscount"
    )
    slayerType.value == 3 && slayerTier.value >= 3 -> arrayOf(
      "voidling radical", "voidcrazed maniac"
    )
    slayerType.value == 5 && slayerTier.value >= 3 -> arrayOf(
      "kindleheart demon", "burningsoul demon"
    )
    else -> arrayOf()
  }
  private val SLAYER_FARM_MOB_KEYWORDS get() = when (slayerType.value) {
    0 -> when (slayerLocation.value) {
      0 -> arrayOf("zombie") // Zombie Graveyard: regular zombies only
      1 -> arrayOf("crypt ghoul", "golden ghoul") // Zombie Crypt
      else -> arrayOf("zombie", "crypt ghoul", "golden ghoul")
    }
    1 -> arrayOf("pack wolf", "old wolf", "pit wolf", "zombie wolf", "wolf", "pup", "pups")
    2 -> arrayOf("dasher spider", "voracious spider", "weaver spider", "spider", "hatchling", "hatchlings", "broodling")
    3 -> when (endermanLocation.value) {
      0 -> arrayOf(ENDERMAN_END_FARM_MOB_KEYWORD)
      1 -> arrayOf(ENDERMAN_HIDEOUT_FARM_MOB_KEYWORD)
      2 -> arrayOf(ENDERMAN_VOID_FARM_MOB_KEYWORD)
      else -> arrayOf(ENDERMAN_END_FARM_MOB_KEYWORD)
    }
    4 -> arrayOf("bat", "vampiric bat", "bloodfiend")
    5 -> arrayOf("blaze", "smoldering blaze", "emerald slime")
    else -> arrayOf()
  }
  // Only "slay the boss" reliably signals the boss is active.
  // Boss entity names (e.g. "revenant horror") also appear in the quest PROGRESS tab line
  // ("Kill Revenant Horror 50/200"), which would incorrectly set slayerBossActive = true.
  private val SLAYER_BOSS_TAB_KEYWORDS = arrayOf("slay the boss")
  private val SLAYER_BOSS_CLEAR_KEYWORDS = arrayOf("boss slain", "slayer quest complete")
  private val SLAYER_QUEST_TAB_KEYWORDS get() = when (slayerType.value) {
    0 -> arrayOf("slayer quest", "zombie slayer", "revenant horror")
    1 -> arrayOf("slayer quest", "wolf slayer", "sven packmaster")
    2 -> arrayOf("slayer quest", "spider slayer", "tarantula broodfather")
    3 -> arrayOf("slayer quest", "enderman slayer", "voidgloom seraph")
    4 -> arrayOf("slayer quest", "vampire slayer", "riftstalker bloodfiend")
    5 -> arrayOf("slayer quest", "blaze slayer", "inferno demonlord")
    else -> arrayOf("slayer quest")
  }
  // Items that are NOT weapons - switch away from these when preparing to attack
  private val SLAYER_NON_WEAPON_KEYWORDS = arrayOf(
    "batphone", "overflux", "ragnarok", "ragnorak", "wand of atonement",
    "reaper scythe", "sword of bad health", "drill", "pickaxe", "gauntlet"
  )
  private val SLAYER_MELEE_WEAPON_KEYWORDS = arrayOf(
    "sword", "blade", "scythe", "katana", "saber", "cleaver", "axe", "rapier", "claymore",
    "halberd", "dagger", "falchion"
  )
  private val SLAYER_BOW_WEAPON_KEYWORDS = arrayOf("terminator", "juju", "shortbow", "bow")
  private val SLAYER_MAGE_WEAPON_KEYWORDS = arrayOf("staff", "wand", "sceptre", "scepter", "scythe")
  private val SLAYER_ANY_WEAPON_KEYWORDS = arrayOf(
    *SLAYER_MELEE_WEAPON_KEYWORDS,
    *SLAYER_BOW_WEAPON_KEYWORDS,
    *SLAYER_MAGE_WEAPON_KEYWORDS
  )
  private val SLAYER_ZOMBIE_SPAWN_WEAPON_DEFAULT_KEYWORDS = arrayOf("halberd")
  private val SLAYER_ZOMBIE_DYNAMIC_SWORD_DEFAULT_KEYWORDS = arrayOf("falchion", "reaper", "shredded", "sword")
  private const val EMAN_SPAWN_WEAPON_TERMINATOR = 0
  private const val EMAN_SPAWN_WEAPON_SHORTBOW = 1
  private const val EMAN_SPAWN_WEAPON_ENDERMAN_SWORD = 2
  private const val EMAN_SPAWN_WEAPON_DYNAMIC = 3
  private const val EMAN_HIT_PHASE_WEAPON_SHORTBOW = 0
  private const val EMAN_HIT_PHASE_WEAPON_TERMINATOR = 1
  private const val EMAN_HIT_PHASE_WEAPON_ENDERMAN_SWORD = 2
  private const val ENDERMAN_END_FARM_MOB_KEYWORD = "enderman"
  private const val ENDERMAN_HIDEOUT_FARM_MOB_KEYWORD = "zealot bruiser"
  private const val ENDERMAN_VOID_FARM_MOB_KEYWORD = "voidling"
  private val SLAYER_ENDERMAN_TERMINATOR_WEAPON_KEYWORDS = arrayOf("terminator")
  private val SLAYER_ENDERMAN_SHORTBOW_WEAPON_KEYWORDS = arrayOf("juju", "shortbow", "bow")
  private val SLAYER_ENDERMAN_DYNAMIC_BOW_WEAPON_KEYWORDS = arrayOf("terminator", "juju", "shortbow", "bow")
  private val SLAYER_ENDERMAN_SPAWN_WEAPON_DEFAULT_KEYWORDS = arrayOf("terminator", "juju", "shortbow", "bow")
  private val SLAYER_ENDERMAN_BOSS_WEAPON_DEFAULT_KEYWORDS = arrayOf("atomsplit", "vorpal", "voidedge", "katana")
  private val SLAYER_SPIDER_PHASE_ADD_KEYWORDS = arrayOf("spider", "hatchling", "hatchlings", "broodling", "vermin")
  private val SLAYER_WOLF_PHASE_ADD_KEYWORDS = arrayOf("wolf", "pup", "pups")
  private val SLAYER_WOLF_PUPS_TEXT_KEYWORDS = arrayOf("calling the pups")
  private val SLAYER_WAND_OF_ATONEMENT_KEYWORDS = arrayOf("wand of atonement")
  private val SLAYER_HYPERION_KEYWORDS = arrayOf("hyperion", "astraea", "scylla", "valkyrie", "necron blade")
  private val SLAYER_ZOMBIE_SWORD_KEYWORDS = arrayOf("zombie sword")
  private val SLAYER_OVERFLUX_KEYWORDS = arrayOf("overflux")
  private val SLAYER_RAGNAROK_KEYWORDS = arrayOf("ragnarok", "ragnorak")
  private val SLAYER_REAPER_SCYTHE_KEYWORDS = arrayOf("reaper scythe")
  private val SLAYER_BAD_HEALTH_KEYWORDS = arrayOf("sword of bad health")
  private val SLAYER_BATPHONE_KEYWORDS = arrayOf("maddox batphone", "batphone")
  private val SLAYER_MADDOX_SCREEN_KEYWORDS = arrayOf("maddox", "slayer")
  // Generic tab keywords that indicate ANY active slayer quest, regardless of type
  private val SLAYER_GENERIC_QUEST_KEYWORDS = arrayOf("slayer quest", "zombie slayer", "wolf slayer",
    "spider slayer", "enderman slayer", "vampire slayer", "blaze slayer")
  private val SLAYER_MADDOX_REVENANT_KEYWORDS get() = when (slayerType.value) {
    0 -> arrayOf("revenant horror", "zombie slayer", "revenant")
    1 -> arrayOf("sven packmaster", "wolf slayer", "sven")
    2 -> arrayOf("tarantula broodfather", "spider slayer", "tarantula")
    3 -> arrayOf("voidgloom seraph", "enderman slayer", "voidgloom")
    4 -> arrayOf("riftstalker bloodfiend", "vampire slayer", "vampire")
    5 -> arrayOf("inferno demonlord", "blaze slayer", "inferno")
    else -> arrayOf()
  }
  private val SLAYER_MADDOX_RESTART_KEYWORDS = arrayOf("restart", "start quest", "begin quest", "start slayer", "slayer quest", "new quest")
  private val SLAYER_MADDOX_CONFIRM_KEYWORDS = arrayOf("confirm", "click to confirm", "accept", "purchase")
  private val SLAYER_QUEST_READY_CHAT_KEYWORDS = arrayOf(
    "ready to spawn your boss",
    "spawn your boss",
    "right-click to summon",
    "slayer quest is ready",
    "kill a mob to spawn the boss",
    "boss will spawn"
  )
  private val SLAYER_BOSS_SPAWNED_CHAT_KEYWORDS get() = when (slayerType.value) {
    0 -> arrayOf(
      "revenant horror has spawned",
      "your revenant horror spawned",
      "atoned horror has spawned",
      "your atoned horror spawned"
    )
    1 -> arrayOf("sven packmaster has spawned", "your sven packmaster spawned")
    2 -> arrayOf("tarantula broodfather has spawned")
    3 -> arrayOf("voidgloom seraph has spawned")
    4 -> arrayOf("riftstalker bloodfiend has spawned")
    5 -> arrayOf("inferno demonlord has spawned")
    else -> arrayOf()
  }
  private val SLAYER_BOSS_KILLED_CHAT_KEYWORDS = arrayOf(
    "you have slain the boss",
    "your slayer quest has been completed",
    "slayer quest complete",
    "boss slain"
  )
  private val SLAYER_LOOT_KEYWORDS = arrayOf("loot", "bag", "drops")
  private const val SLAYER_LOOT_SEARCH_RADIUS_SQ = 36.0  // 6 block radius
  private const val SLAYER_LOOT_CLAIM_RANGE_SQ = 9.0     // 3 block range to right-click
  private const val SLAYER_CLAIM_TIMEOUT_TICKS = 200L    // 10 s before giving up
  private const val SLAYER_CLAIM_DWELL_TICKS = 60L       // 3 s at loot bag before moving on
  private const val SLAYER_CLAIM_CLICK_INTERVAL_TICKS = 5L
  private val slayerWarpCommand get() = when (slayerType.value) {
    0 -> when (slayerLocation.value) {
      0 -> "warp crypts"  // Zombie Graveyard
      else -> ""          // Zombie Crypt: walkback route handles return
    }
    1 -> when (wolfLocation.value) {
      0 -> "warp park"    // Park
      1 -> "warp park"    // Caves (accessed via park)
      2 -> "warp hub"     // Castle
      else -> "warp park"
    }
    2 -> when (spiderLocation.value) {
      0 -> "warp spiders_den"
      1 -> "warp crimson"
      else -> "warp spiders_den"
    }
    3 -> when (endermanLocation.value) {
      2 -> if (endermanVoidWarp.value) "warp void" else ""
      else -> "warp end"
    }
    4 -> "warp rift"
    5 -> "warp blazing_fortress"
    else -> ""
  }
  // Reference positions spread across the crypt - used only for "is player inside crypt?" proximity checks.
  private val CRYPT_PATROL_WAYPOINTS = listOf(
    BlockPos(-152, 57, -102), BlockPos(-133, 50, -101), BlockPos(-132, 45, -121),
    BlockPos(-129, 41, -134), BlockPos(-129, 41, -143), BlockPos(-119, 41, -136),
    BlockPos(-106, 46, -129), BlockPos(-102, 48, -119), BlockPos(-89, 46, -104),
    BlockPos(-77, 46, -105),  BlockPos(-65, 50, -120),  BlockPos(-48, 55, -136),
    BlockPos(-48, 57, -141),  BlockPos(-46, 55, -136),  BlockPos(-80, 46, -101),
    BlockPos(-88, 42, -88),   BlockPos(-96, 38, -86),   BlockPos(-106, 38, -87),
    BlockPos(-114, 43, -89),  BlockPos(-133, 50, -105), BlockPos(-147, 56, -100),
    BlockPos(-145, 57, -114), BlockPos(-136, 58, -127), BlockPos(-121, 55, -126),
    BlockPos(-109, 50, -119), BlockPos(-102, 48, -119),
  )

  private val CYAN_COLOR = Color(0, 255, 255)
  private val PINK_COLOR = Color(255, 105, 180)

  private data class SlayerHighlightState(
    val type: SlayerHighlightType,
    val attunement: BlazeAttunement?,
  )

  private enum class SlayerHighlightType {
    BOSS,
    MINIBOSS,
    HIGH_TIER_MINIBOSS
  }

  private enum class BlazeAttunement(val argb: Int) {
    ASHEN(0xFFFF6B6B.toInt()),
    SPIRIT(0xFF5AE6FF.toInt()),
    AURIC(0xFFFFD54A.toInt()),
    CRYSTAL(0xFFC88CFF.toInt()),
  }

  private data class SlayerEspPalette(
    val stroke: Color,
    val fill: Color,
    val outerStroke: Color,
    val outerFill: Color,
  )

  private val CHAT_FORMATTING_COLORS = listOf(
    ChatFormatting.BLACK to Color(0x000000),
    ChatFormatting.DARK_BLUE to Color(0x0000AA),
    ChatFormatting.DARK_GREEN to Color(0x00AA00),
    ChatFormatting.DARK_AQUA to Color(0x00AAAA),
    ChatFormatting.DARK_RED to Color(0xAA0000),
    ChatFormatting.DARK_PURPLE to Color(0xAA00AA),
    ChatFormatting.GOLD to Color(0xFFAA00),
    ChatFormatting.GRAY to Color(0xAAAAAA),
    ChatFormatting.DARK_GRAY to Color(0x555555),
    ChatFormatting.BLUE to Color(0x5555FF),
    ChatFormatting.GREEN to Color(0x55FF55),
    ChatFormatting.AQUA to Color(0x55FFFF),
    ChatFormatting.RED to Color(0xFF5555),
    ChatFormatting.LIGHT_PURPLE to Color(0xFF55FF),
    ChatFormatting.YELLOW to Color(0xFFFF55),
    ChatFormatting.WHITE to Color(0xFFFFFF),
  )

  private const val SLAYER_ESP_STYLE_GLOW = 0
  private const val SLAYER_ESP_STYLE_BOX = 1
  private const val SLAYER_GLOW_TEAM_PREFIX = "cbsl_"
  private const val SLAYER_GLOW_TEAM_BOSS = "cbsl_boss"
  private const val SLAYER_GLOW_TEAM_MINI = "cbsl_mini"
  private const val SLAYER_GLOW_TEAM_HIGH = "cbsl_high"
  private const val SLAYER_GLOW_TEAM_ASHEN = "cbsl_ash"
  private const val SLAYER_GLOW_TEAM_SPIRIT = "cbsl_spi"
  private const val SLAYER_GLOW_TEAM_AURIC = "cbsl_aur"
  private const val SLAYER_GLOW_TEAM_CRYSTAL = "cbsl_crys"
}
